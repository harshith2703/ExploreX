import React, { useState, useEffect } from 'react';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';

const AdminDashboard = () => {
  const { user: currentUser } = useAuth();
  
  // Tab control state
  const [activeSubTab, setActiveSubTab] = useState('overview');

  // Database counters
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalPlaces: 0,
    totalCategories: 0,
    totalReviews: 0,
    totalBookings: 0,
    totalPendingBookings: 0,
    totalUnrepliedMessages: 0
  });

  // Table collections
  const [places, setPlaces] = useState([]);
  const [categories, setCategories] = useState([]);
  const [users, setUsers] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [contactMessages, setContactMessages] = useState([]);

  // Forms control state
  const [isEditingPlace, setIsEditingPlace] = useState(false);
  const [placeForm, setPlaceForm] = useState({
    id: null,
    name: '',
    description: '',
    location: '',
    state: '',
    district: '',
    categoryId: '',
    imageUrlsRaw: '',
    latitude: '',
    longitude: ''
  });

  const [isEditingCategory, setIsEditingCategory] = useState(false);
  const [categoryForm, setCategoryForm] = useState({
    id: null,
    name: '',
    description: ''
  });

  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  // Fetch admin overview stats
  const fetchStats = async () => {
    try {
      const res = await api.get('/admin/stats');
      setStats(res.data);
    } catch (err) {
      console.error('Error fetching admin statistics:', err);
    }
  };

  useEffect(() => {
    fetchStats();
  }, [activeSubTab]);

  // Load tables dynamically when tabs change
  useEffect(() => {
    const loadTabDetails = async () => {
      setSuccessMsg('');
      setErrorMsg('');
      try {
        if (activeSubTab === 'places') {
          const res = await api.get('/places?sortBy=alphabetical');
          setPlaces(res.data);
          const catRes = await api.get('/categories');
          setCategories(catRes.data);
        } else if (activeSubTab === 'categories') {
          const res = await api.get('/categories');
          setCategories(res.data);
        } else if (activeSubTab === 'users') {
          const res = await api.get('/admin/users');
          setUsers(res.data);
        } else if (activeSubTab === 'bookings') {
          const res = await api.get('/admin/bookings');
          setBookings(res.data);
        } else if (activeSubTab === 'support') {
          const res = await api.get('/admin/contact/all');
          setContactMessages(res.data);
        }
      } catch (err) {
        console.error('Error fetching tab details:', err);
      }
    };
    loadTabDetails();
  }, [activeSubTab]);

  // ----------------------------------------------------
  // PLACE CRUD OPERATIONS
  // ----------------------------------------------------
  const handlePlaceFormSubmit = async (e) => {
    e.preventDefault();
    setSuccessMsg('');
    setErrorMsg('');

    const { name, description, location, state, district, categoryId, imageUrlsRaw, latitude, longitude } = placeForm;
    if (!name || !description || !location || !state || !district || !categoryId) {
      setErrorMsg('Please populate all the required tourist place details.');
      return;
    }

    // Split raw image urls input by comma
    const imageUrls = imageUrlsRaw
      .split(',')
      .map(url => url.trim())
      .filter(url => url !== '');

    const payload = {
      name,
      description,
      location,
      state,
      district,
      categoryId: Number(categoryId),
      imageUrls,
      latitude: latitude ? Number(latitude) : null,
      longitude: longitude ? Number(longitude) : null
    };

    try {
      if (isEditingPlace) {
        const res = await api.put(`/admin/places/${placeForm.id}`, payload);
        setPlaces(places.map(p => p.id === placeForm.id ? res.data : p));
        setSuccessMsg('Tourist place modified successfully!');
      } else {
        const res = await api.post('/admin/places', payload);
        setPlaces([...places, res.data]);
        setSuccessMsg('Tourist destination created successfully!');
      }
      resetPlaceForm();
    } catch (err) {
      setErrorMsg(err.response?.data?.message || 'Error processing place form.');
    }
  };

  const handleEditPlaceClick = (place) => {
    setIsEditingPlace(true);
    setPlaceForm({
      id: place.id,
      name: place.name,
      description: place.description,
      location: place.location,
      state: place.state,
      district: place.district,
      categoryId: place.categoryId.toString(),
      imageUrlsRaw: place.imageUrls ? place.imageUrls.join(', ') : '',
      latitude: place.latitude !== null && place.latitude !== undefined ? place.latitude.toString() : '',
      longitude: place.longitude !== null && place.longitude !== undefined ? place.longitude.toString() : ''
    });
  };

  const handleDeletePlaceClick = async (placeId) => {
    if (!window.confirm('Are you sure you want to permanently delete this tourist place card?')) return;
    try {
      await api.delete(`/admin/places/${placeId}`);
      setPlaces(places.filter(p => p.id !== placeId));
      setSuccessMsg('Place deleted successfully.');
    } catch (err) {
      setErrorMsg('Error deleting destination.');
    }
  };

  const resetPlaceForm = () => {
    setIsEditingPlace(false);
    setPlaceForm({
      id: null,
      name: '',
      description: '',
      location: '',
      state: '',
      district: '',
      categoryId: '',
      imageUrlsRaw: '',
      latitude: '',
      longitude: ''
    });
  };

  // ----------------------------------------------------
  // CATEGORY CRUD OPERATIONS
  // ----------------------------------------------------
  const handleCategoryFormSubmit = async (e) => {
    e.preventDefault();
    setSuccessMsg('');
    setErrorMsg('');

    const { name, description } = categoryForm;
    if (!name) {
      setErrorMsg('Category name is required.');
      return;
    }

    try {
      if (isEditingCategory) {
        const res = await api.put(`/admin/categories/${categoryForm.id}`, { name, description });
        setCategories(categories.map(c => c.id === categoryForm.id ? res.data : c));
        setSuccessMsg('Category updated successfully!');
      } else {
        const res = await api.post('/admin/categories', { name, description });
        setCategories([...categories, res.data]);
        setSuccessMsg('Category created successfully!');
      }
      resetCategoryForm();
    } catch (err) {
      setErrorMsg(err.response?.data?.message || 'Error executing category operations.');
    }
  };

  const handleEditCategoryClick = (cat) => {
    setIsEditingCategory(true);
    setCategoryForm({
      id: cat.id,
      name: cat.name,
      description: cat.description || ''
    });
  };

  const handleDeleteCategoryClick = async (catId) => {
    if (!window.confirm('Deleting category may fail if tourist places refer to it. Continue?')) return;
    try {
      await api.delete(`/admin/categories/${catId}`);
      setCategories(categories.filter(c => c.id !== catId));
      setSuccessMsg('Category removed successfully.');
    } catch (err) {
      setErrorMsg('Error deleting category: check constraints.');
    }
  };

  const resetCategoryForm = () => {
    setIsEditingCategory(false);
    setCategoryForm({
      id: null,
      name: '',
      description: ''
    });
  };

  // ----------------------------------------------------
  // USER & BOOKING & SUPPORT OPERATIONS
  // ----------------------------------------------------
  const handleDeleteUser = async (userId) => {
    if (userId === currentUser.id) {
      alert("You cannot delete your own logged-in admin account!");
      return;
    }
    if (!window.confirm('Are you sure you want to permanently delete this user account?')) return;
    try {
      await api.delete(`/admin/users/${userId}`);
      setUsers(users.filter(u => u.id !== userId));
      setSuccessMsg('User account terminated.');
    } catch (err) {
      setErrorMsg('Failed to terminate user account.');
    }
  };

  const handleUpdateBookingStatus = async (bookingId, status) => {
    try {
      const res = await api.put(`/admin/bookings/${bookingId}/status?status=${status}`);
      setBookings(bookings.map(b => b.id === bookingId ? res.data : b));
      setSuccessMsg(`Booking status set to: ${status}`);
    } catch (err) {
      console.error(err);
      alert('Error updating booking status.');
    }
  };

  const handleReplyMessage = async (messageId) => {
    try {
      await api.put(`/admin/contact/${messageId}/reply`);
      setContactMessages(contactMessages.map(m => m.id === messageId ? { ...m, replied: true } : m));
      setSuccessMsg('Support ticket marked as resolved. Response logged to console.');
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="container-fluid py-5 px-lg-5">
      <div className="text-center mb-5">
        <h1 className="fw-bold display-4">Admin Control Center</h1>
        <p className="text-muted">Manage destinations database catalog, categories, user settings, bookings, and support inquiries</p>
      </div>

      <div className="row g-4">
        {/* Left Side: Category / Resource Tabs Navigation */}
        <div className="col-lg-2">
          <div className="card shadow-sm border-0 p-3" style={{ borderRadius: '16px' }}>
            <div className="d-flex flex-column gap-2">
              <button
                onClick={() => setActiveSubTab('overview')}
                className={`btn text-start py-2 px-3 rounded-pill border-0 fw-semibold ${
                  activeSubTab === 'overview' ? 'btn-explore' : 'text-secondary'
                }`}
              >
                <i className="bi bi-speedometer2 me-2"></i>Overview
              </button>
              <button
                onClick={() => setActiveSubTab('places')}
                className={`btn text-start py-2 px-3 rounded-pill border-0 fw-semibold ${
                  activeSubTab === 'places' ? 'btn-explore' : 'text-secondary'
                }`}
              >
                <i className="bi bi-compass me-2"></i>Tourist Places
              </button>
              <button
                onClick={() => setActiveSubTab('categories')}
                className={`btn text-start py-2 px-3 rounded-pill border-0 fw-semibold ${
                  activeSubTab === 'categories' ? 'btn-explore' : 'text-secondary'
                }`}
              >
                <i className="bi bi-tags me-2"></i>Categories
              </button>
              <button
                onClick={() => setActiveSubTab('bookings')}
                className={`btn text-start py-2 px-3 rounded-pill border-0 fw-semibold ${
                  activeSubTab === 'bookings' ? 'btn-explore' : 'text-secondary'
                }`}
              >
                <i className="bi bi-calendar-check me-2"></i>Bookings
              </button>
              <button
                onClick={() => setActiveSubTab('users')}
                className={`btn text-start py-2 px-3 rounded-pill border-0 fw-semibold ${
                  activeSubTab === 'users' ? 'btn-explore' : 'text-secondary'
                }`}
              >
                <i className="bi bi-people me-2"></i>Manage Users
              </button>
              <button
                onClick={() => setActiveSubTab('support')}
                className={`btn text-start py-2 px-3 rounded-pill border-0 fw-semibold ${
                  activeSubTab === 'support' ? 'btn-explore' : 'text-secondary'
                }`}
              >
                <i className="bi bi-chat-left-text me-2"></i>Support Inbox
              </button>
            </div>
          </div>
        </div>

        {/* Right Side: Tab Displays */}
        <div className="col-lg-10">
          {successMsg && <div className="alert alert-success border-0 text-center rounded-pill py-2 small mb-3">{successMsg}</div>}
          {errorMsg && <div className="alert alert-danger border-0 text-center rounded-pill py-2 small mb-3">{errorMsg}</div>}

          {/* 1. OVERVIEW STATISTICS TAB */}
          {activeSubTab === 'overview' && (
            <div>
              <h3 className="fw-bold mb-4 text-dark"><i className="bi bi-bar-chart-line text-primary me-2"></i>ExploreX Analytics Summary</h3>
              <div className="row g-4">
                <div className="col-md-3">
                  <div className="card shadow-sm border-0 p-4 text-center h-100" style={{ borderRadius: '16px', background: 'var(--white)' }}>
                    <i className="bi bi-people-fill text-primary fs-2 mb-2"></i>
                    <h3 className="fw-bold text-dark mb-1">{stats.totalUsers}</h3>
                    <span className="text-muted small fw-semibold text-uppercase">Total Users</span>
                  </div>
                </div>
                <div className="col-md-3">
                  <div className="card shadow-sm border-0 p-4 text-center h-100" style={{ borderRadius: '16px', background: 'var(--white)' }}>
                    <i className="bi bi-compass-fill text-success fs-2 mb-2"></i>
                    <h3 className="fw-bold text-dark mb-1">{stats.totalPlaces}</h3>
                    <span className="text-muted small fw-semibold text-uppercase">Tourist Places</span>
                  </div>
                </div>
                <div className="col-md-3">
                  <div className="card shadow-sm border-0 p-4 text-center h-100" style={{ borderRadius: '16px', background: 'var(--white)' }}>
                    <i className="bi bi-journal-album text-warning fs-2 mb-2"></i>
                    <h3 className="fw-bold text-dark mb-1">{stats.totalBookings}</h3>
                    <span className="text-muted small fw-semibold text-uppercase">Total Bookings</span>
                  </div>
                </div>
                <div className="col-md-3">
                  <div className="card shadow-sm border-0 p-4 text-center h-100" style={{ borderRadius: '16px', background: 'var(--white)' }}>
                    <i className="bi bi-chat-square-quote-fill text-danger fs-2 mb-2"></i>
                    <h3 className="fw-bold text-dark mb-1">{stats.totalReviews}</h3>
                    <span className="text-muted small fw-semibold text-uppercase">Reviews Published</span>
                  </div>
                </div>
              </div>

              {/* Action warnings widgets */}
              <div className="row mt-4 g-4">
                <div className="col-md-6">
                  <div className="card border-0 shadow-sm p-4 bg-warning-subtle text-warning-emphasis" style={{ borderRadius: '16px' }}>
                    <div className="d-flex align-items-center gap-3">
                      <i className="bi bi-exclamation-octagon fs-2"></i>
                      <div>
                        <h5 className="fw-bold mb-1">{stats.totalPendingBookings} Pending Bookings</h5>
                        <p className="small mb-0 text-secondary">These bookings are waiting for guide allocations and approvals.</p>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="card border-0 shadow-sm p-4 bg-danger-subtle text-danger-emphasis" style={{ borderRadius: '16px' }}>
                    <div className="d-flex align-items-center gap-3">
                      <i className="bi bi-mailbox2 fs-2"></i>
                      <div>
                        <h5 className="fw-bold mb-1">{stats.totalUnrepliedMessages} Unresolved Tickets</h5>
                        <p className="small mb-0 text-secondary">Visitors require assistance regarding custom package details.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 2. PLACES CRUD MANAGEMENT TAB */}
          {activeSubTab === 'places' && (
            <div className="row g-4">
              {/* Table of places */}
              <div className="col-lg-7">
                <div className="card shadow-sm border-0 p-4" style={{ borderRadius: '16px' }}>
                  <h4 className="fw-bold text-dark mb-4">Tourist Destinations</h4>
                  <div className="table-responsive">
                    <table className="table align-middle table-hover">
                      <thead>
                        <tr>
                          <th>Place</th>
                          <th>Category</th>
                          <th>Location</th>
                          <th>Rating</th>
                          <th>Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {places.map((place) => (
                          <tr key={place.id}>
                            <td><span className="fw-semibold text-dark">{place.name}</span></td>
                            <td><span className="badge bg-success-subtle text-success small">{place.categoryName}</span></td>
                            <td><span className="small text-muted">{place.location}, {place.state}</span></td>
                            <td><span className="fw-bold text-warning"><i className="bi bi-star-fill me-1"></i>{place.averageRating}</span></td>
                            <td>
                              <div className="d-flex gap-2">
                                <button onClick={() => handleEditPlaceClick(place)} className="btn btn-outline-primary btn-sm rounded-pill px-3"><i className="bi bi-pencil"></i></button>
                                <button onClick={() => handleDeletePlaceClick(place.id)} className="btn btn-outline-danger btn-sm rounded-pill px-3"><i className="bi bi-trash3"></i></button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

              {/* Form to Create/Update Place */}
              <div className="col-lg-5">
                <div className="card shadow-sm border-0 p-4" style={{ borderRadius: '16px' }}>
                  <h4 className="fw-bold text-dark mb-4">{isEditingPlace ? 'Edit Destination' : 'Add New Destination'}</h4>
                  <form onSubmit={handlePlaceFormSubmit}>
                    <div className="mb-3">
                      <label className="form-label small fw-semibold text-secondary">Destination Name *</label>
                      <input
                        type="text"
                        className="form-control bg-light border-0"
                        value={placeForm.name}
                        onChange={(e) => setPlaceForm({ ...placeForm, name: e.target.value })}
                        placeholder="Taj Mahal, Vagator Beach..."
                      />
                    </div>
                    <div className="row g-2 mb-3">
                      <div className="col-md-6">
                        <label className="form-label small fw-semibold text-secondary">Location City *</label>
                        <input
                          type="text"
                          className="form-control bg-light border-0"
                          value={placeForm.location}
                          onChange={(e) => setPlaceForm({ ...placeForm, location: e.target.value })}
                        />
                      </div>
                      <div className="col-md-6">
                        <label className="form-label small fw-semibold text-secondary">Category *</label>
                        <select
                          className="form-select bg-light border-0"
                          value={placeForm.categoryId}
                          onChange={(e) => setPlaceForm({ ...placeForm, categoryId: e.target.value })}
                        >
                          <option value="">Select Category</option>
                          {categories.map(c => <option value={c.id} key={c.id}>{c.name}</option>)}
                        </select>
                      </div>
                    </div>

                    <div className="row g-2 mb-3">
                      <div className="col-md-6">
                        <label className="form-label small fw-semibold text-secondary">District *</label>
                        <input
                          type="text"
                          className="form-control bg-light border-0"
                          value={placeForm.district}
                          onChange={(e) => setPlaceForm({ ...placeForm, district: e.target.value })}
                        />
                      </div>
                      <div className="col-md-6">
                        <label className="form-label small fw-semibold text-secondary">State *</label>
                        <input
                          type="text"
                          className="form-control bg-light border-0"
                          value={placeForm.state}
                          onChange={(e) => setPlaceForm({ ...placeForm, state: e.target.value })}
                        />
                      </div>
                    </div>

                    <div className="row g-2 mb-3">
                      <div className="col-md-6">
                        <label className="form-label small fw-semibold text-secondary">Latitude (e.g. 15.6030)</label>
                        <input
                          type="number"
                          step="any"
                          className="form-control bg-light border-0"
                          placeholder="Latitude"
                          value={placeForm.latitude}
                          onChange={(e) => setPlaceForm({ ...placeForm, latitude: e.target.value })}
                        />
                      </div>
                      <div className="col-md-6">
                        <label className="form-label small fw-semibold text-secondary">Longitude (e.g. 73.7348)</label>
                        <input
                          type="number"
                          step="any"
                          className="form-control bg-light border-0"
                          placeholder="Longitude"
                          value={placeForm.longitude}
                          onChange={(e) => setPlaceForm({ ...placeForm, longitude: e.target.value })}
                        />
                      </div>
                    </div>

                    <div className="mb-3">
                      <label className="form-label small fw-semibold text-secondary">Image URLs (comma separated) *</label>
                      <textarea
                        rows="2"
                        className="form-control bg-light border-0"
                        placeholder="https://link1.jpg, https://link2.jpg..."
                        value={placeForm.imageUrlsRaw}
                        onChange={(e) => setPlaceForm({ ...placeForm, imageUrlsRaw: e.target.value })}
                      ></textarea>
                    </div>

                    <div className="mb-4">
                      <label className="form-label small fw-semibold text-secondary">Description *</label>
                      <textarea
                        rows="4"
                        className="form-control bg-light border-0"
                        placeholder="Detailed tourist guide info..."
                        value={placeForm.description}
                        onChange={(e) => setPlaceForm({ ...placeForm, description: e.target.value })}
                      ></textarea>
                    </div>

                    <div className="d-flex gap-2">
                      <button type="submit" className="btn btn-explore rounded-pill px-4 flex-grow-1">
                        {isEditingPlace ? 'Modify Details' : 'Create Card'}
                      </button>
                      {isEditingPlace && (
                        <button type="button" onClick={resetPlaceForm} className="btn btn-outline-secondary rounded-pill px-3">
                          Cancel
                        </button>
                      )}
                    </div>
                  </form>
                </div>
              </div>
            </div>
          )}

          {/* 3. CATEGORIES CRUD TAB */}
          {activeSubTab === 'categories' && (
            <div className="row g-4">
              <div className="col-lg-7">
                <div className="card shadow-sm border-0 p-4" style={{ borderRadius: '16px' }}>
                  <h4 className="fw-bold text-dark mb-4">Categories List</h4>
                  <div className="table-responsive">
                    <table className="table align-middle table-hover">
                      <thead>
                        <tr>
                          <th>Category ID</th>
                          <th>Name</th>
                          <th>Description</th>
                          <th>Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {categories.map((cat) => (
                          <tr key={cat.id}>
                            <td><span className="small text-muted">#CAT-0{cat.id}</span></td>
                            <td><span className="fw-semibold text-dark">{cat.name}</span></td>
                            <td><span className="small text-muted">{cat.description || 'None'}</span></td>
                            <td>
                              <div className="d-flex gap-2">
                                <button onClick={() => handleEditCategoryClick(cat)} className="btn btn-outline-primary btn-sm rounded-pill px-3"><i className="bi bi-pencil"></i></button>
                                <button onClick={() => handleDeleteCategoryClick(cat.id)} className="btn btn-outline-danger btn-sm rounded-pill px-3"><i className="bi bi-trash3"></i></button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

              {/* Form Category */}
              <div className="col-lg-5">
                <div className="card shadow-sm border-0 p-4" style={{ borderRadius: '16px' }}>
                  <h4 className="fw-bold text-dark mb-4">{isEditingCategory ? 'Edit Category' : 'Create Category'}</h4>
                  <form onSubmit={handleCategoryFormSubmit}>
                    <div className="mb-3">
                      <label className="form-label small fw-semibold text-secondary">Category Name *</label>
                      <input
                        type="text"
                        className="form-control bg-light border-0"
                        placeholder="Beach, Wildlife..."
                        value={categoryForm.name}
                        onChange={(e) => setCategoryForm({ ...categoryForm, name: e.target.value })}
                      />
                    </div>
                    <div className="mb-4">
                      <label className="form-label small fw-semibold text-secondary">Description</label>
                      <textarea
                        rows="3"
                        className="form-control bg-light border-0"
                        placeholder="Category short description details..."
                        value={categoryForm.description}
                        onChange={(e) => setCategoryForm({ ...categoryForm, description: e.target.value })}
                      ></textarea>
                    </div>

                    <div className="d-flex gap-2">
                      <button type="submit" className="btn btn-explore rounded-pill px-4 flex-grow-1">
                        {isEditingCategory ? 'Modify Category' : 'Save Category'}
                      </button>
                      {isEditingCategory && (
                        <button type="button" onClick={resetCategoryForm} className="btn btn-outline-secondary rounded-pill px-3">
                          Cancel
                        </button>
                      )}
                    </div>
                  </form>
                </div>
              </div>
            </div>
          )}

          {/* 4. BOOKINGS MANAGEMENT TAB */}
          {activeSubTab === 'bookings' && (
            <div className="card shadow-sm border-0 p-4" style={{ borderRadius: '16px' }}>
              <h4 className="fw-bold text-dark mb-4">Tour Booking Inquiries</h4>
              <div className="table-responsive">
                <table className="table align-middle table-hover">
                  <thead>
                    <tr>
                      <th>Booking ID</th>
                      <th>Destination</th>
                      <th>Tourist Email</th>
                      <th>Scheduled Date</th>
                      <th>People</th>
                      <th>Status</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {bookings.map((b) => (
                      <tr key={b.id}>
                        <td><span className="fw-semibold text-secondary">#EX-0{b.id}</span></td>
                        <td><span className="fw-bold text-primary">{b.touristPlaceName}</span></td>
                        <td><span className="small text-muted">{b.userEmail}</span></td>
                        <td>{new Date(b.bookingDate).toLocaleDateString()}</td>
                        <td>{b.numberOfPeople} travelers</td>
                        <td>
                          <span className={`badge rounded-pill px-3 py-1 ${
                            b.status.toUpperCase() === 'APPROVED' ? 'bg-success' : b.status.toUpperCase() === 'CANCELLED' ? 'bg-danger' : 'bg-warning text-dark'
                          }`}>
                            {b.status}
                          </span>
                        </td>
                        <td>
                          {b.status.toUpperCase() === 'PENDING' && (
                            <div className="d-flex gap-2">
                              <button onClick={() => handleUpdateBookingStatus(b.id, 'APPROVED')} className="btn btn-success btn-sm rounded-pill px-3 fw-bold text-white"><i className="bi bi-check-circle me-1"></i>Approve</button>
                              <button onClick={() => handleUpdateBookingStatus(b.id, 'CANCELLED')} className="btn btn-outline-danger btn-sm rounded-pill px-3"><i className="bi bi-x-circle me-1"></i>Reject</button>
                            </div>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* 5. USER MANAGEMENT TAB */}
          {activeSubTab === 'users' && (
            <div className="card shadow-sm border-0 p-4" style={{ borderRadius: '16px' }}>
              <h4 className="fw-bold text-dark mb-4">ExploreX User Directory</h4>
              <div className="table-responsive">
                <table className="table align-middle table-hover">
                  <thead>
                    <tr>
                      <th>User ID</th>
                      <th>Display Name</th>
                      <th>Email Address</th>
                      <th>Username</th>
                      <th>Roles</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {users.map((u) => (
                      <tr key={u.id}>
                        <td><span className="small text-muted">#USER-0{u.id}</span></td>
                        <td><span className="fw-semibold text-dark">{u.firstName} {u.lastName || ''}</span></td>
                        <td>{u.email}</td>
                        <td><span className="text-secondary fw-medium">@{u.username}</span></td>
                        <td>
                          {u.roles.map((r, i) => (
                            <span key={i} className={`badge rounded-pill me-1 ${r === 'ROLE_ADMIN' ? 'bg-danger-subtle text-danger' : 'bg-primary-subtle text-primary'}`}>
                              {r.replace('ROLE_', '')}
                            </span>
                          ))}
                        </td>
                        <td>
                          {u.id !== currentUser.id && (
                            <button onClick={() => handleDeleteUser(u.id)} className="btn btn-outline-danger btn-sm rounded-pill px-3">
                              <i className="bi bi-trash3 me-1"></i>Terminate Account
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* 6. SUPPORT INBOX TAB */}
          {activeSubTab === 'support' && (
            <div className="card shadow-sm border-0 p-4" style={{ borderRadius: '16px' }}>
              <h4 className="fw-bold text-dark mb-4">Support Inquiry Desk</h4>
              <div className="table-responsive">
                <table className="table align-middle table-hover">
                  <thead>
                    <tr>
                      <th>Subject</th>
                      <th>Sender Email</th>
                      <th>Message</th>
                      <th>Date Sent</th>
                      <th>Status</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {contactMessages.map((m) => (
                      <tr key={m.id}>
                        <td><span className="fw-bold text-dark">{m.subject}</span></td>
                        <td><span className="fw-semibold text-secondary">{m.name}</span> <br/><span className="text-muted small">{m.email}</span></td>
                        <td><span className="small text-muted">{m.message}</span></td>
                        <td>{new Date(m.createdAt).toLocaleDateString()}</td>
                        <td>
                          <span className={`badge rounded-pill px-3 py-1 ${m.replied ? 'bg-success text-white' : 'bg-danger text-white'}`}>
                            {m.replied ? 'Resolved' : 'Pending'}
                          </span>
                        </td>
                        <td>
                          {!m.replied && (
                            <button onClick={() => handleReplyMessage(m.id)} className="btn btn-outline-primary btn-sm rounded-pill px-3">
                              <i className="bi bi-reply me-1"></i>Resolve Inquiry
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
