import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Register = () => {
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
    firstName: '',
    lastName: '',
    phoneNumber: ''
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);
  
  const { register } = useAuth();
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    // Input fields verification
    const { username, email, password, confirmPassword, firstName } = formData;
    if (!username || !email || !password || !confirmPassword || !firstName) {
      setError('Please fill in all the required fields.');
      return;
    }

    if (password.length < 6) {
      setError('Password must be at least 6 characters long.');
      return;
    }

    if (password !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }

    setLoading(true);
    // Destructure confirmPassword out of the payload sent to backend
    const { confirmPassword: _, ...registerPayload } = formData;
    const result = await register(registerPayload);
    setLoading(false);

    if (result.success) {
      setSuccess('Account created successfully! Redirecting to login page...');
      setTimeout(() => {
        navigate('/login');
      }, 2500);
    } else {
      setError(result.error);
    }
  };

  return (
    <div className="container py-5">
      <div className="row justify-content-center">
        <div className="col-md-7">
          <div className="card shadow-lg border-0 p-4" style={{ borderRadius: '16px' }}>
            <div className="card-body">
              <div className="text-center mb-4">
                <i className="bi bi-person-plus text-success" style={{ fontSize: '3rem' }}></i>
                <h2 className="mt-3 fw-bold">Join ExploreX</h2>
                <p className="text-muted">Create your account to start reviewing and booking tours</p>
              </div>

              {error && (
                <div className="alert alert-danger border-0 text-center rounded-pill" role="alert">
                  <i className="bi bi-exclamation-triangle-fill me-2"></i>{error}
                </div>
              )}

              {success && (
                <div className="alert alert-success border-0 text-center rounded-pill" role="alert">
                  <i className="bi bi-check-circle-fill me-2"></i>{success}
                </div>
              )}

              <form onSubmit={handleSubmit}>
                <div className="row">
                  {/* First Name */}
                  <div className="col-md-6 mb-3">
                    <label className="form-label fw-semibold text-secondary">First Name *</label>
                    <input
                      type="text"
                      className="form-control bg-light border-0 py-2"
                      name="firstName"
                      placeholder="First Name"
                      value={formData.firstName}
                      onChange={handleChange}
                    />
                  </div>

                  {/* Last Name */}
                  <div className="col-md-6 mb-3">
                    <label className="form-label fw-semibold text-secondary">Last Name</label>
                    <input
                      type="text"
                      className="form-control bg-light border-0 py-2"
                      name="lastName"
                      placeholder="Last Name"
                      value={formData.lastName}
                      onChange={handleChange}
                    />
                  </div>
                </div>

                <div className="row">
                  {/* Username */}
                  <div className="col-md-6 mb-3">
                    <label className="form-label fw-semibold text-secondary">Username *</label>
                    <input
                      type="text"
                      className="form-control bg-light border-0 py-2"
                      name="username"
                      placeholder="Choose username"
                      value={formData.username}
                      onChange={handleChange}
                    />
                  </div>

                  {/* Email */}
                  <div className="col-md-6 mb-3">
                    <label className="form-label fw-semibold text-secondary">Email *</label>
                    <input
                      type="email"
                      className="form-control bg-light border-0 py-2"
                      name="email"
                      placeholder="name@example.com"
                      value={formData.email}
                      onChange={handleChange}
                    />
                  </div>
                </div>

                <div className="row">
                  {/* Phone */}
                  <div className="col-md-12 mb-3">
                    <label className="form-label fw-semibold text-secondary">Phone Number</label>
                    <input
                      type="text"
                      className="form-control bg-light border-0 py-2"
                      name="phoneNumber"
                      placeholder="Enter mobile number"
                      value={formData.phoneNumber}
                      onChange={handleChange}
                    />
                  </div>
                </div>

                <div className="row">
                  {/* Password */}
                  <div className="col-md-6 mb-4">
                    <label className="form-label fw-semibold text-secondary">Password *</label>
                    <input
                      type="password"
                      className="form-control bg-light border-0 py-2"
                      name="password"
                      placeholder="Min 6 characters"
                      value={formData.password}
                      onChange={handleChange}
                    />
                  </div>

                  {/* Confirm Password */}
                  <div className="col-md-6 mb-4">
                    <label className="form-label fw-semibold text-secondary">Confirm Password *</label>
                    <input
                      type="password"
                      className="form-control bg-light border-0 py-2"
                      name="confirmPassword"
                      placeholder="Confirm password"
                      value={formData.confirmPassword}
                      onChange={handleChange}
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="btn btn-explore w-100 py-2 rounded-pill fw-bold fs-5 shadow"
                  disabled={loading}
                >
                  {loading ? (
                    <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                  ) : 'Sign Up'}
                </button>
              </form>

              <div className="text-center mt-4">
                <span className="text-muted">Already have an account? </span>
                <Link to="/login" className="fw-semibold text-decoration-none" style={{ color: 'var(--primary-blue)' }}>Sign In</Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Register;
