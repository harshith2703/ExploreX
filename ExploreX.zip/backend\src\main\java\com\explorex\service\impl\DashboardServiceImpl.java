package com.explorex.service.impl;

import com.explorex.dto.DashboardStatsDto;
import com.explorex.repository.*;
import com.explorex.service.DashboardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Service implementation for compiling dashboard analytics counters.
 */
@Service
public class DashboardServiceImpl implements DashboardService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private TouristPlaceRepository touristPlaceRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private ReviewRepository reviewRepository;

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private ContactMessageRepository contactMessageRepository;

    @Override
    public DashboardStatsDto getDashboardStats() {
        long totalUsers = userRepository.count();
        long totalPlaces = touristPlaceRepository.count();
        long totalCategories = categoryRepository.count();
        long totalReviews = reviewRepository.count();
        long totalBookings = bookingRepository.count();
        
        long totalPendingBookings = bookingRepository.findByStatus("PENDING").size();
        long totalUnrepliedMessages = contactMessageRepository.findByReplied(false).size();

        return new DashboardStatsDto(
                totalUsers,
                totalPlaces,
                totalCategories,
                totalReviews,
                totalBookings,
                totalPendingBookings,
                totalUnrepliedMessages
        );
    }
}
