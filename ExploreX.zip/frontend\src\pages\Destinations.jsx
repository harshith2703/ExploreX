import React, { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import api from '../services/api';

const Destinations = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [places, setPlaces] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  
  // Geolocation Coordinates
  const [userCoords, setUserCoords] = useState(null);

  // Read URL parameters
  const categoryId = searchParams.get('categoryId') || '';
  const keyword = searchParams.get('keyword') || '';
  const sortBy = searchParams.get('sortBy') || 'alphabetical';

  // Input states for filters
  const [searchInput, setSearchInput] = useState(keyword);
  const [sortSelect, setSortSelect] = useState(sortBy);

  // Haversine Distance Calculator
  const calculateDistance = (lat1, lon1, lat2, lon2) => {
    if (!lat1 || !lon1 || !lat2 || !lon2) return null;
    const R = 6371; // Earth radius in km
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLon = ((lon2 - lon1) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((lat1 * Math.PI) / 180) *
        Math.cos((lat2 * Math.PI) / 180) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return parseFloat((R * c).toFixed(1));
  };

  useEffect(() => {
    // Fetch categories list on mount
    const fetchCategories = async () => {
      try {
        const res = await api.get('/categories');
        setCategories(res.data);
      } catch (err) {
        console.error('Error fetching categories:', err);
      }
    };
    fetchCategories();

    // Trigger browser GPS request
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setUserCoords({
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
          });
        },
        (error) => {
          console.warn('Geolocation access rejected:', error.message);
        }
      );
    }
  }, []);

  useEffect(() => {
    // Sync search input with URL when URL changes directly
    setSearchInput(keyword);
  }, [keyword]);

  useEffect(() => {
    // Fetch filtered and sorted tourist places
    const fetchFilteredPlaces = async () => {
      setLoading(true);
      try {
        // Fallback server sort parameter if "nearest" is active
        const serverSort = sortBy === 'nearest' ? 'alphabetical' : sortBy;
        let path = `/places?sortBy=${serverSort}`;
        if (categoryId) {
          path += `&categoryId=${categoryId}`;
        }
        if (keyword) {
          path += `&keyword=${encodeURIComponent(keyword)}`;
        }
        const res = await api.get(path);

        // Inject distance parameters
        let loadedPlaces = res.data.map((p) => {
          const dist = userCoords ? calculateDistance(userCoords.lat, userCoords.lng, p.latitude, p.longitude) : null;
          return { ...p, distance: dist };
        });

        // Client-side sort by distance if "nearest" is selected
        if (sortBy === 'nearest' && userCoords) {
          loadedPlaces.sort((a, b) => {
            if (a.distance === null) return 1;
            if (b.distance === null) return -1;
            return a.distance - b.distance;
          });
        }

        setPlaces(loadedPlaces);
      } catch (error) {
        console.error('Error fetching filtered destinations:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchFilteredPlaces();
  }, [categoryId, keyword, sortBy, userCoords]);

  // Update query parameters in URL
  const updateParams = (newParams) => {
    const current = Object.fromEntries(searchParams);
    const updated = { ...current, ...newParams };
    
    // Remove empty parameters
    Object.keys(updated).forEach(key => {
      if (!updated[key]) delete updated[key];
    });

    setSearchParams(updated);
  };

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    updateParams({ keyword: searchInput });
  };

  const handleCategoryFilter = (id) => {
    updateParams({ categoryId: id === categoryId ? '' : id }); // Toggle category filter
  };

  const handleSortChange = (e) => {
    setSortSelect(e.target.value);
    updateParams({ sortBy: e.target.value });
  };

  const clearAllFilters = () => {
    setSearchInput('');
    setSortSelect('alphabetical');
    setSearchParams({});
  };

  return (
    <div className="container py-5">
      <div className="text-center mb-5">
        <h1 className="fw-bold display-4">Explore Destinations</h1>
        <p className="text-muted">Find and book verified tour packages across scenic destinations</p>
      </div>

      <div className="row g-4">
        {/* Sidebar Filters Column */}
        <div className="col-lg-3">
          <div className="card shadow-sm border-0 p-4 sticky-lg-top" style={{ borderRadius: '16px', top: '100px' }}>
            <div className="d-flex justify-content-between align-items-center mb-4">
              <h5 className="fw-bold mb-0 text-dark">Filters</h5>
              <button onClick={clearAllFilters} className="btn btn-link text-decoration-none text-muted small p-0">Clear All</button>
            </div>

            {/* Keyword Search Form */}
            <form onSubmit={handleSearchSubmit} className="mb-4">
              <label className="form-label small fw-semibold text-secondary">Search Keyword</label>
              <div className="input-group bg-light rounded-pill overflow-hidden border">
                <input
                  type="text"
                  className="form-control border-0 bg-transparent py-2"
                  placeholder="Type name, state..."
                  value={searchInput}
                  onChange={(e) => setSearchInput(e.target.value)}
                />
                <button type="submit" className="btn btn-transparent border-0"><i className="bi bi-search text-muted"></i></button>
              </div>
            </form>

            {/* Categories filter list */}
            <div className="mb-4">
              <label className="form-label small fw-semibold text-secondary mb-3">Categories</label>
              <div className="d-flex flex-column gap-2">
                {categories.map((cat) => {
                  const isActive = categoryId === cat.id.toString();
                  return (
                    <button
                      key={cat.id}
                      onClick={() => handleCategoryFilter(cat.id.toString())}
                      className={`btn w-100 text-start py-2 px-3 rounded-3 d-flex justify-content-between align-items-center fw-medium border-0 transition ${
                        isActive ? 'bg-success text-white' : 'bg-light text-dark hover-green'
                      }`}
                    >
                      <span>{cat.name}</span>
                      {isActive && <i className="bi bi-check-circle-fill"></i>}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Sorting Widget */}
            <div className="mb-2">
              <label className="form-label small fw-semibold text-secondary">Sort By</label>
              <select
                className="form-select bg-light border py-2"
                value={sortSelect}
                onChange={handleSortChange}
                style={{ borderRadius: '8px' }}
              >
                <option value="alphabetical">Alphabetical</option>
                <option value="rating">Highest Rating</option>
                <option value="newest">Newest Added</option>
                <option value="popularity">Popularity</option>
                <option value="nearest" disabled={!userCoords}>
                  Nearest to Me {!userCoords ? '(Enable GPS)' : ''}
                </option>
              </select>
            </div>
          </div>
        </div>

        {/* Places List Grid Column */}
        <div className="col-lg-9">
          {loading ? (
            <div className="text-center py-5">
              <div className="spinner-border text-primary" role="status" style={{ width: '3rem', height: '3rem' }}>
                <span className="visually-hidden">Loading destinations...</span>
              </div>
              <p className="mt-3 text-muted">Sifting through scenic spots...</p>
            </div>
          ) : places.length === 0 ? (
            <div className="card shadow-sm border-0 p-5 text-center" style={{ borderRadius: '16px' }}>
              <i className="bi bi-compass text-muted" style={{ fontSize: '4rem' }}></i>
              <h3 className="fw-bold mt-3">No Places Found</h3>
              <p className="text-muted">We couldn't find any destinations matching your criteria. Try adjusting your keyword search filters.</p>
              <button onClick={clearAllFilters} className="btn btn-explore mx-auto mt-2 rounded-pill px-4">Clear All Filters</button>
            </div>
          ) : (
            <div>
              <div className="d-flex justify-content-between align-items-center mb-4">
                <span className="text-muted fw-medium">{places.length} destinations found</span>
              </div>
              
              <div className="row g-4">
                {places.map((place) => (
                  <div className="col-md-6" key={place.id}>
                    <div className="card explore-card border-0 h-100 shadow-sm">
                      <div className="position-relative">
                        <img
                          src={place.imageUrls?.[0] || 'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?w=800'}
                          alt={place.name}
                          className="card-img-top"
                          style={{ height: '220px', objectFit: 'cover' }}
                        />
                        <div className="position-absolute top-0 end-0 m-3">
                          <span className="rating-badge shadow-sm">
                            <i className="bi bi-star-fill text-warning"></i>
                            {place.averageRating || 'New'}
                          </span>
                        </div>
                      </div>
                      <div className="card-body p-4 d-flex flex-column">
                        <span className="text-uppercase small fw-bold text-success mb-2">{place.categoryName}</span>
                        <h4 className="card-title fw-bold text-dark mb-1">{place.name}</h4>
                        <p className="text-secondary small mb-3 d-flex justify-content-between align-items-center flex-wrap gap-2">
                          <span><i className="bi bi-geo-alt-fill text-danger me-1"></i>{place.location}, {place.state}</span>
                          {place.distance !== null && (
                            <span className="badge bg-success-subtle text-success rounded-pill fw-bold" style={{ fontSize: '11px' }}>
                              <i className="bi bi-pin-map me-1"></i>{place.distance} km away
                            </span>
                          )}
                        </p>
                        <p className="text-muted small flex-grow-1 card-text-truncate" style={{ display: '-webkit-box', WebkitLineClamp: 3, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
                          {place.description}
                        </p>
                        <Link to={`/places/${place.id}`} className="btn btn-explore w-100 rounded-pill mt-3">Explore Details</Link>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Destinations;
