import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';

const ExploreMap = () => {
  const navigate = useNavigate();
  const [places, setPlaces] = useState([]);
  const [filteredPlaces, setFilteredPlaces] = useState([]);
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Geolocation State
  const [userCoords, setUserCoords] = useState(null);
  const [geoLoading, setGeoLoading] = useState(false);

  // Map References
  const mapRef = useRef(null);
  const googleMapInst = useRef(null);
  const markersRef = useRef([]);
  const infoWindowRef = useRef(null);

  // 1. Haversine Formula for distance calculation
  const calculateHaversineDistance = (lat1, lon1, lat2, lon2) => {
    if (!lat1 || !lon1 || !lat2 || !lon2) return null;
    const R = 6371; // Earth radius in km
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLon = ((lon2 - lon1) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((lat1 * Math.PI) / 180) *
        Math.cos((lat2 * Math.PI) / 180) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return parseFloat((R * c).toFixed(1));
  };

  // 2. Fetch Places and Categories
  useEffect(() => {
    const loadInitialData = async () => {
      try {
        const placesRes = await api.get('/places');
        const catsRes = await api.get('/categories');
        setPlaces(placesRes.data);
        setFilteredPlaces(placesRes.data);
        setCategories(catsRes.data);
      } catch (err) {
        console.error('Error fetching explore map data:', err);
      }
    };
    loadInitialData();
  }, []);

  // 3. Obtain User Geolocation
  const requestUserLocation = () => {
    if (!navigator.geolocation) {
      alert('Geolocation is not supported by your browser.');
      return;
    }
    setGeoLoading(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setUserCoords({
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
        });
        setGeoLoading(false);
        // Center map on user's location if map exists
        if (googleMapInst.current) {
          googleMapInst.current.setCenter({
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
          });
          googleMapInst.current.setZoom(10);
        }
      },
      (error) => {
        console.warn('Geolocation access rejected by user:', error.message);
        setGeoLoading(false);
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  // Auto request location on load
  useEffect(() => {
    requestUserLocation();
  }, []);

  // 4. Update Place Distances if User Coordinates change
  const placesWithDistance = filteredPlaces.map((p) => {
    const dist = userCoords ? calculateHaversineDistance(userCoords.lat, userCoords.lng, p.latitude, p.longitude) : null;
    return { ...p, distance: dist };
  }).sort((a, b) => {
    // If distances are available, sort by nearest
    if (a.distance !== null && b.distance !== null) {
      return a.distance - b.distance;
    }
    return 0;
  });

  // 5. Handle filters (Search & Category)
  useEffect(() => {
    let result = places;

    if (selectedCategory !== 'All') {
      result = result.filter((p) => p.categoryName === selectedCategory);
    }

    if (searchQuery.trim() !== '') {
      const q = searchQuery.toLowerCase();
      result = result.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.location.toLowerCase().includes(q) ||
          p.state.toLowerCase().includes(q)
      );
    }

    setFilteredPlaces(result);
  }, [searchQuery, selectedCategory, places]);

  // 6. Load Google Maps SDK
  useEffect(() => {
    const loadMapScript = () => {
      if (window.google && window.google.maps) {
        initializeMap();
        return;
      }

      const apiKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '';
      const script = document.createElement('script');
      script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&callback=initExploreMapCallback`;
      script.async = true;
      script.defer = true;
      
      window.initExploreMapCallback = () => {
        initializeMap();
      };

      document.head.appendChild(script);

      return () => {
        // Cleanup global callback on unmount
        window.initExploreMapCallback = null;
      };
    };

    loadMapScript();
  }, [filteredPlaces]); // Re-initialize pins if filtered places list updates

  // 7. Initialize Map and Markers
  const initializeMap = () => {
    if (!mapRef.current || !window.google || !window.google.maps) return;

    // Default center in India if user coordinates are not set
    const defaultCenter = userCoords || { lat: 20.5937, lng: 78.9629 };
    const defaultZoom = userCoords ? 10 : 5;

    // Instantiate Google Map
    const map = new window.google.maps.Map(mapRef.current, {
      center: defaultCenter,
      zoom: defaultZoom,
      styles: [
        {
          featureType: 'poi',
          elementType: 'labels',
          stylers: [{ visibility: 'off' }], // Hide commercial points of interest for cleaner look
        },
      ],
      mapTypeControl: false,
      streetViewControl: false,
      fullscreenControl: false,
    });

    googleMapInst.current = map;
    infoWindowRef.current = new window.google.maps.InfoWindow();

    // Clear old markers
    markersRef.current.forEach((m) => m.setMap(null));
    markersRef.current = [];

    // Plot user location marker if GPS is active
    if (userCoords) {
      new window.google.maps.Marker({
        position: userCoords,
        map: map,
        title: 'Your Location',
        icon: {
          path: window.google.maps.SymbolPath.CIRCLE,
          scale: 10,
          fillColor: '#007bff',
          fillOpacity: 1,
          strokeColor: '#ffffff',
          strokeWeight: 2,
        },
      });
    }

    // Plot tourist places markers
    filteredPlaces.forEach((place) => {
      if (!place.latitude || !place.longitude) return;

      const marker = new window.google.maps.Marker({
        position: { lat: place.latitude, lng: place.longitude },
        map: map,
        title: place.name,
        animation: window.google.maps.Animation.DROP,
      });

      // Bind click event to trigger customized infowindow
      marker.addListener('click', () => {
        showPlaceInfoWindow(place, marker);
      });

      markersRef.current.push(marker);
    });
  };

  // 8. Custom Info Window Template
  const showPlaceInfoWindow = (place, marker) => {
    if (!infoWindowRef.current || !googleMapInst.current) return;

    const imgUrl = place.imageUrls?.[0] || 'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?w=800';
    const contentString = `
      <div style="font-family: inherit; width: 220px; padding: 5px;">
        <img src="${imgUrl}" alt="${place.name}" style="width: 100%; height: 110px; object-fit: cover; border-radius: 8px; margin-bottom: 8px;" />
        <span style="font-size: 10px; font-weight: bold; color: var(--primary-green); text-transform: uppercase;">${place.categoryName}</span>
        <h6 style="font-weight: bold; margin: 2px 0 4px 0; color: #333;">${place.name}</h6>
        <p style="font-size: 11px; color: #666; margin: 0 0 6px 0;"><i class="bi bi-geo-alt-fill"></i> ${place.location}, ${place.state}</p>
        <div style="display: flex; justify-content: space-between; align-items: center;">
          <span style="font-weight: bold; font-size: 12px; color: #ffa500;"><i class="bi bi-star-fill"></i> ${place.averageRating || 'New'}</span>
          <button id="infowindow-btn-${place.id}" style="background-color: #007bff; color: white; border: none; font-size: 11px; padding: 4px 10px; border-radius: 20px; cursor: pointer; font-weight: 600;">View Details</button>
        </div>
      </div>
    `;

    infoWindowRef.current.setContent(contentString);
    infoWindowRef.current.open(googleMapInst.current, marker);

    // Bind event handler inside HTML info window string after insertion to DOM
    window.google.maps.event.addListener(infoWindowRef.current, 'domready', () => {
      const btn = document.getElementById(`infowindow-btn-${place.id}`);
      if (btn) {
        btn.addEventListener('click', () => {
          navigate(`/places/${place.id}`);
        });
      }
    });
  };

  // 9. Focus place on list click
  const handlePlaceCardClick = (place) => {
    if (!googleMapInst.current || !place.latitude || !place.longitude) return;

    const coords = { lat: place.latitude, lng: place.longitude };
    googleMapInst.current.setCenter(coords);
    googleMapInst.current.setZoom(13);

    // Find marker instance to open popup
    const matchMarker = markersRef.current.find(
      (m) =>
        Math.abs(m.getPosition().lat() - place.latitude) < 0.0001 &&
        Math.abs(m.getPosition().lng() - place.longitude) < 0.0001
    );

    if (matchMarker) {
      showPlaceInfoWindow(place, matchMarker);
    }
  };

  return (
    <div className="container-fluid p-0 d-flex flex-column" style={{ height: 'calc(100vh - 66px)', overflow: 'hidden' }}>
      {/* Search and Category Pills Bar */}
      <div className="bg-white shadow-sm px-4 py-3 z-3 border-bottom d-flex flex-column flex-md-row gap-3 align-items-center justify-content-between">
        <div className="d-flex align-items-center gap-2 flex-grow-1 w-100">
          <div className="position-relative flex-grow-1">
            <i className="bi bi-search position-absolute top-50 start-0 translate-middle-y ms-3 text-muted"></i>
            <input
              type="text"
              placeholder="Search destinations by name or state..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="form-control rounded-pill ps-5 border-light-subtle shadow-sm py-2"
              style={{ fontSize: '15px' }}
            />
          </div>
          <button
            onClick={requestUserLocation}
            className={`btn rounded-pill px-3 d-flex align-items-center gap-1 py-2 fw-semibold ${
              userCoords ? 'btn-success text-white' : 'btn-outline-primary'
            }`}
            disabled={geoLoading}
          >
            {geoLoading ? (
              <span className="spinner-border spinner-border-sm" role="status"></span>
            ) : (
              <i className="bi bi-geo-fill"></i>
            )}
            <span className="d-none d-lg-inline">{userCoords ? 'GPS Active' : 'Locate Me'}</span>
          </button>
        </div>

        {/* Filter Pills */}
        <div className="d-flex gap-2 overflow-auto w-100 w-md-auto py-1 justify-content-md-end">
          <button
            onClick={() => setSelectedCategory('All')}
            className={`btn rounded-pill px-3 py-1 fw-semibold btn-sm ${
              selectedCategory === 'All' ? 'btn-primary text-white' : 'btn-outline-secondary'
            }`}
          >
            All
          </button>
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.name)}
              className={`btn rounded-pill px-3 py-1 fw-semibold btn-sm text-nowrap ${
                selectedCategory === cat.name ? 'btn-primary text-white' : 'btn-outline-secondary'
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>
      </div>

      {/* Map and Sidebar Grid */}
      <div className="row g-0 flex-grow-1 w-100 m-0">
        {/* Left Sidebar List */}
        <div className="col-md-4 col-lg-3 bg-light border-end d-flex flex-column h-100 overflow-auto" style={{ maxHeight: '100%' }}>
          <div className="p-3 bg-white border-bottom d-flex align-items-center justify-content-between">
            <span className="fw-bold text-dark">{placesWithDistance.length} Places Found</span>
            {userCoords && <span className="badge bg-info-subtle text-info rounded-pill px-2 py-1">Sorted by Distance</span>}
          </div>

          <div className="p-3 d-flex flex-column gap-3">
            {placesWithDistance.length === 0 ? (
              <div className="text-center py-5">
                <i className="bi bi-geo-alt text-muted fs-1"></i>
                <p className="text-muted mt-2">No matching destinations found.</p>
              </div>
            ) : (
              placesWithDistance.map((p) => (
                <div
                  key={p.id}
                  onClick={() => handlePlaceCardClick(p)}
                  className="card border-0 shadow-sm cursor-pointer hover-card"
                  style={{ borderRadius: '12px', overflow: 'hidden', cursor: 'pointer', transition: 'transform 0.2s' }}
                >
                  <img
                    src={p.imageUrls?.[0] || 'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?w=800'}
                    alt={p.name}
                    style={{ height: '140px', objectFit: 'cover' }}
                  />
                  <div className="card-body p-3">
                    <span className="text-uppercase small fw-bold text-success" style={{ fontSize: '10px' }}>
                      {p.categoryName}
                    </span>
                    <h6 className="fw-bold text-dark mt-1 mb-1 text-truncate">{p.name}</h6>
                    <p className="text-muted small mb-2 text-truncate">
                      <i className="bi bi-geo-alt-fill text-danger me-1"></i>
                      {p.location}, {p.state}
                    </p>

                    <div className="d-flex justify-content-between align-items-center border-top pt-2 mt-1">
                      <span className="text-warning fw-bold small">
                        <i className="bi bi-star-fill text-warning me-1"></i>
                        {p.averageRating ? p.averageRating.toFixed(1) : 'New'}
                      </span>
                      {p.distance !== null ? (
                        <span className="badge bg-success-subtle text-success rounded-pill fw-bold">
                          <i className="bi bi-pin-map me-1"></i>
                          {p.distance} km
                        </span>
                      ) : (
                        <span className="text-muted small" style={{ fontSize: '11px' }}>
                          Dist. unknown
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Right Map Canvas Container */}
        <div className="col-md-8 col-lg-9 h-100 p-0 relative">
          <div ref={mapRef} style={{ width: '100%', height: '100%', minHeight: '400px' }}></div>
        </div>
      </div>
    </div>
  );
};

export default ExploreMap;
