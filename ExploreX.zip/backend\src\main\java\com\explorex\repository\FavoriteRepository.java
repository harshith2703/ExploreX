package com.explorex.repository;

import com.explorex.entity.Favorite;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Spring Data Repository for the {@link Favorite} entity.
 */
@Repository
public interface FavoriteRepository extends JpaRepository<Favorite, Long> {
    List<Favorite> findByUserId(Long userId);
    Optional<Favorite> findByUserIdAndTouristPlaceId(Long userId, Long touristPlaceId);
    Boolean existsByUserIdAndTouristPlaceId(Long userId, Long touristPlaceId);
    void deleteByUserIdAndTouristPlaceId(Long userId, Long touristPlaceId);
}
