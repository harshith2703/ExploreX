package com.explorex.repository;

import com.explorex.entity.Review;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Spring Data Repository for the {@link Review} entity.
 */
@Repository
public interface ReviewRepository extends JpaRepository<Review, Long> {
    List<Review> findByTouristPlaceId(Long touristPlaceId);
    List<Review> findByUserId(Long userId);
    Boolean existsByUserIdAndTouristPlaceId(Long userId, Long touristPlaceId);

    @Query("SELECT AVG(r.rating) FROM Review r WHERE r.touristPlace.id = :placeId")
    Double getAverageRatingForPlace(@Param("placeId") Long placeId);
}
