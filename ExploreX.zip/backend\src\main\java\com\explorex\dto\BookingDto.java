package com.explorex.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDateTime;

/**
 * DTO representing detailed booking details.
 */
public class BookingDto {

    private Long id;
    private Long userId;
    private String username;
    private String userEmail;

    @NotNull(message = "Tourist place ID is required")
    private Long touristPlaceId;
    private String touristPlaceName;

    @NotNull(message = "Booking date and time is required")
    private LocalDateTime bookingDate;

    @NotNull(message = "Number of people is required")
    @Min(value = 1, message = "There must be at least 1 person booking")
    private Integer numberOfPeople;

    private String status;
    private String specialRequests;
    private LocalDateTime createdAt;

    public BookingDto() {}

    public BookingDto(Long id, Long userId, String username, String userEmail, Long touristPlaceId, String touristPlaceName, LocalDateTime bookingDate, Integer numberOfPeople, String status, String specialRequests, LocalDateTime createdAt) {
        this.id = id;
        this.userId = userId;
        this.username = username;
        this.userEmail = userEmail;
        this.touristPlaceId = touristPlaceId;
        this.touristPlaceName = touristPlaceName;
        this.bookingDate = bookingDate;
        this.numberOfPeople = numberOfPeople;
        this.status = status;
        this.specialRequests = specialRequests;
        this.createdAt = createdAt;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public Long getTouristPlaceId() {
        return touristPlaceId;
    }

    public void setTouristPlaceId(Long touristPlaceId) {
        this.touristPlaceId = touristPlaceId;
    }

    public String getTouristPlaceName() {
        return touristPlaceName;
    }

    public void setTouristPlaceName(String touristPlaceName) {
        this.touristPlaceName = touristPlaceName;
    }

    public LocalDateTime getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(LocalDateTime bookingDate) {
        this.bookingDate = bookingDate;
    }

    public Integer getNumberOfPeople() {
        return numberOfPeople;
    }

    public void setNumberOfPeople(Integer numberOfPeople) {
        this.numberOfPeople = numberOfPeople;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSpecialRequests() {
        return specialRequests;
    }

    public void setSpecialRequests(String specialRequests) {
        this.specialRequests = specialRequests;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public String toString() {
        return "BookingDto(id='" + id + "', userId='" + userId + "', username='" + username + "', userEmail='" + userEmail + "', touristPlaceId='" + touristPlaceId + "', touristPlaceName='" + touristPlaceName + "', bookingDate='" + bookingDate + "', numberOfPeople='" + numberOfPeople + "', status='" + status + "', specialRequests='" + specialRequests + "', createdAt='" + createdAt + "')";
    }
}
