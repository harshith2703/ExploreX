package com.explorex.service;

import com.explorex.dto.ReviewDto;

import java.util.List;

/**
 * Service interface for Review operations.
 */
public interface ReviewService {
    ReviewDto addReview(Long userId, ReviewDto reviewDto);
    List<ReviewDto> getReviewsByPlaceId(Long placeId);
    List<ReviewDto> getReviewsByUserId(Long userId);
    void deleteReview(Long id);
}
