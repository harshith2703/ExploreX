import React, { useState } from 'react';
import api from '../services/api';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSuccess('');
    setError('');

    const { name, email, subject, message } = formData;
    if (!name || !email || !subject || !message) {
      setError('Please populate all the contact form fields.');
      return;
    }

    setLoading(true);
    try {
      await api.post('/contact/submit', formData);
      setSuccess('Your support message was submitted successfully! Our agents will contact you shortly.');
      setFormData({ name: '', email: '', subject: '', message: '' });
    } catch (err) {
      setError('Error submitting support ticket. Please check connection.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container py-5">
      {/* 1. Page Header */}
      <div className="text-center mb-5">
        <h1 className="fw-bold display-4">Contact Support</h1>
        <p className="text-muted">Have inquiries regarding customized tour packages? Fill out the form below</p>
      </div>

      <div className="row g-5">
        {/* Left Side: Contact Form Card */}
        <div className="col-lg-7">
          <div className="card shadow-sm border-0 p-4" style={{ borderRadius: '16px' }}>
            <h4 className="fw-bold text-dark mb-4"><i className="bi bi-envelope-paper text-primary me-2"></i>Send Support Query</h4>

            {success && <div className="alert alert-success border-0 text-center rounded-pill py-2 small">{success}</div>}
            {error && <div className="alert alert-danger border-0 text-center rounded-pill py-2 small">{error}</div>}

            <form onSubmit={handleSubmit}>
              <div className="row">
                <div className="col-md-6 mb-3">
                  <label className="form-label small fw-semibold text-secondary">Your Name</label>
                  <input
                    type="text"
                    className="form-control bg-light border-0 py-2"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="Enter your name"
                  />
                </div>
                <div className="col-md-6 mb-3">
                  <label className="form-label small fw-semibold text-secondary">Email Address</label>
                  <input
                    type="email"
                    className="form-control bg-light border-0 py-2"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="name@example.com"
                  />
                </div>
              </div>

              <div className="mb-3">
                <label className="form-label small fw-semibold text-secondary">Subject</label>
                <input
                  type="text"
                  className="form-control bg-light border-0 py-2"
                  name="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  placeholder="e.g. Booking adjustments, pricing plan guides..."
                />
              </div>

              <div className="mb-4">
                <label className="form-label small fw-semibold text-secondary">Message Details</label>
                <textarea
                  rows="5"
                  className="form-control bg-light border-0"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  placeholder="Explain your travel issue in detail..."
                ></textarea>
              </div>

              <button
                type="submit"
                className="btn btn-explore w-100 py-2 rounded-pill fw-bold"
                disabled={loading}
              >
                {loading ? (
                  <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                ) : 'Submit Inquiry'}
              </button>
            </form>
          </div>
        </div>

        {/* Right Side: Contact info & Maps */}
        <div className="col-lg-5">
          <div className="card shadow-sm border-0 p-4 mb-4" style={{ borderRadius: '16px' }}>
            <h4 className="fw-bold text-dark mb-4">Support Channels</h4>
            <div className="d-flex flex-column gap-3">
              <div className="d-flex gap-3 align-items-start">
                <div className="icon-circle bg-light-green text-success"><i className="bi bi-geo-alt-fill"></i></div>
                <div>
                  <h6 className="fw-bold mb-0">Panaji Support Desk</h6>
                  <p className="text-muted small mb-0">Patto Plaza, Panaji, Goa - 403001</p>
                </div>
              </div>
              <div className="d-flex gap-3 align-items-start">
                <div className="icon-circle bg-light-green text-success"><i className="bi bi-telephone-fill"></i></div>
                <div>
                  <h6 className="fw-bold mb-0">Helpline Numbers</h6>
                  <p className="text-muted small mb-0">+91 98765 43210 (Mon-Sat, 9AM to 6PM)</p>
                </div>
              </div>
              <div className="d-flex gap-3 align-items-start">
                <div className="icon-circle bg-light-green text-success"><i className="bi bi-envelope-fill"></i></div>
                <div>
                  <h6 className="fw-bold mb-0">Email Assistance</h6>
                  <p className="text-muted small mb-0">support@explorex.com</p>
                </div>
              </div>
            </div>
          </div>

          {/* Interactive Google Map Mock Placeholder */}
          <div className="card shadow-sm border-0 overflow-hidden" style={{ borderRadius: '16px', height: '220px' }}>
            <div className="h-100 bg-secondary-subtle d-flex flex-column align-items-center justify-content-center text-center p-3">
              <i className="bi bi-map text-primary fs-1 mb-2"></i>
              <h6 className="fw-bold mb-1">Panaji Office Map</h6>
              <p className="text-muted small mb-0">15.4909° N, 73.8278° E</p>
              <span className="badge bg-primary mt-2">Open In Maps</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
