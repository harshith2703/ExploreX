package com.explorex.controller;

import com.explorex.dto.TouristPlaceDto;
import com.explorex.service.TouristPlaceService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Controller exposing Tourist Place APIs for public searches/filters and admin-secured CRUD.
 */
@RestController
public class TouristPlaceController {

    @Autowired
    private TouristPlaceService touristPlaceService;

    // Public lookup, search, filter, and sort endpoints
    @GetMapping("/api/places")
    public ResponseEntity<List<TouristPlaceDto>> searchAndFilterPlaces(
            @RequestParam(required = false) Long categoryId,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String sortBy) {
        List<TouristPlaceDto> places = touristPlaceService.searchAndFilterTouristPlaces(categoryId, keyword, sortBy);
        return ResponseEntity.ok(places);
    }

    @GetMapping("/api/places/{id}")
    public ResponseEntity<TouristPlaceDto> getTouristPlaceById(@PathVariable Long id) {
        TouristPlaceDto place = touristPlaceService.getTouristPlaceById(id);
        return ResponseEntity.ok(place);
    }

    // Admin secured write endpoints
    @PostMapping("/api/admin/places")
    public ResponseEntity<TouristPlaceDto> createTouristPlace(@Valid @RequestBody TouristPlaceDto dto) {
        TouristPlaceDto savedPlace = touristPlaceService.createTouristPlace(dto);
        return new ResponseEntity<>(savedPlace, HttpStatus.CREATED);
    }

    @PutMapping("/api/admin/places/{id}")
    public ResponseEntity<TouristPlaceDto> updateTouristPlace(
            @PathVariable Long id,
            @Valid @RequestBody TouristPlaceDto dto) {
        TouristPlaceDto updatedPlace = touristPlaceService.updateTouristPlace(id, dto);
        return ResponseEntity.ok(updatedPlace);
    }

    @DeleteMapping("/api/admin/places/{id}")
    public ResponseEntity<Map<String, String>> deleteTouristPlace(@PathVariable Long id) {
        touristPlaceService.deleteTouristPlace(id);
        Map<String, String> response = new HashMap<>();
        response.put("message", "Tourist place deleted successfully!");
        return ResponseEntity.ok(response);
    }
}
