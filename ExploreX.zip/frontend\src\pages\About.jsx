import React from 'react';

const About = () => {
  return (
    <div className="container py-5">
      {/* 1. Page Header */}
      <div className="text-center mb-5">
        <h1 className="fw-bold display-4">About ExploreX</h1>
        <p className="text-muted">A project designed to simplify travel exploration, review aggregation, and tour booking reservations</p>
      </div>

      {/* 2. Brand Mission Section */}
      <div className="row align-items-center g-5 mb-5">
        <div className="col-md-6">
          <span className="text-uppercase small fw-bold text-success">Who We Are</span>
          <h2 className="fw-bold mt-2 mb-4 text-dark">Our Mission & Values</h2>
          <p className="text-secondary leading-relaxed mb-3">
            ExploreX is a Tourist Information System developed as a final year college project to address modern tourism challenges. Our mission is to build a highly optimized, full-stack database application that connects tourists to scenic places, simplifies booking requests, and aggregates reviews.
          </p>
          <p className="text-secondary leading-relaxed">
            By mapping verified locations, providing filter matrices, and enabling dynamic sort patterns, we help travelers discover unique historical spots, beaches, hills, and wildlife sanctuaries across the country.
          </p>
        </div>
        <div className="col-md-6">
          <div className="card border-0 shadow-lg overflow-hidden" style={{ borderRadius: '20px' }}>
            <img
              src="https://images.unsplash.com/photo-1524492412937-b28074a5d7da?w=800"
              alt="Indian Heritage Taj"
              style={{ height: '350px', objectFit: 'cover' }}
            />
          </div>
        </div>
      </div>

      {/* 3. Core Values Grid */}
      <div className="row g-4 mb-5 text-center">
        <div className="col-md-4">
          <div className="card shadow-sm border-0 p-4 h-100" style={{ borderRadius: '16px' }}>
            <div className="icon-circle mx-auto mb-3 bg-light-green text-success">
              <i className="bi bi-shield-check fs-4"></i>
            </div>
            <h5 className="fw-bold text-dark">Verified Spots</h5>
            <p className="text-muted small mb-0">Our administrators review and audit tourist place details to ensure location coordinates, descriptions, and photo links are completely valid.</p>
          </div>
        </div>
        <div className="col-md-4">
          <div className="card shadow-sm border-0 p-4 h-100" style={{ borderRadius: '16px' }}>
            <div className="icon-circle mx-auto mb-3 bg-light-green text-success">
              <i className="bi bi-chat-left-heart fs-4"></i>
            </div>
            <h5 className="fw-bold text-dark">Traveler Reviews</h5>
            <p className="text-muted small mb-0">A transparent review aggregation system recalculates star ratings automatically, ensuring authentic community feedback for all spots.</p>
          </div>
        </div>
        <div className="col-md-4">
          <div className="card shadow-sm border-0 p-4 h-100" style={{ borderRadius: '16px' }}>
            <div className="icon-circle mx-auto mb-3 bg-light-green text-success">
              <i className="bi bi-calendar-event fs-4"></i>
            </div>
            <h5 className="fw-bold text-dark">Guided Tours</h5>
            <p className="text-muted small mb-0">Select travel dates and book packages instantly. Our admin panel coordinates approvals and assigns custom guide requirements.</p>
          </div>
        </div>
      </div>

      {/* 4. Geography Showcase */}
      <div className="bg-light p-5 rounded-4 shadow-sm text-center">
        <h3 className="fw-bold mb-4 text-dark italic-header">Explore Diversity</h3>
        <p className="text-secondary max-w-2xl mx-auto mb-4 small">
          India's geographic diversity offers a rich collection of ecosystems: from the snowcapped mountains of the Western Himalayas and the rich biodiversity of Munnar's Western Ghats, to the golden sandy beaches of North Goa and ancient Mughal monuments in Agra.
        </p>
        <div className="row g-2 justify-content-center">
          <div className="col-3"><img src="https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=300" className="img-fluid rounded-3 shadow-sm" alt="Goa Coasts"/></div>
          <div className="col-3"><img src="https://images.unsplash.com/photo-1593693397690-362cb9666fc2?w=300" className="img-fluid rounded-3 shadow-sm" alt="Kerala Hills"/></div>
          <div className="col-3"><img src="https://images.unsplash.com/photo-1564507592333-c60657eea523?w=300" className="img-fluid rounded-3 shadow-sm" alt="Agra Fort"/></div>
          <div className="col-3"><img src="https://images.unsplash.com/photo-1615959189255-75e11ad9fb5c?w=300" className="img-fluid rounded-3 shadow-sm" alt="Safari Wilds"/></div>
        </div>
      </div>
    </div>
  );
};

export default About;
