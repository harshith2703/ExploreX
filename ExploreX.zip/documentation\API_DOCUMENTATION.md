# ExploreX – REST API Documentation

All request payloads and response bodies conform to the JSON standard. Secured endpoints require a valid `Bearer <Token>` string in the `Authorization` header.

---

## 1. Authentication Endpoints

### Login User
- **URL**: `/api/auth/login`
- **HTTP Method**: `POST`
- **Security**: Public
- **Request Body (`AuthRequest`)**:
  ```json
  {
    "usernameOrEmail": "user",
    "password": "User@123"
  }
  ```
- **Response Body (`AuthResponse`)**:
  ```json
  {
    "accessToken": "eyJhbGciOiJIUzI1NiJ9...",
    "tokenType": "Bearer",
    "id": 2,
    "username": "user",
    "email": "user@explorex.com",
    "roles": ["ROLE_USER"]
  }
  ```

### Register User
- **URL**: `/api/auth/register`
- **HTTP Method**: `POST`
- **Security**: Public
- **Request Body (`RegisterRequest`)**:
  ```json
  {
    "username": "traveler",
    "email": "traveler@test.com",
    "password": "Password@123",
    "firstName": "Dave",
    "lastName": "Smith",
    "phoneNumber": "9000011111"
  }
  ```
- **Response**: `201 Created` with confirmation message.

---

## 2. User Profile Settings

### Get Current Profile
- **URL**: `/api/user/profile`
- **HTTP Method**: `GET`
- **Security**: Authenticated User
- **Response Body (`UserProfileDto`)**:
  ```json
  {
    "id": 2,
    "username": "user",
    "email": "user@explorex.com",
    "firstName": "John",
    "lastName": "Doe",
    "phoneNumber": "9876543210",
    "profilePicture": "https://api.dicebear.com/...",
    "roles": ["ROLE_USER"]
  }
  ```

### Update Profile
- **URL**: `/api/user/profile/update`
- **HTTP Method**: `PUT`
- **Security**: Authenticated User
- **Request Body (`UserProfileDto`)**: Updates first/last name, phone, email, and profile avatar.

### Change Password
- **URL**: `/api/user/change-password`
- **HTTP Method**: `PUT`
- **Security**: Authenticated User
- **Request Body (`ChangePasswordRequest`)**:
  ```json
  {
    "oldPassword": "User@123",
    "newPassword": "NewPassword@123"
  }
  ```

---

## 3. Categories Management

### Get Categories
- **URL**: `/api/categories`
- **HTTP Method**: `GET`
- **Security**: Public

### Create Category (Admin Only)
- **URL**: `/api/admin/categories`
- **HTTP Method**: `POST`
- **Request Body (`CategoryDto`)**:
  ```json
  {
    "name": "Historical Monuments",
    "description": "Monuments and ancient architecture structures."
  }
  ```

---

## 4. Tourist Places Catalog

### Search, Filter, & Sort Places
- **URL**: `/api/places`
- **HTTP Method**: `GET`
- **Security**: Public
- **Query Parameters**:
  - `categoryId` (Optional): ID to filter.
  - `keyword` (Optional): Text matching across name, location, district, state.
  - `sortBy` (Optional): `rating`, `newest`, `popularity`, `alphabetical`.
- **Response**: List of `TouristPlaceDto` objects.

### Get Place Details
- **URL**: `/api/places/{id}`
- **HTTP Method**: `GET`
- **Security**: Public

### Create Tourist Place (Admin Only)
- **URL**: `/api/admin/places`
- **HTTP Method**: `POST`
- **Request Body (`TouristPlaceDto`)**:
  ```json
  {
    "name": "Vagator Beach",
    "description": "Sunset beach in North Goa...",
    "location": "Vagator",
    "state": "Goa",
    "district": "North Goa",
    "categoryId": 1,
    "imageUrls": ["https://images..."]
  }
  ```

---

## 5. Review & Rating Management

### Submit Review
- **URL**: `/api/reviews`
- **HTTP Method**: `POST`
- **Security**: Authenticated User
- **Request Body (`ReviewDto`)**:
  ```json
  {
    "rating": 5,
    "comment": "Perfect location! Sunset cliffs were amazing.",
    "touristPlaceId": 1
  }
  ```

---

## 6. Booking Guided Tours

### Create Tour Booking
- **URL**: `/api/bookings`
- **HTTP Method**: `POST`
- **Security**: Authenticated User
- **Request Body (`BookingDto`)**:
  ```json
  {
    "touristPlaceId": 2,
    "bookingDate": "2026-12-15T09:00:00",
    "numberOfPeople": 3,
    "specialRequests": "We require a local Hindi speaking guide."
  }
  ```

### Cancel Booking
- **URL**: `/api/bookings/{id}/cancel`
- **HTTP Method**: `PUT`
- **Security**: Authenticated Booking Author

---

## 7. Support Contact Forms

### Submit Query
- **URL**: `/api/contact/submit`
- **HTTP Method**: `POST`
- **Security**: Public
- **Request Body (`ContactMessageDto`)**:
  ```json
  {
    "name": "Alex Johnson",
    "email": "alex@inquiries.com",
    "subject": "Student Tour Packages",
    "message": "Do you offer tailored package rates for student tour groups?"
  }
  ```

---

## 8. Admin Controls

### Get Statistics Summary
- **URL**: `/api/admin/stats`
- **HTTP Method**: `GET`
- **Security**: Admin Only

### List All Users
- **URL**: `/api/admin/users`
- **HTTP Method**: `GET`
- **Security**: Admin Only

### Terminate User
- **URL**: `/api/admin/users/{id}`
- **HTTP Method**: `DELETE`
- **Security**: Admin Only
