package com.explorex.service;

import com.explorex.dto.ContactMessageDto;

import java.util.List;

/**
 * Service interface for Contact support message operations.
 */
public interface ContactMessageService {
    ContactMessageDto submitMessage(ContactMessageDto dto);
    List<ContactMessageDto> getAllMessages();
    List<ContactMessageDto> getMessagesByReplyStatus(Boolean replied);
    void replyToMessage(Long messageId);
}
