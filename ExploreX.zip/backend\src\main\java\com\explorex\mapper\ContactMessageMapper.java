package com.explorex.mapper;

import com.explorex.dto.ContactMessageDto;
import com.explorex.entity.ContactMessage;

/**
 * Mapper utility to convert between ContactMessage entities and DTOs.
 */
public class ContactMessageMapper {

    public static ContactMessageDto toDto(ContactMessage message) {
        if (message == null) {
            return null;
        }
        return new ContactMessageDto(
                message.getId(),
                message.getName(),
                message.getEmail(),
                message.getSubject(),
                message.getMessage(),
                message.getReplied(),
                message.getCreatedAt()
        );
    }

    public static ContactMessage toEntity(ContactMessageDto dto) {
        if (dto == null) {
            return null;
        }
        ContactMessage message = new ContactMessage();
        message.setId(dto.getId());
        message.setName(dto.getName());
        message.setEmail(dto.getEmail());
        message.setSubject(dto.getSubject());
        message.setMessage(dto.getMessage());
        if (dto.getReplied() != null) {
            message.setReplied(dto.getReplied());
        }
        return message;
    }
}
