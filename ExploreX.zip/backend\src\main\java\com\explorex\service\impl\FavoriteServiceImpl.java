package com.explorex.service.impl;

import com.explorex.dto.TouristPlaceDto;
import com.explorex.entity.Favorite;
import com.explorex.entity.TouristPlace;
import com.explorex.entity.User;
import com.explorex.exception.BadRequestException;
import com.explorex.exception.ResourceNotFoundException;
import com.explorex.mapper.TouristPlaceMapper;
import com.explorex.repository.FavoriteRepository;
import com.explorex.repository.TouristPlaceRepository;
import com.explorex.repository.UserRepository;
import com.explorex.service.FavoriteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Service implementation for Favorite operations.
 */
@Service
public class FavoriteServiceImpl implements FavoriteService {

    @Autowired
    private FavoriteRepository favoriteRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private TouristPlaceRepository touristPlaceRepository;

    @Override
    @Transactional
    public void addFavorite(Long userId, Long placeId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));

        TouristPlace place = touristPlaceRepository.findById(placeId)
                .orElseThrow(() -> new ResourceNotFoundException("TouristPlace", "id", placeId));

        if (favoriteRepository.existsByUserIdAndTouristPlaceId(userId, placeId)) {
            throw new BadRequestException("Place is already in your favorites!");
        }

        Favorite favorite = new Favorite();
        favorite.setUser(user);
        favorite.setTouristPlace(place);
        favoriteRepository.save(favorite);
    }

    @Override
    @Transactional
    public void removeFavorite(Long userId, Long placeId) {
        Favorite favorite = favoriteRepository.findByUserIdAndTouristPlaceId(userId, placeId)
                .orElseThrow(() -> new ResourceNotFoundException("Favorite not found for this user and place"));
        favoriteRepository.delete(favorite);
    }

    @Override
    public List<TouristPlaceDto> getFavoritesByUser(Long userId) {
        if (!userRepository.existsById(userId)) {
            throw new ResourceNotFoundException("User", "id", userId);
        }
        return favoriteRepository.findByUserId(userId).stream()
                .map(favorite -> TouristPlaceMapper.toDto(favorite.getTouristPlace()))
                .collect(Collectors.toList());
    }

    @Override
    public Boolean isFavorite(Long userId, Long placeId) {
        return favoriteRepository.existsByUserIdAndTouristPlaceId(userId, placeId);
    }
}
