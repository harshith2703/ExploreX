package com.explorex.service;

import com.explorex.dto.ChangePasswordRequest;
import com.explorex.dto.UserProfileDto;

import java.util.List;

/**
 * Service interface for user profile and management operations.
 */
public interface UserService {
    UserProfileDto getUserProfile(Long id);
    UserProfileDto updateUserProfile(Long id, UserProfileDto profileDto);
    void changePassword(Long id, ChangePasswordRequest request);
    void forgotPassword(String email);
    List<UserProfileDto> getAllUsers();
    void deleteUser(Long id);
}
