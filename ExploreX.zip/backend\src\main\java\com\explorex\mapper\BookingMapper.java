package com.explorex.mapper;

import com.explorex.dto.BookingDto;
import com.explorex.entity.Booking;

/**
 * Mapper utility to convert between Booking entities and DTOs.
 */
public class BookingMapper {

    public static BookingDto toDto(Booking booking) {
        if (booking == null) {
            return null;
        }

        BookingDto dto = new BookingDto();
        dto.setId(booking.getId());
        dto.setBookingDate(booking.getBookingDate());
        dto.setNumberOfPeople(booking.getNumberOfPeople());
        dto.setStatus(booking.getStatus());
        dto.setSpecialRequests(booking.getSpecialRequests());
        dto.setCreatedAt(booking.getCreatedAt());

        if (booking.getUser() != null) {
            dto.setUserId(booking.getUser().getId());
            dto.setUsername(booking.getUser().getUsername());
            dto.setUserEmail(booking.getUser().getEmail());
        }

        if (booking.getTouristPlace() != null) {
            dto.setTouristPlaceId(booking.getTouristPlace().getId());
            dto.setTouristPlaceName(booking.getTouristPlace().getName());
        }

        return dto;
    }

    public static Booking toEntity(BookingDto dto) {
        if (dto == null) {
            return null;
        }

        Booking booking = new Booking();
        booking.setId(dto.getId());
        booking.setBookingDate(dto.getBookingDate());
        booking.setNumberOfPeople(dto.getNumberOfPeople());
        booking.setStatus(dto.getStatus());
        booking.setSpecialRequests(dto.getSpecialRequests());
        // User and TouristPlace will be resolved in Service layer
        return booking;
    }
}
