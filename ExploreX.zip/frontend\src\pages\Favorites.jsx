import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../services/api';

const Favorites = () => {
  const [favorites, setFavorites] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchFavorites = async () => {
    try {
      const res = await api.get('/favorites/my-favorites');
      setFavorites(res.data);
    } catch (err) {
      console.error('Error fetching favorites list:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchFavorites();
  }, []);

  const handleRemove = async (placeId) => {
    try {
      await api.delete(`/favorites/remove?placeId=${placeId}`);
      // Remove bookmarked item from state
      setFavorites(favorites.filter(fav => fav.id !== placeId));
    } catch (err) {
      console.error('Error removing bookmark:', err);
    }
  };

  return (
    <div className="container py-5">
      <div className="text-center mb-5">
        <h1 className="fw-bold display-4">Saved Wishlist</h1>
        <p className="text-muted">Browse through destinations you have bookmarked for your future travel plans</p>
      </div>

      {loading ? (
        <div className="text-center py-5">
          <div className="spinner-border text-danger" role="status" style={{ width: '3rem', height: '3rem' }}>
            <span className="visually-hidden">Loading wishlist...</span>
          </div>
        </div>
      ) : favorites.length === 0 ? (
        <div className="card shadow-sm border-0 p-5 text-center max-w-lg mx-auto" style={{ borderRadius: '16px' }}>
          <i className="bi bi-heartbreak text-muted" style={{ fontSize: '4rem' }}></i>
          <h3 className="fw-bold mt-3">Wishlist is Empty</h3>
          <p className="text-muted">You haven't bookmarked any tourist spots yet. Start exploring and click the wishlist heart on any place details card!</p>
          <Link to="/destinations" className="btn btn-explore mx-auto mt-2 rounded-pill px-4">Browse Places</Link>
        </div>
      ) : (
        <div className="row g-4">
          {favorites.map((place) => (
            <div className="col-md-4" key={place.id}>
              <div className="card explore-card border-0 h-100 shadow-sm">
                <div className="position-relative">
                  <img
                    src={place.imageUrls?.[0] || 'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?w=800'}
                    alt={place.name}
                    className="card-img-top"
                    style={{ height: '220px', objectFit: 'cover' }}
                  />
                  <div className="position-absolute top-0 end-0 m-3">
                    <button
                      onClick={() => handleRemove(place.id)}
                      className="btn btn-light rounded-circle shadow-sm border-0 d-flex align-items-center justify-content-center"
                      style={{ width: '40px', height: '40px', color: 'var(--primary-blue)' }}
                      title="Remove from favorites"
                    >
                      <i className="bi bi-heart-fill text-danger fs-5"></i>
                    </button>
                  </div>
                </div>
                <div className="card-body p-4 d-flex flex-column">
                  <span className="text-uppercase small fw-bold text-success mb-2">{place.categoryName}</span>
                  <h4 className="card-title fw-bold text-dark mb-1">{place.name}</h4>
                  <p className="text-secondary small mb-3"><i className="bi bi-geo-alt-fill text-danger me-1"></i>{place.location}, {place.state}</p>
                  <p className="text-muted small flex-grow-1 card-text-truncate" style={{ display: '-webkit-box', WebkitLineClamp: 3, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
                    {place.description}
                  </p>
                  <Link to={`/places/${place.id}`} className="btn btn-explore w-100 rounded-pill mt-3">Explore Details</Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Favorites;
