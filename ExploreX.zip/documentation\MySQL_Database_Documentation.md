# ExploreX - MySQL Database & API Mapping Documentation

This document serves as the official Database Schema & API Mapping guide for the **ExploreX Tourist Information System**. It connects the REST API endpoints defined in the Swagger UI documentation to their corresponding MySQL 8.0 database structures and operations.

---

## 1. Database Entity-Relationship Diagram (ERD)

The following Mermaid diagram represents the MySQL relational database schema:

```mermaid
erDiagram
    users ||--o{ user_roles : has
    roles ||--o{ user_roles : assigned_to
    users ||--o{ bookings : places
    users ||--o{ reviews : writes
    users ||--o{ favorites : bookmarks
    categories ||--o{ tourist_places : classifies
    tourist_places ||--o{ images : contains
    tourist_places ||--o{ bookings : booked_for
    tourist_places ||--o{ reviews : rated_by
    tourist_places ||--o{ favorites : bookmarked_by

    users {
        bigint id PK
        varchar username UK
        varchar email UK
        varchar password
        varchar first_name
        varchar last_name
        varchar phone_number
        varchar profile_picture
        datetime created_at
        datetime updated_at
    }

    roles {
        bigint id PK
        varchar name UK
    }

    user_roles {
        bigint user_id FK
        bigint role_id FK
    }

    categories {
        bigint id PK
        varchar name UK
        text description
        datetime created_at
        datetime updated_at
    }

    tourist_places {
        bigint id PK
        varchar name
        text description
        varchar location
        varchar state
        varchar district
        double average_rating
        double latitude
        double longitude
        bigint category_id FK
        datetime created_at
        datetime updated_at
    }

    images {
        bigint id PK
        varchar image_url
        bigint tourist_place_id FK
        datetime created_at
    }

    reviews {
        bigint id PK
        int rating
        text comment
        bigint user_id FK
        bigint tourist_place_id FK
        datetime created_at
    }

    favorites {
        bigint id PK
        bigint user_id FK
        bigint tourist_place_id FK
        datetime created_at
    }

    bookings {
        bigint id PK
        datetime booking_date
        int number_of_people
        varchar status
        text special_requests
        bigint user_id FK
        bigint tourist_place_id FK
        datetime created_at
        datetime updated_at
    }

    contact_messages {
        bigint id PK
        varchar name
        varchar email
        varchar subject
        text message
        boolean replied
        datetime created_at
    }
```

---

## 2. MySQL Data Dictionary (Table Schemas)

### Table: `users`
Stores user profile information and credentials.
| Column | Data Type | Nullable | Key / Constraint | Description |
| :--- | :--- | :--- | :--- | :--- |
| `id` | `BIGINT` | NO | `PRIMARY KEY` (Auto-Increment) | Unique user identifier. |
| `username` | `VARCHAR(50)` | NO | `UNIQUE` | Unique login username. |
| `email` | `VARCHAR(100)` | NO | `UNIQUE` | Unique email address. |
| `password` | `VARCHAR(255)` | NO | - | BCrypt hashed password string. |
| `first_name` | `VARCHAR(50)` | NO | - | User's first name. |
| `last_name` | `VARCHAR(50)` | YES | - | User's last name. |
| `phone_number` | `VARCHAR(20)` | YES | - | Contact phone number. |
| `profile_picture` | `VARCHAR(255)` | YES | - | Profile image URL. |
| `created_at` | `DATETIME` | NO | - | Audit trail: Record creation time. |
| `updated_at` | `DATETIME` | YES | - | Audit trail: Record last update time. |

### Table: `roles`
Stores access control roles (e.g., ROLE_USER, ROLE_ADMIN).
| Column | Data Type | Nullable | Key / Constraint | Description |
| :--- | :--- | :--- | :--- | :--- |
| `id` | `BIGINT` | NO | `PRIMARY KEY` (Auto-Increment) | Unique role identifier. |
| `name` | `VARCHAR(50)` | NO | `UNIQUE` | Role name string (`ROLE_USER`, `ROLE_ADMIN`). |

### Table: `user_roles`
Many-to-many junction table mapping users to their roles.
| Column | Data Type | Nullable | Key / Constraint | Description |
| :--- | :--- | :--- | :--- | :--- |
| `user_id` | `BIGINT` | NO | `PRIMARY KEY`, `FOREIGN KEY` | References `users(id)` (On Delete CASCADE). |
| `role_id` | `BIGINT` | NO | `PRIMARY KEY`, `FOREIGN KEY` | References `roles(id)` (On Delete CASCADE). |

### Table: `categories`
Stores categories of tourist places (e.g., Beaches, Mountains).
| Column | Data Type | Nullable | Key / Constraint | Description |
| :--- | :--- | :--- | :--- | :--- |
| `id` | `BIGINT` | NO | `PRIMARY KEY` (Auto-Increment) | Unique category identifier. |
| `name` | `VARCHAR(50)` | NO | `UNIQUE` | Name of the category. |
| `description` | `TEXT` | YES | - | Details about the category. |
| `created_at` | `DATETIME` | NO | - | Creation date. |
| `updated_at` | `DATETIME` | YES | - | Last modification date. |

### Table: `tourist_places`
Stores details of tourist places.
| Column | Data Type | Nullable | Key / Constraint | Description |
| :--- | :--- | :--- | :--- | :--- |
| `id` | `BIGINT` | NO | `PRIMARY KEY` (Auto-Increment) | Unique place identifier. |
| `name` | `VARCHAR(100)` | NO | - | Destination name. |
| `description` | `TEXT` | NO | - | Detailed description. |
| `location` | `VARCHAR(100)` | NO | - | Town/city name. |
| `state` | `VARCHAR(50)` | NO | - | Indian state. |
| `district` | `VARCHAR(50)` | NO | - | District name. |
| `average_rating` | `DOUBLE` | YES | Default: `0.0` | Computed average of user ratings. |
| `latitude` | `DOUBLE` | YES | - | Google Maps Latitude coordinates. |
| `longitude` | `DOUBLE` | YES | - | Google Maps Longitude coordinates. |
| `category_id` | `BIGINT` | NO | `FOREIGN KEY` | References `categories(id)` (On Delete Restrict). |
| `created_at` | `DATETIME` | NO | - | Creation date. |
| `updated_at` | `DATETIME` | YES | - | Last modification date. |

### Table: `images`
Stores gallery images for destinations (One-to-Many).
| Column | Data Type | Nullable | Key / Constraint | Description |
| :--- | :--- | :--- | :--- | :--- |
| `id` | `BIGINT` | NO | `PRIMARY KEY` (Auto-Increment) | Unique image identifier. |
| `image_url` | `VARCHAR(255)` | NO | - | URL of the image. |
| `tourist_place_id` | `BIGINT` | NO | `FOREIGN KEY` | References `tourist_places(id)` (On Delete CASCADE). |
| `created_at` | `DATETIME` | NO | - | Creation date. |

### Table: `reviews`
Stores tourist feedback and ratings (Many-to-One with User and Destination).
| Column | Data Type | Nullable | Key / Constraint | Description |
| :--- | :--- | :--- | :--- | :--- |
| `id` | `BIGINT` | NO | `PRIMARY KEY` (Auto-Increment) | Unique review identifier. |
| `rating` | `INT` | NO | Check: `1 <= rating <= 5` | Star rating out of 5. |
| `comment` | `TEXT` | NO | - | User review text. |
| `user_id` | `BIGINT` | NO | `FOREIGN KEY` | References `users(id)` (On Delete CASCADE). |
| `tourist_place_id` | `BIGINT` | NO | `FOREIGN KEY` | References `tourist_places(id)` (On Delete CASCADE). |
| `created_at` | `DATETIME` | NO | - | Creation date. |

### Table: `favorites`
Stores bookmarked wishlist items (User-Place unique pairs).
| Column | Data Type | Nullable | Key / Constraint | Description |
| :--- | :--- | :--- | :--- | :--- |
| `id` | `BIGINT` | NO | `PRIMARY KEY` (Auto-Increment) | Unique favorite identifier. |
| `user_id` | `BIGINT` | NO | `FOREIGN KEY` | References `users(id)` (On Delete CASCADE). |
| `tourist_place_id` | `BIGINT` | NO | `FOREIGN KEY` | References `tourist_places(id)` (On Delete CASCADE). |
| `created_at` | `DATETIME` | NO | - | Creation date. |

### Table: `bookings`
Stores tour booking requests.
| Column | Data Type | Nullable | Key / Constraint | Description |
| :--- | :--- | :--- | :--- | :--- |
| `id` | `BIGINT` | NO | `PRIMARY KEY` (Auto-Increment) | Unique booking identifier. |
| `booking_date` | `DATETIME` | NO | - | Target date of visit. |
| `number_of_people` | `INT` | NO | Check: `>= 1` | Headcount of travelers. |
| `status` | `VARCHAR(20)` | NO | Default: `'PENDING'` | Status: `PENDING`, `APPROVED`, `CANCELLED`. |
| `special_requests`| `TEXT` | YES | - | Message requests (e.g. guide needs). |
| `user_id` | `BIGINT` | NO | `FOREIGN KEY` | References `users(id)` (On Delete CASCADE). |
| `tourist_place_id` | `BIGINT` | NO | `FOREIGN KEY` | References `tourist_places(id)` (On Delete CASCADE). |
| `created_at` | `DATETIME` | NO | - | Creation date. |
| `updated_at` | `DATETIME` | YES | - | Last modification date. |

### Table: `contact_messages`
Stores contact queries submitted via the Help Desk form.
| Column | Data Type | Nullable | Key / Constraint | Description |
| :--- | :--- | :--- | :--- | :--- |
| `id` | `BIGINT` | NO | `PRIMARY KEY` (Auto-Increment) | Unique message identifier. |
| `name` | `VARCHAR(100)` | NO | - | Sender's name. |
| `email` | `VARCHAR(100)` | NO | - | Sender's email. |
| `subject` | `VARCHAR(150)` | NO | - | Inquiry topic. |
| `message` | `TEXT` | NO | - | Message body details. |
| `replied` | `BOOLEAN` | NO | Default: `FALSE` | Flag: whether admin has replied. |
| `created_at` | `DATETIME` | NO | - | Submission date. |

---

## 3. Swagger API to MySQL Table Mapping

This section maps each Swagger UI endpoint to the database tables it accesses and modifies.

### Category 1: Authentication (`/api/auth`)
| Swagger Endpoint | HTTP Method | Service Implementation | SQL Actions | Tables Modified/Read | Description |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `/api/auth/register` | `POST` | `AuthServiceImpl.registerUser()` | `SELECT`, `INSERT` | `users`, `user_roles` | Hashes password and registers a user with the default `ROLE_USER` role. |
| `/api/auth/login` | `POST` | `AuthServiceImpl.authenticateUser()` | `SELECT` | `users`, `roles` | Validates credentials and returns a JWT token. |
| `/api/auth/forgot-password`| `POST`| `UserServiceImpl.forgotPassword()` | `SELECT` | `users` | Verifies email and logs a simulated password reset token on the console. |

### Category 2: User Settings (`/api/user`)
| Swagger Endpoint | HTTP Method | Service Implementation | SQL Actions | Tables Modified/Read | Description |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `/api/user/profile` | `GET` | `UserServiceImpl.getUserProfile()` | `SELECT` | `users` | Retrieves the authenticated user's profile details. |
| `/api/user/profile/update` | `PUT` | `UserServiceImpl.updateUserProfile()` | `UPDATE` | `users` | Modifies contact details (first name, phone number, etc.). |
| `/api/user/change-password`| `PUT` | `UserServiceImpl.changePassword()` | `SELECT`, `UPDATE` | `users` | Verifies current password and updates it in the database. |

### Category 3: Categories Catalog (`/api/categories`)
| Swagger Endpoint | HTTP Method | Service Implementation | SQL Actions | Tables Modified/Read | Description |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `/api/categories` | `GET` | `CategoryServiceImpl.getAllCategories()`| `SELECT` | `categories` | Fetches list of active categories. |

### Category 4: Tourist Places Catalog (`/api/places`)
| Swagger Endpoint | HTTP Method | Service Implementation | SQL Actions | Tables Modified/Read | Description |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `/api/places` | `GET` | `TouristPlaceServiceImpl.getAllTouristPlaces()` | `SELECT` | `tourist_places`, `images`, `categories` | Fetches places supporting dynamic SQL filters (category, query, sorting). |
| `/api/places/{id}` | `GET` | `TouristPlaceServiceImpl.getTouristPlaceById()` | `SELECT` | `tourist_places`, `images` | Retrieves place details. |

### Category 5: Bookings Panel (`/api/bookings`)
| Swagger Endpoint | HTTP Method | Service Implementation | SQL Actions | Tables Modified/Read | Description |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `/api/bookings` | `POST` | `BookingServiceImpl.createBooking()` | `SELECT`, `INSERT` | `bookings`, `users`, `tourist_places` | Creates a new tour booking package. |
| `/api/bookings/my-bookings` | `GET` | `BookingServiceImpl.getUserBookings()` | `SELECT` | `bookings` | Retrieves all bookings for the authenticated user. |
| `/api/bookings/{id}/cancel` | `PUT` | `BookingServiceImpl.cancelBooking()` | `SELECT`, `UPDATE` | `bookings` | Marks a booking as `'CANCELLED'`. |

### Category 6: Favorites / Bookmark Wishlist (`/api/favorites`)
| Swagger Endpoint | HTTP Method | Service Implementation | SQL Actions | Tables Modified/Read | Description |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `/api/favorites/add` | `POST` | `FavoriteServiceImpl.addToFavorites()` | `SELECT`, `INSERT` | `favorites` | Adds a place to the user's wishlist. |
| `/api/favorites/remove` | `DELETE` | `FavoriteServiceImpl.removeFromFavorites()`| `SELECT`, `DELETE` | `favorites` | Removes a place from the user's wishlist. |
| `/api/favorites/my-favorites` | `GET` | `FavoriteServiceImpl.getUserFavorites()`| `SELECT` | `favorites`, `tourist_places`| Fetches all bookmarked destinations. |
| `/api/favorites/check` | `GET` | `FavoriteServiceImpl.isFavorite()` | `SELECT` | `favorites` | Returns a boolean flag indicating if a place is bookmarked. |

### Category 7: Reviews & Ratings Feed (`/api/reviews`)
| Swagger Endpoint | HTTP Method | Service Implementation | SQL Actions | Tables Modified/Read | Description |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `/api/reviews` | `POST` | `ReviewServiceImpl.addReview()` | `SELECT`, `INSERT`, `UPDATE` | `reviews`, `tourist_places` | Publishes a review. Automatically recalculates `average_rating` for the place. |
| `/api/reviews/place/{placeId}`| `GET` | `ReviewServiceImpl.getReviewsByPlace()`| `SELECT` | `reviews`, `users` | Fetches all reviews for a destination. |

### Category 8: Help Desk / Contact query (`/api/contact`)
| Swagger Endpoint | HTTP Method | Service Implementation | SQL Actions | Tables Modified/Read | Description |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `/api/contact/submit` | `POST` | `ContactMessageServiceImpl.submitMessage()` | `INSERT` | `contact_messages` | Submits a support inquiry form. |

---

## 4. Admin CRUD REST APIs (`/api/admin`)
Endpoints reserved exclusively for administrators (`ROLE_ADMIN`).

| Swagger Endpoint | HTTP Method | Service Implementation | SQL Actions | Tables Modified/Read | Description |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `/api/admin/stats` | `GET` | `DashboardServiceImpl.getStats()` | `SELECT` (Aggregate counts) | `users`, `tourist_places`, `bookings`, etc. | Calculates totals for the dashboard dashboard widgets. |
| `/api/admin/places` | `POST` | `TouristPlaceServiceImpl.createTouristPlace()` | `SELECT`, `INSERT` | `tourist_places`, `images` | Admin: Creates a destination. Coordinates are saved here. |
| `/api/admin/places/{id}` | `PUT` | `TouristPlaceServiceImpl.updateTouristPlace()` | `SELECT`, `UPDATE` | `tourist_places`, `images` | Admin: Updates a destination's name, category, or coordinates. |
| `/api/admin/places/{id}` | `DELETE` | `TouristPlaceServiceImpl.deleteTouristPlace()` | `SELECT`, `DELETE` | `tourist_places`, `images` | Admin: Permanently deletes a destination. |
| `/api/admin/categories` | `POST` | `CategoryServiceImpl.createCategory()` | `INSERT` | `categories` | Admin: Creates a new category. |
| `/api/admin/categories/{id}`| `PUT` | `CategoryServiceImpl.updateCategory()` | `SELECT`, `UPDATE` | `categories` | Admin: Modifies a category. |
| `/api/admin/bookings` | `GET` | `BookingServiceImpl.getAllBookings()` | `SELECT` | `bookings`, `users`, `tourist_places` | Admin: Lists all bookings. |
| `/api/admin/bookings/{id}/approve` | `PUT` | `BookingServiceImpl.approveBooking()` | `SELECT`, `UPDATE` | `bookings` | Admin: Approves a booking. |
| `/api/admin/users` | `GET` | `UserServiceImpl.getAllUsers()` | `SELECT` | `users`, `roles` | Admin: Lists all users and roles. |
| `/api/admin/users/{id}` | `DELETE` | `UserServiceImpl.deleteUser()` | `SELECT`, `DELETE` | `users` | Admin: Deletes a user profile (cascades bookings/reviews). |
| `/api/admin/contact/all` | `GET` | `ContactMessageServiceImpl.getAllMessages()`| `SELECT` | `contact_messages` | Admin: Lists all support emails. |
| `/api/admin/contact/{id}/reply`| `POST` | `ContactMessageServiceImpl.replyToMessage()`| `SELECT`, `UPDATE` | `contact_messages` | Admin: Flags a query as replied and logs the reply to the console. |
