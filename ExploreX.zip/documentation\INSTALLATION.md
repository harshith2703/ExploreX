# ExploreX – Installation & Setup Guide

This document outlines the step-by-step instructions to run the ExploreX Tourist Information System on your local computer.

---

## 1. Database Setup (MySQL)

Ensure MySQL Server 8.0+ is running locally.

1. Open your terminal or MySQL Workbench, log in with your root credentials, and execute the SQL scripts in order:
   ```sql
   -- Create and map tables
   SOURCE c:/Users/harsh/OneDrive/Desktop/ExploreX/database/schema.sql;

   -- Populate default users, categories, and tourist place cards
   SOURCE c:/Users/harsh/OneDrive/Desktop/ExploreX/database/data.sql;
   ```
2. Alternatively, copy-paste the text inside [schema.sql](file:///c:/Users/harsh/OneDrive/Desktop/ExploreX/database/schema.sql) and [data.sql](file:///c:/Users/harsh/OneDrive/Desktop/ExploreX/database/data.sql) directly into your SQL query console and execute.

---

## 2. Backend Setup (Spring Tool Suite / Eclipse)

1. Open **Spring Tool Suite (STS)**.
2. Select **File > Import...** from the top menu.
3. Choose **Maven > Existing Maven Projects** and click **Next**.
4. Click **Browse** and select the folder `c:\Users\harsh\OneDrive\Desktop\ExploreX\backend`.
5. Click **Finish**. STS will download the required libraries listed in `pom.xml`.
6. Open [application.properties](file:///c:/Users/harsh/OneDrive/Desktop/ExploreX/backend/src/main/resources/application.properties) and verify the MySQL connection settings:
   - `spring.datasource.username=root`
   - `spring.datasource.password=root` (Change this to your local MySQL password if different).
7. Right-click on the project in Package Explorer, select **Run As > Spring Boot App**.
8. The server will start and host endpoints at `http://localhost:8080`.
9. Access the Swagger documentation in your browser to test endpoints:
   - URL: `http://localhost:8080/swagger-ui.html`

---

## 3. Frontend Setup (VS Code)

1. Open **Visual Studio Code**.
2. Select **File > Open Folder...** and choose `c:\Users\harsh\OneDrive\Desktop\ExploreX\frontend`.
3. Open the built-in terminal in VS Code (Ctrl+` or **Terminal > New Terminal**).
4. Run the following command to download and install all package dependencies listed in `package.json`:
   ```bash
   npm install
   ```
5. Once installation finishes, start the local development server:
   ```bash
   npm run dev
   ```
6. The terminal will output the local port (usually `http://localhost:5173`).
7. Open the local port in your browser. The ExploreX Tourist System is now fully functional!
