package com.explorex.controller;

import com.explorex.dto.TouristPlaceDto;
import com.explorex.security.UserPrincipal;
import com.explorex.service.FavoriteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Controller exposing Favorite place APIs.
 */
@RestController
@RequestMapping("/api/favorites")
public class FavoriteController {

    @Autowired
    private FavoriteService favoriteService;

    @PostMapping("/add")
    public ResponseEntity<Map<String, String>> addFavorite(
            @AuthenticationPrincipal UserPrincipal userPrincipal,
            @RequestParam Long placeId) {
        favoriteService.addFavorite(userPrincipal.getId(), placeId);
        Map<String, String> response = new HashMap<>();
        response.put("message", "Place added to favorites!");
        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/remove")
    public ResponseEntity<Map<String, String>> removeFavorite(
            @AuthenticationPrincipal UserPrincipal userPrincipal,
            @RequestParam Long placeId) {
        favoriteService.removeFavorite(userPrincipal.getId(), placeId);
        Map<String, String> response = new HashMap<>();
        response.put("message", "Place removed from favorites!");
        return ResponseEntity.ok(response);
    }

    @GetMapping("/my-favorites")
    public ResponseEntity<List<TouristPlaceDto>> getMyFavorites(@AuthenticationPrincipal UserPrincipal userPrincipal) {
        List<TouristPlaceDto> favorites = favoriteService.getFavoritesByUser(userPrincipal.getId());
        return ResponseEntity.ok(favorites);
    }

    @GetMapping("/check")
    public ResponseEntity<Map<String, Boolean>> checkIsFavorite(
            @AuthenticationPrincipal UserPrincipal userPrincipal,
            @RequestParam Long placeId) {
        Boolean isFav = favoriteService.isFavorite(userPrincipal.getId(), placeId);
        Map<String, Boolean> response = new HashMap<>();
        response.put("isFavorite", isFav);
        return ResponseEntity.ok(response);
    }
}
