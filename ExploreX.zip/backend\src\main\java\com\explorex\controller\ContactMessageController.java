package com.explorex.controller;

import com.explorex.dto.ContactMessageDto;
import com.explorex.service.ContactMessageService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Controller exposing Contact Message/Support APIs.
 */
@RestController
public class ContactMessageController {

    @Autowired
    private ContactMessageService contactMessageService;

    // Public Form Submission
    @PostMapping("/api/contact/submit")
    public ResponseEntity<ContactMessageDto> submitContactMessage(@Valid @RequestBody ContactMessageDto dto) {
        ContactMessageDto savedMessage = contactMessageService.submitMessage(dto);
        return new ResponseEntity<>(savedMessage, HttpStatus.CREATED);
    }

    // Admin secured endpoints
    @GetMapping("/api/admin/contact/all")
    public ResponseEntity<List<ContactMessageDto>> getAllContactMessages() {
        List<ContactMessageDto> messages = contactMessageService.getAllMessages();
        return ResponseEntity.ok(messages);
    }

    @GetMapping("/api/admin/contact/replied/{replied}")
    public ResponseEntity<List<ContactMessageDto>> getContactMessagesByStatus(@PathVariable Boolean replied) {
        List<ContactMessageDto> messages = contactMessageService.getMessagesByReplyStatus(replied);
        return ResponseEntity.ok(messages);
    }

    @PutMapping("/api/admin/contact/{id}/reply")
    public ResponseEntity<Map<String, String>> replyToMessage(@PathVariable Long id) {
        contactMessageService.replyToMessage(id);
        Map<String, String> response = new HashMap<>();
        response.put("message", "Message marked as replied successfully!");
        return ResponseEntity.ok(response);
    }
}
