package com.explorex.dto;


/**
 * DTO representing administrative dashboard metrics.
 */
public class DashboardStatsDto {
    private Long totalUsers;
    private Long totalPlaces;
    private Long totalCategories;
    private Long totalReviews;
    private Long totalBookings;
    private Long totalPendingBookings;
    private Long totalUnrepliedMessages;

    public DashboardStatsDto() {}

    public DashboardStatsDto(Long totalUsers, Long totalPlaces, Long totalCategories, Long totalReviews, Long totalBookings, Long totalPendingBookings, Long totalUnrepliedMessages) {
        this.totalUsers = totalUsers;
        this.totalPlaces = totalPlaces;
        this.totalCategories = totalCategories;
        this.totalReviews = totalReviews;
        this.totalBookings = totalBookings;
        this.totalPendingBookings = totalPendingBookings;
        this.totalUnrepliedMessages = totalUnrepliedMessages;
    }

    public Long getTotalUsers() {
        return totalUsers;
    }

    public void setTotalUsers(Long totalUsers) {
        this.totalUsers = totalUsers;
    }

    public Long getTotalPlaces() {
        return totalPlaces;
    }

    public void setTotalPlaces(Long totalPlaces) {
        this.totalPlaces = totalPlaces;
    }

    public Long getTotalCategories() {
        return totalCategories;
    }

    public void setTotalCategories(Long totalCategories) {
        this.totalCategories = totalCategories;
    }

    public Long getTotalReviews() {
        return totalReviews;
    }

    public void setTotalReviews(Long totalReviews) {
        this.totalReviews = totalReviews;
    }

    public Long getTotalBookings() {
        return totalBookings;
    }

    public void setTotalBookings(Long totalBookings) {
        this.totalBookings = totalBookings;
    }

    public Long getTotalPendingBookings() {
        return totalPendingBookings;
    }

    public void setTotalPendingBookings(Long totalPendingBookings) {
        this.totalPendingBookings = totalPendingBookings;
    }

    public Long getTotalUnrepliedMessages() {
        return totalUnrepliedMessages;
    }

    public void setTotalUnrepliedMessages(Long totalUnrepliedMessages) {
        this.totalUnrepliedMessages = totalUnrepliedMessages;
    }

    @Override
    public String toString() {
        return "DashboardStatsDto(totalUsers='" + totalUsers + "', totalPlaces='" + totalPlaces + "', totalCategories='" + totalCategories + "', totalReviews='" + totalReviews + "', totalBookings='" + totalBookings + "', totalPendingBookings='" + totalPendingBookings + "', totalUnrepliedMessages='" + totalUnrepliedMessages + "')";
    }
}
