package com.explorex.entity;

/**
 * Enumeration representing security roles in the ExploreX system.
 */
public enum RoleName {
    ROLE_USER,
    ROLE_ADMIN
}
