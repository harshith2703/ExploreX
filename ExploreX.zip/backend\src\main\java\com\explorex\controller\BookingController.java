package com.explorex.controller;

import com.explorex.dto.BookingDto;
import com.explorex.security.UserPrincipal;
import com.explorex.service.BookingService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Controller exposing Booking APIs.
 */
@RestController
public class BookingController {

    @Autowired
    private BookingService bookingService;

    // User Booking endpoints
    @PostMapping("/api/bookings")
    public ResponseEntity<BookingDto> createBooking(
            @AuthenticationPrincipal UserPrincipal userPrincipal,
            @Valid @RequestBody BookingDto bookingDto) {
        BookingDto savedBooking = bookingService.createBooking(userPrincipal.getId(), bookingDto);
        return new ResponseEntity<>(savedBooking, HttpStatus.CREATED);
    }

    @GetMapping("/api/bookings/my-bookings")
    public ResponseEntity<List<BookingDto>> getMyBookings(@AuthenticationPrincipal UserPrincipal userPrincipal) {
        List<BookingDto> bookings = bookingService.getBookingsByUserId(userPrincipal.getId());
        return ResponseEntity.ok(bookings);
    }

    @PutMapping("/api/bookings/{id}/cancel")
    public ResponseEntity<Map<String, String>> cancelBooking(
            @PathVariable Long id,
            @AuthenticationPrincipal UserPrincipal userPrincipal) {
        bookingService.cancelBooking(userPrincipal.getId(), id);
        Map<String, String> response = new HashMap<>();
        response.put("message", "Booking cancelled successfully!");
        return ResponseEntity.ok(response);
    }

    // Admin secured endpoints
    @GetMapping("/api/admin/bookings")
    public ResponseEntity<List<BookingDto>> getAllBookings() {
        List<BookingDto> bookings = bookingService.getAllBookings();
        return ResponseEntity.ok(bookings);
    }

    @PutMapping("/api/admin/bookings/{id}/status")
    public ResponseEntity<BookingDto> updateBookingStatus(
            @PathVariable Long id,
            @RequestParam String status) {
        BookingDto updatedBooking = bookingService.updateBookingStatus(id, status);
        return ResponseEntity.ok(updatedBooking);
    }
}
