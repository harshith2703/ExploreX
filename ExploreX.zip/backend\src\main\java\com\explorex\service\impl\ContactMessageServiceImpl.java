package com.explorex.service.impl;

import com.explorex.dto.ContactMessageDto;
import com.explorex.entity.ContactMessage;
import com.explorex.exception.ResourceNotFoundException;
import com.explorex.mapper.ContactMessageMapper;
import com.explorex.repository.ContactMessageRepository;
import com.explorex.service.ContactMessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Service implementation for Contact support message operations.
 */
@Service
public class ContactMessageServiceImpl implements ContactMessageService {

    @Autowired
    private ContactMessageRepository contactMessageRepository;

    @Override
    @Transactional
    public ContactMessageDto submitMessage(ContactMessageDto dto) {
        ContactMessage message = ContactMessageMapper.toEntity(dto);
        message.setReplied(false);
        ContactMessage savedMessage = contactMessageRepository.save(message);
        return ContactMessageMapper.toDto(savedMessage);
    }

    @Override
    public List<ContactMessageDto> getAllMessages() {
        return contactMessageRepository.findAll().stream()
                .map(ContactMessageMapper::toDto)
                .collect(Collectors.toList());
    }

    @Override
    public List<ContactMessageDto> getMessagesByReplyStatus(Boolean replied) {
        return contactMessageRepository.findByReplied(replied).stream()
                .map(ContactMessageMapper::toDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public void replyToMessage(Long messageId) {
        ContactMessage message = contactMessageRepository.findById(messageId)
                .orElseThrow(() -> new ResourceNotFoundException("ContactMessage", "id", messageId));

        message.setReplied(true);
        contactMessageRepository.save(message);

        System.out.println("[SMTP Mock Server] Send support response to: " + message.getEmail());
    }
}
