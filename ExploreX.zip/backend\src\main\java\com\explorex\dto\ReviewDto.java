package com.explorex.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDateTime;

/**
 * DTO representing detailed review details.
 */
public class ReviewDto {

    private Long id;

    @NotNull(message = "Rating score is required")
    @Min(value = 1, message = "Rating must be at least 1 star")
    @Max(value = 5, message = "Rating cannot exceed 5 stars")
    private Integer rating;

    @NotBlank(message = "Review comment is required")
    private String comment;

    private Long userId;
    private String username;
    private String userProfilePic;

    @NotNull(message = "Tourist place ID is required")
    private Long touristPlaceId;
    private String touristPlaceName;

    private LocalDateTime createdAt;

    public ReviewDto() {}

    public ReviewDto(Long id, Integer rating, String comment, Long userId, String username, String userProfilePic, Long touristPlaceId, String touristPlaceName, LocalDateTime createdAt) {
        this.id = id;
        this.rating = rating;
        this.comment = comment;
        this.userId = userId;
        this.username = username;
        this.userProfilePic = userProfilePic;
        this.touristPlaceId = touristPlaceId;
        this.touristPlaceName = touristPlaceName;
        this.createdAt = createdAt;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getRating() {
        return rating;
    }

    public void setRating(Integer rating) {
        this.rating = rating;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUserProfilePic() {
        return userProfilePic;
    }

    public void setUserProfilePic(String userProfilePic) {
        this.userProfilePic = userProfilePic;
    }

    public Long getTouristPlaceId() {
        return touristPlaceId;
    }

    public void setTouristPlaceId(Long touristPlaceId) {
        this.touristPlaceId = touristPlaceId;
    }

    public String getTouristPlaceName() {
        return touristPlaceName;
    }

    public void setTouristPlaceName(String touristPlaceName) {
        this.touristPlaceName = touristPlaceName;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public String toString() {
        return "ReviewDto(id='" + id + "', rating='" + rating + "', comment='" + comment + "', userId='" + userId + "', username='" + username + "', userProfilePic='" + userProfilePic + "', touristPlaceId='" + touristPlaceId + "', touristPlaceName='" + touristPlaceName + "', createdAt='" + createdAt + "')";
    }
}
