package com.explorex.service.impl;

import com.explorex.dto.ChangePasswordRequest;
import com.explorex.dto.UserProfileDto;
import com.explorex.entity.User;
import com.explorex.exception.BadRequestException;
import com.explorex.exception.ResourceNotFoundException;
import com.explorex.mapper.UserMapper;
import com.explorex.repository.UserRepository;
import com.explorex.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Service implementation for user operations.
 */
@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public UserProfileDto getUserProfile(Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", id));
        return UserMapper.toDto(user);
    }

    @Override
    @Transactional
    public UserProfileDto updateUserProfile(Long id, UserProfileDto profileDto) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", id));

        // Check if email already exists for another user
        userRepository.findByEmail(profileDto.getEmail()).ifPresent(existingUser -> {
            if (!existingUser.getId().equals(id)) {
                throw new BadRequestException("Email address is already in use by another user!");
            }
        });

        user.setFirstName(profileDto.getFirstName());
        user.setLastName(profileDto.getLastName());
        user.setEmail(profileDto.getEmail());
        user.setPhoneNumber(profileDto.getPhoneNumber());
        if (profileDto.getProfilePicture() != null && !profileDto.getProfilePicture().trim().isEmpty()) {
            user.setProfilePicture(profileDto.getProfilePicture());
        }

        User updatedUser = userRepository.save(user);
        return UserMapper.toDto(updatedUser);
    }

    @Override
    @Transactional
    public void changePassword(Long id, ChangePasswordRequest request) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", id));

        if (!passwordEncoder.matches(request.getOldPassword(), user.getPassword())) {
            throw new BadRequestException("Current password does not match!");
        }

        user.setPassword(passwordEncoder.encode(request.getNewPassword()));
        userRepository.save(user);
    }

    @Override
    @Transactional
    public void forgotPassword(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User", "email", email));

        // Mock reset: Reset to default and print to stdout
        String temporaryPassword = "Reset@123";
        user.setPassword(passwordEncoder.encode(temporaryPassword));
        userRepository.save(user);

        System.out.println("[SMTP Mock Server] Password reset email sent to " + email);
        System.out.println("[SMTP Mock Server] Temporary password is: " + temporaryPassword);
    }

    @Override
    public List<UserProfileDto> getAllUsers() {
        return userRepository.findAll().stream()
                .map(UserMapper::toDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public void deleteUser(Long id) {
        if (!userRepository.existsById(id)) {
            throw new ResourceNotFoundException("User", "id", id);
        }
        userRepository.deleteById(id);
    }
}
