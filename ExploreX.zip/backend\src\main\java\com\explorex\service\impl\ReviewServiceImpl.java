package com.explorex.service.impl;

import com.explorex.dto.ReviewDto;
import com.explorex.entity.Review;
import com.explorex.entity.TouristPlace;
import com.explorex.entity.User;
import com.explorex.exception.BadRequestException;
import com.explorex.exception.ResourceNotFoundException;
import com.explorex.mapper.ReviewMapper;
import com.explorex.repository.ReviewRepository;
import com.explorex.repository.TouristPlaceRepository;
import com.explorex.repository.UserRepository;
import com.explorex.service.ReviewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Service implementation for Review operations.
 */
@Service
public class ReviewServiceImpl implements ReviewService {

    @Autowired
    private ReviewRepository reviewRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private TouristPlaceRepository touristPlaceRepository;

    @Override
    @Transactional
    public ReviewDto addReview(Long userId, ReviewDto dto) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));

        TouristPlace touristPlace = touristPlaceRepository.findById(dto.getTouristPlaceId())
                .orElseThrow(() -> new ResourceNotFoundException("TouristPlace", "id", dto.getTouristPlaceId()));

        if (reviewRepository.existsByUserIdAndTouristPlaceId(userId, dto.getTouristPlaceId())) {
            throw new BadRequestException("You have already reviewed this tourist place!");
        }

        Review review = ReviewMapper.toEntity(dto);
        review.setUser(user);
        review.setTouristPlace(touristPlace);

        Review savedReview = reviewRepository.save(review);

        // Update average rating of the Tourist Place
        updateAverageRating(touristPlace.getId());

        return ReviewMapper.toDto(savedReview);
    }

    @Override
    public List<ReviewDto> getReviewsByPlaceId(Long placeId) {
        if (!touristPlaceRepository.existsById(placeId)) {
            throw new ResourceNotFoundException("TouristPlace", "id", placeId);
        }
        return reviewRepository.findByTouristPlaceId(placeId).stream()
                .map(ReviewMapper::toDto)
                .collect(Collectors.toList());
    }

    @Override
    public List<ReviewDto> getReviewsByUserId(Long userId) {
        if (!userRepository.existsById(userId)) {
            throw new ResourceNotFoundException("User", "id", userId);
        }
        return reviewRepository.findByUserId(userId).stream()
                .map(ReviewMapper::toDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public void deleteReview(Long id) {
        Review review = reviewRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Review", "id", id));

        Long touristPlaceId = review.getTouristPlace().getId();
        reviewRepository.delete(review);

        // Recompute average rating after deletion
        updateAverageRating(touristPlaceId);
    }

    private void updateAverageRating(Long placeId) {
        TouristPlace place = touristPlaceRepository.findById(placeId)
                .orElseThrow(() -> new ResourceNotFoundException("TouristPlace", "id", placeId));

        Double avgRating = reviewRepository.getAverageRatingForPlace(placeId);
        if (avgRating == null) {
            avgRating = 0.0;
        } else {
            // Round to 1 decimal place
            avgRating = Math.round(avgRating * 10.0) / 10.0;
        }

        place.setAverageRating(avgRating);
        touristPlaceRepository.save(place);
    }
}
