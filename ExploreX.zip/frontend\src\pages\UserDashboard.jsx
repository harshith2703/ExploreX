import React, { useState, useEffect } from 'react';
import api from '../services/api';

const UserDashboard = () => {
  const [bookings, setBookings] = useState([]);
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('bookings');

  const fetchDashboardData = async () => {
    try {
      const bookingsRes = await api.get('/bookings/my-bookings');
      setBookings(bookingsRes.data);

      const reviewsRes = await api.get('/reviews/my-reviews');
      setReviews(reviewsRes.data);
    } catch (err) {
      console.error('Error loading dashboard stats:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const handleCancelBooking = async (bookingId) => {
    if (!window.confirm('Are you sure you want to cancel this tour booking request?')) {
      return;
    }
    try {
      await api.put(`/bookings/${bookingId}/cancel`);
      // Update local state status to CANCELLED
      setBookings(bookings.map(b => b.id === bookingId ? { ...b, status: 'CANCELLED' } : b));
    } catch (err) {
      console.error('Error cancelling booking:', err);
      alert('Could not cancel booking request.');
    }
  };

  const handleDeleteReview = async (reviewId) => {
    if (!window.confirm('Are you sure you want to delete your review comment?')) {
      return;
    }
    try {
      await api.delete(`/reviews/${reviewId}`);
      setReviews(reviews.filter(r => r.id !== reviewId));
    } catch (err) {
      console.error('Error deleting review:', err);
    }
  };

  const getStatusBadgeClass = (status) => {
    switch (status.toUpperCase()) {
      case 'APPROVED': return 'bg-success text-white';
      case 'CANCELLED': return 'bg-danger text-white';
      case 'PENDING':
      default: return 'bg-warning text-dark';
    }
  };

  return (
    <div className="container py-5">
      <div className="text-center mb-5">
        <h1 className="fw-bold display-4">Traveler Dashboard</h1>
        <p className="text-muted">Track active tour schedules, verify approved guides, and manage destination reviews</p>
      </div>

      {/* Navigation Tabs */}
      <div className="d-flex justify-content-center mb-4">
        <div className="btn-group bg-white p-1 shadow-sm rounded-pill" role="group">
          <button
            type="button"
            onClick={() => setActiveTab('bookings')}
            className={`btn rounded-pill px-4 py-2 border-0 fw-semibold ${
              activeTab === 'bookings' ? 'btn-explore' : 'text-secondary'
            }`}
          >
            <i className="bi bi-journal-check me-2"></i>My Bookings
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('reviews')}
            className={`btn rounded-pill px-4 py-2 border-0 fw-semibold ${
              activeTab === 'reviews' ? 'btn-explore' : 'text-secondary'
            }`}
          >
            <i className="bi bi-chat-text me-2"></i>My Reviews ({reviews.length})
          </button>
        </div>
      </div>

      {loading ? (
        <div className="text-center py-5">
          <div className="spinner-border text-primary" role="status" style={{ width: '3rem', height: '3rem' }}>
            <span className="visually-hidden">Loading dashboard...</span>
          </div>
        </div>
      ) : activeTab === 'bookings' ? (
        /* Bookings Section Layout */
        <div className="card shadow-sm border-0 p-4" style={{ borderRadius: '16px' }}>
          <h3 className="fw-bold text-dark mb-4"><i className="bi bi-calendar-check text-primary me-2"></i>Scheduled Guided Tours</h3>
          
          {bookings.length === 0 ? (
            <div className="text-center py-5 bg-light rounded-3">
              <i className="bi bi-calendar-x text-muted fs-1"></i>
              <p className="text-muted mb-0 mt-3">You have no active tour reservations. Start planning today!</p>
            </div>
          ) : (
            <div className="table-responsive">
              <table className="table align-middle table-hover">
                <thead className="table-light">
                  <tr>
                    <th>Booking ID</th>
                    <th>Destination Name</th>
                    <th>Date Scheduled</th>
                    <th>Traveler Counts</th>
                    <th>Special Requests</th>
                    <th>Status</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {bookings.map((booking) => (
                    <tr key={booking.id}>
                      <td><span className="fw-bold small text-secondary">#EX-0{booking.id}</span></td>
                      <td><span className="fw-semibold text-primary">{booking.touristPlaceName}</span></td>
                      <td>{new Date(booking.bookingDate).toLocaleDateString()}</td>
                      <td>{booking.numberOfPeople} people</td>
                      <td><span className="text-muted small">{booking.specialRequests || 'None'}</span></td>
                      <td>
                        <span className={`badge rounded-pill px-3 py-1 text-uppercase ${getStatusBadgeClass(booking.status)}`}>
                          {booking.status}
                        </span>
                      </td>
                      <td>
                        {booking.status.toUpperCase() === 'PENDING' || booking.status.toUpperCase() === 'APPROVED' ? (
                          <button
                            onClick={() => handleCancelBooking(booking.id)}
                            className="btn btn-outline-danger btn-sm rounded-pill px-3"
                          >
                            <i className="bi bi-x-circle me-1"></i>Cancel Request
                          </button>
                        ) : (
                          <span className="text-muted small">Completed</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      ) : (
        /* Reviews Section Layout */
        <div className="card shadow-sm border-0 p-4" style={{ borderRadius: '16px' }}>
          <h3 className="fw-bold text-dark mb-4"><i className="bi bi-chat-heart text-success me-2"></i>My Destination Reviews</h3>
          
          {reviews.length === 0 ? (
            <div className="text-center py-5 bg-light rounded-3">
              <i className="bi bi-chat-square-quote text-muted fs-1"></i>
              <p className="text-muted mb-0 mt-3">You haven't posted any reviews yet.</p>
            </div>
          ) : (
            <div className="row g-3">
              {reviews.map((rev) => (
                <div className="col-md-6" key={rev.id}>
                  <div className="p-3 bg-light rounded-3 shadow-sm d-flex flex-column h-100 justify-content-between border-start border-4 border-success">
                    <div>
                      <div className="d-flex justify-content-between align-items-center mb-2">
                        <h5 className="fw-bold text-dark mb-0">{rev.touristPlaceName}</h5>
                        <span className="text-warning">
                          {Array.from({ length: rev.rating }).map((_, i) => (
                            <i key={i} className="bi bi-star-fill small"></i>
                          ))}
                        </span>
                      </div>
                      <p className="text-secondary small mb-3">"{rev.comment}"</p>
                    </div>
                    <div className="d-flex justify-content-between align-items-center mt-2 pt-2 border-top">
                      <small className="text-muted text-uppercase" style={{ fontSize: '0.65rem' }}>
                        Date: {new Date(rev.createdAt).toLocaleDateString()}
                      </small>
                      <button
                        onClick={() => handleDeleteReview(rev.id)}
                        className="btn btn-link text-danger text-decoration-none small p-0 fw-semibold"
                      >
                        <i className="bi bi-trash3 me-1"></i>Delete Review
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default UserDashboard;
