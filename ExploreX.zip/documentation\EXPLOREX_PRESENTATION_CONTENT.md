# TOURIST INFORMATION SYSTEM (ExploreX)
## Project Documentation / PPT Content

### A Java Full Stack Web Application
**React.js | Spring Boot | MySQL**

---

### **Objective of the Project**
To design and develop a secure, full-stack tourist information and booking system that allows travelers to discover destinations, view live geographic distances via browser GPS coordinates, manage tour bookings, and view interactive locations on a Google Map, backed by a robust REST API and relational database with full admin controls.

---

## 1. Introduction

### 1.1 What is a Tourist Information System (ExploreX)?
ExploreX is a full-stack travel booking and discovery platform where users can explore tourism destinations, filter them by category, view real-time distances to spots from their location, and book trips. It provides interactive mapping coordinates and provides administrators with a complete backend control center to manage destinations, categories, user accounts, and bookings.

### 1.2 Why This Project is Useful
This project demonstrates how modern web applications combine REST API design, state-management architectures, relational database management, and browser APIs (HTML5 Geolocation and Google Maps JS SDK). It models production-style system development, featuring JWT authentication and decoupled software layers.

### 1.3 Users of the System
*   **Admin**: Manages user accounts, performs full CRUD operations on destinations/categories, manages bookings (approvals), updates maps coordinates, and answers support inquiries.
*   **Registered Tourist (User)**: Registers and logs in securely. Can search destinations, view live distances to locations, add spots to a wishlist (favorites), write ratings/reviews, and book trips.
*   **Visitor (Anonymous)**: Can browse tourist places, read reviews, and submit help desk contact forms.

---

## 2. Technologies Used

| Technology | Purpose |
| :--- | :--- |
| **React.js** | Building the dynamic frontend user interface. |
| **HTML5 / CSS3** | Structuring and custom styling web pages (Vanilla CSS). |
| **JavaScript** | Client-side logic, routing, and geo-distance calculations. |
| **Axios** | Sending HTTP requests from React to the backend API with interceptors. |
| **React Router** | Handling page routing and private access gates. |
| **Java 24 / 26** | Core programming language for the backend. |
| **Spring Boot 3.3.1** | Building the REST API and backend application. |
| **Spring Data JPA** | Simplifying database ORM operations and transaction queries. |
| **Spring Security + JWT** | Securing endpoints, password hashing, and handling stateless auth. |
| **Maven** | Managing backend project dependencies and compilations. |
| **MySQL** | Storing application data (users, places, reviews, bookings). |
| **Spring Tool Suite (STS)** | Backend development environment. |
| **Visual Studio Code** | Frontend development environment. |
| **MySQL Workbench** | Designing and managing database schemas. |

---

## 3. Project Architecture

The application follows a layered client-server architecture. The React frontend runs in the user's browser, fetching user GPS coordinates and rendering the UI. It communicates with the Spring Boot backend through REST APIs over HTTP. The backend filters request filters through its security engines and processes requests through its internal service layers before communicating with the MySQL database.

### 3.1 Data Flow Diagram
```
     React Frontend (Vite)
              |
              v
      Axios HTTP Requests
              |
              v
     Spring Boot REST API
              |
              v
    Service Implementation
              |
              v
    Repository Layer (JPA)
              |
              v
        MySQL Database
```

### 3.2 Layer Responsibilities
*   **React Frontend**: Renders user dashboards, collects search filters, tracks browser coordinates, and computes client-side Haversine distances.
*   **Axios**: Transmits JSON requests (attaching JWT bearer authorization headers) to Spring Boot and intercepts responses.
*   **REST API (Controller)**: Exposes endpoints, parses path parameters, and routes payloads to correct services.
*   **Service Layer**: Executes transaction business logic (e.g. recalculates place average ratings on review submits).
*   **Repository Layer (JPA)**: Bridges Java models to SQL tables using Hibernate query compilation.
*   **MySQL Database**: Persists relational tables (Users, Bookings, Places, Reviews).

---

## 4. Project Development Process

The project is built in the following sequential steps:
1. Create the backend Spring Boot project using Spring Initializr.
2. Add dependencies: Spring Web, Spring Data JPA, MySQL Driver, Spring Security, JWT.
3. Configure database connection parameters in `application.properties`.
4. Create the relational database schemas and seed SQL files (`schema.sql`, `data.sql`) in MySQL.
5. Create Java entity models: `User`, `Role`, `Category`, `TouristPlace`, `Image`, `Review`, `Favorite`, `Booking`, `ContactMessage`.
6. Create JPA Repository interfaces.
7. Create Service interfaces and Implementations handling business transactions.
8. Create REST Controllers exposing public and secure `/api/admin` APIs.
9. Test and verify all REST endpoints using Postman.
10. Set up the React application using Vite.
11. Install dependencies: `axios`, `react-router-dom`, `bootstrap`, `bootstrap-icons`.
12. Create Global context authentication manager (`AuthContext.jsx`).
13. Create component views: Login, Register, Home, Destinations (Catalog), DestinationDetails, ExploreMap, AdminDashboard, UserDashboard, About, Contact.
14. Integrate Geolocation tracking and the Google Maps API canvas.
15. Verify execution and package the project.

---

## 5. Backend and Frontend Connection

React and Spring Boot communicate through REST APIs using JSON as the data exchange format.

```
 Browser (User Action)
         |
         v
  React Component (State)
         |
         v
   Axios Request (JWT)
         |
         v
  REST Controller (Spring)
         |
         v
  Service Implementation
         |
         v
    Repository (JPA)
         |
         v
      MySQL DB
```

### 5.1 HTTP Methods Used
| Method | Purpose |
| :--- | :--- |
| **GET** | Retrieve data (e.g., loading places list, checking my bookings, loading maps pins). |
| **POST** | Create data (e.g., submitting a review, booking a trip, registering a user). |
| **PUT** | Update data (e.g., editing destination coordinates, approving a booking, profile updates). |
| **DELETE** | Remove data (e.g., canceling a booking, deleting a destination, removing a favorite). |

### 5.2 JSON Request and Response
Data is exchanged as JSON payloads. When the frontend registers a user or saves coordinates, it transmits a JSON object with form variables. The Spring Boot backend processes the input, validates credentials, commits changes to the database, and returns a JSON response (like `{"message": "User registered successfully!"}`) which React uses to trigger alerts and route transitions.

---

## 6. Database Design

### 6.1 Users Table (`users`)
| Column | Description |
| :--- | :--- |
| `id` | Unique user identifier (Primary Key) |
| `username` | Unique username (Unique Key) |
| `email` | Unique email address (Unique Key) |
| `password` | Hashed password string |
| `first_name` | User's first name |
| `phone_number` | Contact phone number |

### 6.2 Tourist Places Table (`tourist_places`)
| Column | Description |
| :--- | :--- |
| `id` | Unique place identifier (Primary Key) |
| `name` | Destination name |
| `description` | Detailed guide information |
| `location` | Town / City name |
| `state` | State name |
| `average_rating` | Floating average of ratings (1 to 5 stars) |
| `latitude` | GPS latitude coordinates (for mapping) |
| `longitude` | GPS longitude coordinates (for mapping) |
| `category_id` | References categories catalog classification (Foreign Key) |

### 6.3 Bookings Table (`bookings`)
| Column | Description |
| :--- | :--- |
| `id` | Unique booking identifier (Primary Key) |
| `booking_date` | Visit target date |
| `number_of_people` | Count of travelers |
| `status` | Booking state (`PENDING`, `APPROVED`, `CANCELLED`) |
| `user_id` | References the booking tourist (Foreign Key) |
| `tourist_place_id` | References the booked tourist place (Foreign Key) |

---

## 7. Application Workflow

The end-to-end working of the application follows this sequence:
```
               User Registration
                       |
                       v
                 Login (JWT)
                       |
                       v
             Main Landing Dashboard
                       |
                       v
     Browse Destinations / Map Canvas (GPS Coords)
                       |
                       v
           Compare Places by Distance
                       |
                       v
        Book Tours / Request Special Services
                       |
                       v
            Save Spots to Wishlist
                       |
                       v
             Review / Rate Visited Spots
                       |
                       v
                Contact Support
                       |
                       v
                    Logout
```

---

## 8. Features

*   **HTML5 Geolocation Tracker**: Detects the traveler's coordinates to compute relative physical distance (in km) to any destination using the Haversine formula.
*   **Dynamic Search Catalog**: Filters place listings by text queries, category tags, and sorts dynamically by "Nearest to Me", "Highest Rating", and "Popularity".
*   **Unified Google Map View**: Interactive split-pane map plotting all destinations. Dropped markers show clickable popups with images, ratings, and redirect links.
*   **State-of-the-Art Visual Aesthetics**: Premium dark-blue layout accented with vibrant emerald green, smooth cards, grid matrices, hover micro-animations, and clean fonts.
*   **Secure Stateless Auth**: Spring Security JWT configuration protecting personal views (User Profile, My Bookings, Favorites Wishlist).
*   **Role-Based Security Paths**: Restricts admin panels to `ROLE_ADMIN` and normal actions to `ROLE_USER`.
*   **Interactive Admin Dashboard**: Admin CRUD panels to create, edit, or delete tourist places, add coordinate parameters, review bookings, and respond to help desk queries.

---

## 9. Advantages

*   **Production-Ready Layer Decoupling**: Separation of database models, transfer entities, business components, and controllers guarantees ease of scaling.
*   **High Performance Client Processing**: Sorting by proximity is computed in the React DOM, saving database processor loads.
*   **Robust Data Integrity**: MySQL foreign constraints automatically cascade user deletions to clean up orphans.
*   **Cross-Device Local Testing**: Dynamic endpoint resolver in React configures APIs relative to the host browser IP, allowing teammates to access the system from local network connections.
*   **Complete documentation package**: Includes installation guides, visual system design documents, API collections, and database data dictionaries.

---

## 10. Future Enhancements

*   **Live Payment Gateway integration**: Embed dummy Stripe or Razorpay interfaces to complete mock invoice payments.
*   **Dynamic Route Planning**: Connect the Google Maps Directions API to display path navigations on the map canvas.
*   **Automated Email alerts**: Integrate Spring Mail to send ticket confirmation emails on booking approvals.
*   **Social logins**: Support OAuth2 integrations (Log in with Google, Facebook, etc.).
*   **Tour Guide matching**: Add features to let tourists select and book verified local guides.

---

## 11. Conclusion

The ExploreX Tourist Information and Booking project demonstrates how React, Spring Boot, and MySQL integrate to build a secure, scalable, and responsive travel portal. By combining standard Spring Security JWT authentication with real-time client-side Geolocation APIs and Google Maps integrations, the system bridges backend architecture with modern frontend features. Together, these modules serve as a solid, extensible foundation for real-world enterprise web applications.
