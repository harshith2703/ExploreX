package com.explorex.service;

import com.explorex.dto.AuthRequest;
import com.explorex.dto.AuthResponse;
import com.explorex.dto.RegisterRequest;

/**
 * Service interface for authentication operations.
 */
public interface AuthService {
    AuthResponse authenticateUser(AuthRequest authRequest);
    void registerUser(RegisterRequest registerRequest);
}
