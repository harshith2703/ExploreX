# ExploreX – UML and ER Diagrams

This document contains standard Mermaid diagrams representing the database schema, architecture flows, and use cases of the Tourist Information System.

---

## 1. Entity-Relationship (ER) Diagram

```mermaid
erDiagram
    users ||--o{ user_roles : "has"
    roles ||--o{ user_roles : "assigned"
    
    categories ||--o{ tourist_places : "classifies"
    tourist_places ||--o{ images : "has gallery"
    
    users ||--o{ reviews : "writes"
    tourist_places ||--o{ reviews : "receives"
    
    users ||--o{ favorites : "wishlists"
    tourist_places ||--o{ favorites : "added_to"
    
    users ||--o{ bookings : "makes"
    tourist_places ||--o{ bookings : "booked_for"

    users {
        bigint id PK
        varchar username
        varchar email
        varchar password
        varchar first_name
        varchar last_name
        varchar phone_number
        varchar profile_picture
        datetime created_at
        datetime updated_at
    }

    roles {
        bigint id PK
        varchar name
    }

    user_roles {
        bigint user_id PK, FK
        bigint role_id PK, FK
    }

    categories {
        bigint id PK
        varchar name
        text description
        datetime created_at
        datetime updated_at
    }

    tourist_places {
        bigint id PK
        varchar name
        text description
        varchar location
        varchar state
        varchar district
        double average_rating
        bigint category_id FK
        datetime created_at
        datetime updated_at
    }

    images {
        bigint id PK
        varchar image_url
        bigint tourist_place_id FK
        datetime created_at
    }

    reviews {
        bigint id PK
        int rating
        text comment
        bigint user_id FK
        bigint tourist_place_id FK
        datetime created_at
    }

    favorites {
        bigint id PK
        bigint user_id FK
        bigint tourist_place_id FK
        datetime created_at
    }

    bookings {
        bigint id PK
        bigint user_id FK
        bigint tourist_place_id FK
        datetime booking_date
        int number_of_people
        varchar status
        text special_requests
        datetime created_at
        datetime updated_at
    }

    contact_messages {
        bigint id PK
        varchar name
        varchar email
        varchar subject
        text message
        boolean replied
        datetime created_at
    }
```

---

## 2. Use Case Diagram

```mermaid
graph TD
    subgraph ExploreX Tourist Information System
        UC1(Register Account)
        UC2(Authenticate Login)
        UC3(Search/Filter Places)
        UC4(Post Review/Rating)
        UC5(Save Bookmark/Favorite)
        UC6(Book Guided Tour)
        UC7(Update Profile/Settings)
        
        UC8(Manage Tourist Place Cards)
        UC9(Manage Categories)
        UC10(Review Booking Requests)
        UC11(View Analytics Dashboard)
        UC12(Moderate Reviews/Users)
    end

    Tourist((Tourist User)) --> UC1
    Tourist --> UC2
    Tourist --> UC3
    Tourist --> UC4
    Tourist --> UC5
    Tourist --> UC6
    Tourist --> UC7

    Admin((System Admin)) --> UC2
    Admin --> UC8
    Admin --> UC9
    Admin --> UC10
    Admin --> UC11
    Admin --> UC12
```

---

## 3. Sequence Diagram (Authentication & Secured API Requests)

```mermaid
sequenceDiagram
    autonumber
    actor Client as React Client (Frontend)
    participant Auth as AuthController
    participant Provider as JwtTokenProvider
    participant Security as Security Filter Chain
    participant API as SecuredController

    Client->>Auth: POST /api/auth/login (credentials)
    Auth->>Provider: Generate Token (claims)
    Provider-->>Auth: JWT Access Token String
    Auth-->>Client: Returns JWT Token + User Roles
    Note over Client: Save token in LocalStorage
    
    Client->>Security: GET /api/user/profile (Auth: Bearer JWT)
    Security->>Provider: Validate & Parse Token
    Provider-->>Security: Valid Token (UserId signature)
    Security->>API: Forward Authorized Request
    API-->>Client: Return JSON User Details (200 OK)
```

---

## 4. Class Diagram (Clean Architecture Layering Pattern)

```mermaid
classDiagram
    class TouristPlace {
        +Long id
        +String name
        +String description
        +Double averageRating
        +Category category
        +List~Image~ images
    }

    class TouristPlaceRepository {
        <<interface>>
        +filterAndSearch(Long catId, String keyword, Sort sort) List
    }

    class TouristPlaceService {
        <<interface>>
        +createTouristPlace(TouristPlaceDto dto) TouristPlaceDto
        +getTouristPlaceById(Long id) TouristPlaceDto
        +searchAndFilterTouristPlaces(Long catId, String keyword, String sortBy) List
    }

    class TouristPlaceServiceImpl {
        -TouristPlaceRepository placeRepo
        -CategoryRepository catRepo
        +createTouristPlace(TouristPlaceDto dto) TouristPlaceDto
        +getTouristPlaceById(Long id) TouristPlaceDto
        +searchAndFilterTouristPlaces(Long catId, String keyword, String sortBy) List
    }

    class TouristPlaceController {
        -TouristPlaceService placeService
        +searchAndFilterPlaces(Long catId, String keyword, String sortBy) ResponseEntity
        +createTouristPlace(TouristPlaceDto dto) ResponseEntity
    }

    TouristPlaceController --> TouristPlaceService
    TouristPlaceServiceImpl ..|> TouristPlaceService
    TouristPlaceServiceImpl --> TouristPlaceRepository
    TouristPlaceRepository --> TouristPlace : queries
```

---

## 5. Deployment Diagram

```mermaid
graph LR
    subgraph Client Tier
        React[Vite React SPA<br/>Port: 5173]
    end

    subgraph Application Tier
        SpringBoot[Spring Boot REST APIs<br/>Port: 8080]
        SpringSecurity[Spring Security + JWT<br/>Auth Filter]
    end

    subgraph Data Tier
        MySQL[(MySQL 8.0 Server<br/>Port: 3306)]
    end

    React -- HTTP REST / JSON --> SpringSecurity
    SpringSecurity --> SpringBoot
    SpringBoot -- Spring Data JPA / Hibernate --> MySQL
```
