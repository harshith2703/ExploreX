package com.explorex.service;

import com.explorex.dto.BookingDto;

import java.util.List;

/**
 * Service interface for Booking operations.
 */
public interface BookingService {
    BookingDto createBooking(Long userId, BookingDto bookingDto);
    List<BookingDto> getBookingsByUserId(Long userId);
    List<BookingDto> getAllBookings();
    BookingDto updateBookingStatus(Long bookingId, String status);
    void cancelBooking(Long userId, Long bookingId);
}
