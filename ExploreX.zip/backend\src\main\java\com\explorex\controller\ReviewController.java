package com.explorex.controller;

import com.explorex.dto.ReviewDto;
import com.explorex.security.UserPrincipal;
import com.explorex.service.ReviewService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Controller exposing Review APIs.
 */
@RestController
public class ReviewController {

    @Autowired
    private ReviewService reviewService;

    // Public endpoint
    @GetMapping("/api/reviews/place/{placeId}")
    public ResponseEntity<List<ReviewDto>> getReviewsByPlaceId(@PathVariable Long placeId) {
        List<ReviewDto> reviews = reviewService.getReviewsByPlaceId(placeId);
        return ResponseEntity.ok(reviews);
    }

    // Authenticated endpoints
    @PostMapping("/api/reviews")
    public ResponseEntity<ReviewDto> addReview(
            @AuthenticationPrincipal UserPrincipal userPrincipal,
            @Valid @RequestBody ReviewDto reviewDto) {
        ReviewDto savedReview = reviewService.addReview(userPrincipal.getId(), reviewDto);
        return new ResponseEntity<>(savedReview, HttpStatus.CREATED);
    }

    @GetMapping("/api/reviews/my-reviews")
    public ResponseEntity<List<ReviewDto>> getMyReviews(@AuthenticationPrincipal UserPrincipal userPrincipal) {
        List<ReviewDto> reviews = reviewService.getReviewsByUserId(userPrincipal.getId());
        return ResponseEntity.ok(reviews);
    }

    // Admin secured deleting endpoints (Also mapped under /api/admin/reviews for security configurations consistency)
    @DeleteMapping("/api/admin/reviews/{id}")
    public ResponseEntity<Map<String, String>> deleteReviewByAdmin(@PathVariable Long id) {
        reviewService.deleteReview(id);
        Map<String, String> response = new HashMap<>();
        response.put("message", "Review deleted successfully by Admin!");
        return ResponseEntity.ok(response);
    }

    // User delete own review endpoint
    @DeleteMapping("/api/reviews/{id}")
    public ResponseEntity<Map<String, String>> deleteMyReview(
            @PathVariable Long id,
            @AuthenticationPrincipal UserPrincipal userPrincipal) {
        // Retrieve review details to check ownership
        List<ReviewDto> userReviews = reviewService.getReviewsByUserId(userPrincipal.getId());
        boolean ownsReview = userReviews.stream().anyMatch(r -> r.getId().equals(id));

        if (!ownsReview) {
            Map<String, String> response = new HashMap<>();
            response.put("error", "You do not have permission to delete this review!");
            return new ResponseEntity<>(response, HttpStatus.FORBIDDEN);
        }

        reviewService.deleteReview(id);
        Map<String, String> response = new HashMap<>();
        response.put("message", "Your review was deleted successfully!");
        return ResponseEntity.ok(response);
    }
}
