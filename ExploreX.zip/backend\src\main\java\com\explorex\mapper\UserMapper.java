package com.explorex.mapper;

import com.explorex.dto.UserProfileDto;
import com.explorex.entity.Role;
import com.explorex.entity.User;

import java.util.ArrayList;
import java.util.stream.Collectors;

/**
 * Mapper utility to convert between User entities and UserProfileDtos.
 */
public class UserMapper {

    public static UserProfileDto toDto(User user) {
        if (user == null) {
            return null;
        }

        UserProfileDto dto = new UserProfileDto();
        dto.setId(user.getId());
        dto.setUsername(user.getUsername());
        dto.setEmail(user.getEmail());
        dto.setFirstName(user.getFirstName());
        dto.setLastName(user.getLastName());
        dto.setPhoneNumber(user.getPhoneNumber());
        dto.setProfilePicture(user.getProfilePicture());

        if (user.getRoles() != null) {
            dto.setRoles(user.getRoles().stream()
                    .map(role -> role.getName().name())
                    .collect(Collectors.toList()));
        } else {
            dto.setRoles(new ArrayList<>());
        }

        return dto;
    }
}
