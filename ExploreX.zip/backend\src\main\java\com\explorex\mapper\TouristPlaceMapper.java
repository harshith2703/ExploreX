package com.explorex.mapper;

import com.explorex.dto.TouristPlaceDto;
import com.explorex.entity.Image;
import com.explorex.entity.TouristPlace;

import java.util.ArrayList;
import java.util.stream.Collectors;

/**
 * Mapper utility to convert between TouristPlace entities and DTOs.
 */
public class TouristPlaceMapper {

    public static TouristPlaceDto toDto(TouristPlace touristPlace) {
        if (touristPlace == null) {
            return null;
        }

        TouristPlaceDto dto = new TouristPlaceDto();
        dto.setId(touristPlace.getId());
        dto.setName(touristPlace.getName());
        dto.setDescription(touristPlace.getDescription());
        dto.setLocation(touristPlace.getLocation());
        dto.setState(touristPlace.getState());
        dto.setDistrict(touristPlace.getDistrict());
        dto.setAverageRating(touristPlace.getAverageRating());
        dto.setLatitude(touristPlace.getLatitude());
        dto.setLongitude(touristPlace.getLongitude());

        if (touristPlace.getCategory() != null) {
            dto.setCategoryId(touristPlace.getCategory().getId());
            dto.setCategoryName(touristPlace.getCategory().getName());
        }

        if (touristPlace.getImages() != null) {
            dto.setImageUrls(touristPlace.getImages().stream()
                    .map(Image::getImageUrl)
                    .collect(Collectors.toList()));
        } else {
            dto.setImageUrls(new ArrayList<>());
        }

        return dto;
    }

    public static TouristPlace toEntity(TouristPlaceDto dto) {
        if (dto == null) {
            return null;
        }

        TouristPlace touristPlace = new TouristPlace();
        touristPlace.setId(dto.getId());
        touristPlace.setName(dto.getName());
        touristPlace.setDescription(dto.getDescription());
        touristPlace.setLocation(dto.getLocation());
        touristPlace.setState(dto.getState());
        touristPlace.setDistrict(dto.getDistrict());
        touristPlace.setLatitude(dto.getLatitude());
        touristPlace.setLongitude(dto.getLongitude());
        // Category will be resolved in Service layer
        return touristPlace;
    }
}
