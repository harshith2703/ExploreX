package com.explorex.service;

import com.explorex.dto.DashboardStatsDto;

/**
 * Service interface for retrieving dashboard statistical counters.
 */
public interface DashboardService {
    DashboardStatsDto getDashboardStats();
}
