package com.explorex.repository;

import com.explorex.entity.TouristPlace;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Spring Data Repository for the {@link TouristPlace} entity.
 */
@Repository
public interface TouristPlaceRepository extends JpaRepository<TouristPlace, Long> {

    @Query("SELECT t FROM TouristPlace t WHERE " +
            "(:categoryId IS NULL OR t.category.id = :categoryId) AND " +
            "(:keyword IS NULL OR t.name LIKE %:keyword% OR t.location LIKE %:keyword% OR t.state LIKE %:keyword% OR t.district LIKE %:keyword%)")
    List<TouristPlace> filterAndSearch(
            @Param("categoryId") Long categoryId,
            @Param("keyword") String keyword,
            Sort sort
    );

    List<TouristPlace> findByCategoryId(Long categoryId);
}
