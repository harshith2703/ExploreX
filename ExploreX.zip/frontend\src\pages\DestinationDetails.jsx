import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import api from '../services/api';

const DestinationDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();
  
  const [place, setPlace] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [isFav, setIsFav] = useState(false);
  const [loading, setLoading] = useState(true);
  const [activeImage, setActiveImage] = useState('');
  
  // Geolocation and Distance States
  const [userCoords, setUserCoords] = useState(null);

  const calculateDistance = (lat1, lon1, lat2, lon2) => {
    if (!lat1 || !lon1 || !lat2 || !lon2) return null;
    const R = 6371; // km
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLon = ((lon2 - lon1) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((lat1 * Math.PI) / 180) *
        Math.cos((lat2 * Math.PI) / 180) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return parseFloat((R * c).toFixed(1));
  };

  const distance = place && userCoords ? calculateDistance(userCoords.lat, userCoords.lng, place.latitude, place.longitude) : null;

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setUserCoords({
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
          });
        },
        (error) => {
          console.warn('Geolocation access rejected in details:', error.message);
        }
      );
    }
  }, []);

  // Booking Form State
  const [bookingDate, setBookingDate] = useState('');
  const [numberOfPeople, setNumberOfPeople] = useState(1);
  const [specialRequests, setSpecialRequests] = useState('');
  const [bookingSuccess, setBookingSuccess] = useState('');
  const [bookingError, setBookingError] = useState('');

  // Review Form State
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [reviewSuccess, setReviewSuccess] = useState('');
  const [reviewError, setReviewError] = useState('');

  const fetchPlaceData = async () => {
    try {
      const placeRes = await api.get(`/places/${id}`);
      setPlace(placeRes.data);
      setActiveImage(placeRes.data.imageUrls?.[0] || 'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?w=800');

      const reviewsRes = await api.get(`/reviews/place/${id}`);
      setReviews(reviewsRes.data);

      if (isAuthenticated) {
        const favRes = await api.get(`/favorites/check?placeId=${id}`);
        setIsFav(favRes.data.isFavorite);
      }
    } catch (error) {
      console.error('Error loading destination details:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPlaceData();
  }, [id, isAuthenticated]);

  const handleFavoriteToggle = async () => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }

    try {
      if (isFav) {
        await api.delete(`/favorites/remove?placeId=${id}`);
        setIsFav(false);
      } else {
        await api.post(`/favorites/add?placeId=${id}`);
        setIsFav(true);
      }
    } catch (error) {
      console.error('Error toggling bookmark status:', error);
    }
  };

  const handleBookingSubmit = async (e) => {
    e.preventDefault();
    setBookingSuccess('');
    setBookingError('');

    if (!isAuthenticated) {
      navigate('/login');
      return;
    }

    if (!bookingDate) {
      setBookingError('Please select a valid scheduled date.');
      return;
    }

    try {
      const bookingPayload = {
        touristPlaceId: id,
        bookingDate: `${bookingDate}T09:00:00`,
        numberOfPeople,
        specialRequests
      };
      await api.post('/bookings', bookingPayload);
      setBookingSuccess('Booking package requested successfully! View status in dashboard.');
      setBookingDate('');
      setNumberOfPeople(1);
      setSpecialRequests('');
    } catch (error) {
      const msg = error.response?.data?.message || 'Error processing tour booking request.';
      setBookingError(msg);
    }
  };

  const handleReviewSubmit = async (e) => {
    e.preventDefault();
    setReviewSuccess('');
    setReviewError('');

    if (!isAuthenticated) {
      navigate('/login');
      return;
    }

    if (!comment.trim()) {
      setReviewError('Please write review comments.');
      return;
    }

    try {
      const reviewPayload = {
        rating,
        comment,
        touristPlaceId: id
      };
      await api.post('/reviews', reviewPayload);
      setReviewSuccess('Thank you! Review published successfully.');
      setComment('');
      setRating(5);
      // Refresh details to update star averages and reviews list
      fetchPlaceData();
    } catch (error) {
      const msg = error.response?.data?.message || 'You can only review each destination once!';
      setReviewError(msg);
    }
  };

  if (loading) {
    return (
      <div className="text-center py-5">
        <div className="spinner-border text-success" role="status" style={{ width: '3rem', height: '3rem' }}>
          <span className="visually-hidden">Loading destination...</span>
        </div>
      </div>
    );
  }

  if (!place) {
    return (
      <div className="container py-5 text-center">
        <h3 className="fw-bold">Destination Not Found</h3>
        <p className="text-muted">The requested tourist place could not be resolved.</p>
        <Link to="/destinations" className="btn btn-explore rounded-pill px-4">Back to Destinations</Link>
      </div>
    );
  }

  return (
    <div className="container py-5">
      {/* 1. Header Navigation and Title */}
      <div className="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-4 gap-3">
        <div>
          <span className="text-uppercase small fw-bold text-success mb-1 d-block">{place.categoryName}</span>
          <h1 className="fw-bold display-4 mb-1 text-dark">{place.name}</h1>
          <p className="text-secondary mb-0 d-flex align-items-center flex-wrap gap-2">
            <span><i className="bi bi-geo-alt-fill text-danger me-1"></i>{place.location}, {place.district}, {place.state}</span>
            {distance !== null && (
              <span className="badge bg-success text-white rounded-pill fw-bold" style={{ fontSize: '12px' }}>
                <i className="bi bi-pin-map-fill me-1"></i>{distance} km away from your location
              </span>
            )}
          </p>
        </div>

        {/* Favorite heart toggle button */}
        <button
          onClick={handleFavoriteToggle}
          className={`btn d-flex align-items-center gap-2 px-4 py-2 rounded-pill shadow-sm border ${
            isFav ? 'bg-danger text-white border-danger' : 'bg-white text-danger border-danger'
          }`}
          style={{ transition: 'all 0.3s' }}
        >
          <i className={`bi ${isFav ? 'bi-heart-fill' : 'bi-heart'} fs-5`}></i>
          <span className="fw-semibold">{isFav ? 'Saved to Favorites' : 'Save to Wishlist'}</span>
        </button>
      </div>

      <div className="row g-4">
        {/* Left Side: Image Gallery & Details Column */}
        <div className="col-lg-8">
          {/* Main Display Image */}
          <div className="card shadow-sm border-0 overflow-hidden mb-3" style={{ borderRadius: '20px' }}>
            <img
              src={activeImage}
              alt={place.name}
              className="img-fluid"
              style={{ width: '100%', height: '420px', objectFit: 'cover' }}
            />
          </div>

          {/* Gallery Thumbnails List */}
          {place.imageUrls && place.imageUrls.length > 0 && (
            <div className="d-flex gap-2 overflow-auto pb-3 mb-4">
              {place.imageUrls.map((url, idx) => (
                <img
                  key={idx}
                  src={url}
                  alt={`Thumbnail ${idx + 1}`}
                  onClick={() => setActiveImage(url)}
                  className={`rounded-3 img-thumbnail border-2 cursor-pointer ${
                    activeImage === url ? 'border-primary' : 'border-light'
                  }`}
                  style={{ width: '90px', height: '65px', objectFit: 'cover', cursor: 'pointer' }}
                />
              ))}
            </div>
          )}

          {/* Description Card */}
          <div className="card shadow-sm border-0 p-4 mb-4" style={{ borderRadius: '16px' }}>
            <h4 className="fw-bold text-dark mb-3">About Destination</h4>
            <p className="text-secondary leading-relaxed mb-0" style={{ whiteSpace: 'pre-line' }}>{place.description}</p>
          </div>

          {/* Location & Map Section */}
          <div className="card shadow-sm border-0 p-4 mb-4" style={{ borderRadius: '16px' }}>
            <h4 className="fw-bold text-dark mb-3">
              <i className="bi bi-map-fill text-success me-2"></i>Location Map
            </h4>
            <div className="ratio ratio-21x9 rounded-3 overflow-hidden border shadow-sm" style={{ minHeight: '300px' }}>
              <iframe
                title={`Map of ${place.name}`}
                src={place.latitude && place.longitude ? `https://maps.google.com/maps?q=${place.latitude},${place.longitude}&t=&z=14&ie=UTF8&iwloc=&output=embed` : `https://maps.google.com/maps?q=${encodeURIComponent(place.name + ", " + place.location + ", " + place.state)}&t=&z=14&ie=UTF8&iwloc=&output=embed`}
                style={{ border: 0 }}
                allowFullScreen=""
                loading="lazy"
              ></iframe>
            </div>
            <div className="mt-3 d-flex align-items-center justify-content-between flex-wrap gap-2">
              <span className="text-muted small">
                <i className="bi bi-info-circle me-1"></i> Interactive map centered at {place.name}. {place.latitude && place.longitude ? `(${place.latitude}, ${place.longitude})` : ''}
              </span>
              <a
                href={place.latitude && place.longitude ? `https://www.google.com/maps/search/?api=1&query=${place.latitude},${place.longitude}` : `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(place.name + ", " + place.location + ", " + place.state)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-outline-success btn-sm rounded-pill px-3 fw-semibold"
              >
                <i className="bi bi-box-arrow-up-right me-1"></i> Open in Google Maps
              </a>
            </div>
          </div>

          {/* Reviews Rating Section */}
          <div className="card shadow-sm border-0 p-4 mb-4" style={{ borderRadius: '16px' }}>
            <div className="d-flex justify-content-between align-items-center mb-4">
              <h4 className="fw-bold text-dark mb-0">Traveler Reviews</h4>
              <span className="rating-badge fs-5">
                <i className="bi bi-star-fill text-warning"></i>
                {place.averageRating ? `${place.averageRating} / 5.0` : 'No reviews yet'}
              </span>
            </div>

            {/* Individual Reviews Cards */}
            {reviews.length === 0 ? (
              <div className="text-center py-4 bg-light rounded-3">
                <i className="bi bi-chat-text text-muted fs-2"></i>
                <p className="text-muted mb-0 mt-2">No reviews posted yet. Be the first one to share your travel experience!</p>
              </div>
            ) : (
              <div className="d-flex flex-column gap-3 mb-4">
                {reviews.map((rev) => (
                  <div className="p-3 bg-light rounded-3 shadow-sm border-start border-4 border-primary" key={rev.id}>
                    <div className="d-flex justify-content-between align-items-center mb-2">
                      <div className="d-flex align-items-center gap-2">
                        <img
                          src={rev.userProfilePic || `https://api.dicebear.com/7.x/pixel-art/svg?seed=${rev.username}`}
                          alt={rev.username}
                          className="rounded-circle"
                          style={{ width: '32px', height: '32px', objectFit: 'cover' }}
                        />
                        <span className="fw-bold text-dark small">{rev.username}</span>
                      </div>
                      <span className="text-warning">
                        {Array.from({ length: rev.rating }).map((_, i) => (
                          <i key={i} className="bi bi-star-fill small"></i>
                        ))}
                        {Array.from({ length: 5 - rev.rating }).map((_, i) => (
                          <i key={i} className="bi bi-star small text-muted"></i>
                        ))}
                      </span>
                    </div>
                    <p className="text-secondary small mb-1">{rev.comment}</p>
                    <small className="text-muted text-uppercase" style={{ fontSize: '0.65rem' }}>
                      Published: {new Date(rev.createdAt).toLocaleDateString()}
                    </small>
                  </div>
                ))}
              </div>
            )}

            {/* Submit Review Card */}
            <hr className="my-4" />
            <h5 className="fw-bold text-dark mb-3">Add Your Review</h5>
            {reviewSuccess && <div className="alert alert-success border-0 small py-2 rounded-pill text-center">{reviewSuccess}</div>}
            {reviewError && <div className="alert alert-danger border-0 small py-2 rounded-pill text-center">{reviewError}</div>}

            <form onSubmit={handleReviewSubmit}>
              <div className="row g-3">
                <div className="col-md-4">
                  <label className="form-label small fw-semibold text-secondary">Rating Stars</label>
                  <select
                    className="form-select bg-light border-0"
                    value={rating}
                    onChange={(e) => setRating(Number(e.target.value))}
                  >
                    <option value={5}>5 Stars (Excellent)</option>
                    <option value={4}>4 Stars (Good)</option>
                    <option value={3}>3 Stars (Average)</option>
                    <option value={2}>2 Stars (Poor)</option>
                    <option value={1}>1 Star (Terrible)</option>
                  </select>
                </div>
                <div className="col-md-8">
                  <label className="form-label small fw-semibold text-secondary">Review comments</label>
                  <textarea
                    rows="2"
                    className="form-control bg-light border-0"
                    placeholder="Share your personal review about food, transport, guide..."
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                  ></textarea>
                </div>
              </div>
              <button type="submit" className="btn btn-explore rounded-pill px-4 mt-3">Submit Review</button>
            </form>
          </div>
        </div>

        {/* Right Side: Booking Form Column */}
        <div className="col-lg-4">
          <div className="card shadow-sm border-0 p-4 sticky-lg-top" style={{ borderRadius: '16px', top: '100px' }}>
            <h4 className="fw-bold text-dark mb-2">Book Guided Tour</h4>
            <p className="text-muted small mb-4">Request customizable guided travel packages verified by ExploreX agents.</p>

            {bookingSuccess && <div className="alert alert-success border-0 small py-2 text-center rounded-3">{bookingSuccess}</div>}
            {bookingError && <div className="alert alert-danger border-0 small py-2 text-center rounded-3">{bookingError}</div>}

            <form onSubmit={handleBookingSubmit}>
              {/* Trip Date Selector */}
              <div className="mb-3">
                <label className="form-label small fw-semibold text-secondary">Schedule Travel Date</label>
                <div className="input-group">
                  <span className="input-group-text bg-light border-0"><i className="bi bi-calendar-event"></i></span>
                  <input
                    type="date"
                    className="form-control bg-light border-0"
                    min={new Date().toISOString().split('T')[0]} // Blocks past booking dates
                    value={bookingDate}
                    onChange={(e) => setBookingDate(e.target.value)}
                  />
                </div>
              </div>

              {/* Traveler Counts */}
              <div className="mb-3">
                <label className="form-label small fw-semibold text-secondary">Number of People</label>
                <div className="input-group">
                  <span className="input-group-text bg-light border-0"><i className="bi bi-people"></i></span>
                  <input
                    type="number"
                    className="form-control bg-light border-0"
                    min="1"
                    value={numberOfPeople}
                    onChange={(e) => setNumberOfPeople(Math.max(1, Number(e.target.value)))}
                  />
                </div>
              </div>

              {/* Special instructions */}
              <div className="mb-4">
                <label className="form-label small fw-semibold text-secondary">Special Requests / Notes</label>
                <textarea
                  rows="3"
                  className="form-control bg-light border-0"
                  placeholder="Need local translation guides, specific dietary foods, or custom hotel pickups?"
                  value={specialRequests}
                  onChange={(e) => setSpecialRequests(e.target.value)}
                ></textarea>
              </div>

              <button type="submit" className="btn btn-explore-green w-100 rounded-pill py-2 shadow fw-bold">
                Book Package Now
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DestinationDetails;
