import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Layout = ({ children }) => {
  const { user, isAuthenticated, isAdmin, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <div className="d-flex flex-column min-vh-100">
      {/* Dynamic Header Navbar */}
      <nav className="navbar navbar-expand-lg sticky-top shadow-sm" style={{ backgroundColor: 'var(--primary-blue)', borderBottom: '3px solid var(--primary-green)' }}>
        <div className="container">
          {/* Logo brand */}
          <Link className="navbar-brand d-flex align-items-center text-white gap-2" to="/">
            <img src="/favicon.svg" alt="ExploreX Logo" width="32" height="32" className="d-inline-block align-middle" />
            <span className="fs-4 brand-font text-white tracking-wider">Explore<span style={{ color: 'var(--primary-green)' }}>X</span></span>
          </Link>

          {/* Toggle buttons for mobile */}
          <button className="navbar-toggler border-0 text-white" type="button" data-bs-toggle="collapse" data-bs-target="#explorexNavbar" aria-controls="explorexNavbar" aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon" style={{ filter: 'invert(1)' }}></span>
          </button>

          <div className="collapse navbar-collapse" id="explorexNavbar">
            <ul className="navbar-nav mx-auto mb-2 mb-lg-0 gap-lg-3">
              <li className="nav-item">
                <Link className="nav-link text-white fw-medium" to="/">Home</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link text-white fw-medium" to="/destinations">Destinations</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link text-white fw-medium" to="/explore-map">Explore Map</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link text-white fw-medium" to="/about">About Us</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link text-white fw-medium" to="/contact">Contact</Link>
              </li>
            </ul>

            {/* Profile management indicators */}
            <div className="d-flex align-items-center gap-3">
              {isAuthenticated ? (
                <div className="dropdown">
                  <button className="btn btn-outline-light dropdown-toggle d-flex align-items-center gap-2 px-3 rounded-pill" type="button" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                    <i className="bi bi-person-circle fs-5"></i>
                    <span>Hi, {user.username}</span>
                  </button>
                  <ul className="dropdown-menu dropdown-menu-end shadow border-0 mt-2" aria-labelledby="profileDropdown" style={{ borderRadius: '12px' }}>
                    {isAdmin && (
                      <li>
                        <Link className="dropdown-item fw-semibold text-primary" to="/admin">
                          <i className="bi bi-speedometer2 me-2"></i>Admin Dashboard
                        </Link>
                      </li>
                    )}
                    <li>
                      <Link className="dropdown-item" to="/profile">
                        <i className="bi bi-person-badge me-2"></i>My Profile
                      </Link>
                    </li>
                    <li>
                      <Link className="dropdown-item" to="/dashboard">
                        <i className="bi bi-journal-check me-2"></i>My Bookings
                      </Link>
                    </li>
                    <li>
                      <Link className="dropdown-item" to="/favorites">
                        <i className="bi bi-heart-fill text-danger me-2"></i>Saved Places
                      </Link>
                    </li>
                    <li><hr className="dropdown-divider" /></li>
                    <li>
                      <button className="dropdown-item text-danger fw-semibold" onClick={handleLogout}>
                        <i className="bi bi-box-arrow-right me-2"></i>Log Out
                      </button>
                    </li>
                  </ul>
                </div>
              ) : (
                <div className="d-flex align-items-center gap-2">
                  <Link className="btn btn-link text-white text-decoration-none fw-medium" to="/login">Login</Link>
                  <Link className="btn btn-explore-green rounded-pill text-white px-4" to="/register">Sign Up</Link>
                </div>
              )}
            </div>
          </div>
        </div>
      </nav>

      {/* Main Section Content */}
      <main className="flex-grow-1">
        {children}
      </main>

      {/* Footer Design */}
      <footer className="text-white mt-auto pt-5 pb-4" style={{ backgroundColor: 'var(--dark-slate)', borderTop: '4px solid var(--primary-blue)' }}>
        <div className="container text-md-start">
          <div className="row text-center text-md-start">
            {/* Logo and mission statement */}
            <div className="col-md-3 col-lg-3 col-xl-3 mx-auto mt-3">
              <h5 className="text-uppercase mb-4 font-weight-bold text-white brand-font">Explore<span style={{ color: 'var(--primary-green)' }}>X</span></h5>
              <p className="text-white-50 small">
                ExploreX is a premium tourist information platform created to guide travelers through breathtaking destinations, simplify bookings, and gather authentic traveler reviews.
              </p>
            </div>

            {/* Quick Links */}
            <div className="col-md-2 col-lg-2 col-xl-2 mx-auto mt-3">
              <h6 className="text-uppercase mb-4 font-weight-bold text-white">Quick Links</h6>
              <p className="mb-2"><Link to="/destinations" className="text-white-50 text-decoration-none hover-green">Explore Places</Link></p>
              <p className="mb-2"><Link to="/about" className="text-white-50 text-decoration-none">About India</Link></p>
              <p className="mb-2"><Link to="/contact" className="text-white-50 text-decoration-none">Support Desk</Link></p>
            </div>

            {/* Contact details */}
            <div className="col-md-4 col-lg-3 col-xl-3 mx-auto mt-3">
              <h6 className="text-uppercase mb-4 font-weight-bold text-white">Contact</h6>
              <p className="text-white-50 mb-2"><i className="bi bi-geo-alt-fill me-2"></i> Panaji, Goa, India - 403001</p>
              <p className="text-white-50 mb-2"><i className="bi bi-envelope-fill me-2"></i> info@explorex.com</p>
              <p className="text-white-50 mb-2"><i className="bi bi-phone-fill me-2"></i> +91 98765 43210</p>
            </div>

            {/* Social handles */}
            <div className="col-md-3 col-lg-3 col-xl-3 mx-auto mt-3 text-center text-md-start">
              <h6 className="text-uppercase mb-4 font-weight-bold text-white">Connect with Us</h6>
              <div className="d-flex gap-3 justify-content-center justify-content-md-start">
                <a href="#" className="text-white fs-4"><i className="bi bi-facebook"></i></a>
                <a href="#" className="text-white fs-4"><i className="bi bi-instagram"></i></a>
                <a href="#" className="text-white fs-4"><i className="bi bi-twitter-x"></i></a>
                <a href="#" className="text-white fs-4"><i className="bi bi-youtube"></i></a>
              </div>
            </div>
          </div>

          <hr className="mb-4 mt-4" style={{ borderColor: 'rgba(255,255,255,0.1)' }} />

          <div className="row align-items-center">
            <div className="col-md-7 col-lg-8 text-center text-md-start">
              <p className="text-white-50 small mb-0">© 2026 ExploreX Tourist Information System. Final Year College Project. All Rights Reserved.</p>
            </div>
            <div className="col-md-5 col-lg-4 text-center text-md-end">
              <p className="text-white-50 small mb-0">Built with Spring Boot, React, & MySQL</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
