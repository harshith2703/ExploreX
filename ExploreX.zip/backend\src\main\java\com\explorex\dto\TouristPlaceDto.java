package com.explorex.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.util.List;

/**
 * DTO representing detailed tourist place details.
 */
public class TouristPlaceDto {

    private Long id;

    @NotBlank(message = "Name is required")
    private String name;

    @NotBlank(message = "Description is required")
    private String description;

    @NotBlank(message = "Location is required")
    private String location;

    @NotBlank(message = "State is required")
    private String state;

    @NotBlank(message = "District is required")
    private String district;

    private Double averageRating;

    private Double latitude;

    private Double longitude;

    @NotNull(message = "Category ID is required")
    private Long categoryId;

    private String categoryName;

    private List<String> imageUrls;

    public TouristPlaceDto() {}

    public TouristPlaceDto(Long id, String name, String description, String location, String state, String district, Double averageRating, Double latitude, Double longitude, Long categoryId, String categoryName, List<String> imageUrls) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.location = location;
        this.state = state;
        this.district = district;
        this.averageRating = averageRating;
        this.latitude = latitude;
        this.longitude = longitude;
        this.categoryId = categoryId;
        this.categoryName = categoryName;
        this.imageUrls = imageUrls;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public Double getAverageRating() {
        return averageRating;
    }

    public void setAverageRating(Double averageRating) {
        this.averageRating = averageRating;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public Long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public List<String> getImageUrls() {
        return imageUrls;
    }

    public void setImageUrls(List<String> imageUrls) {
        this.imageUrls = imageUrls;
    }

    @Override
    public String toString() {
        return "TouristPlaceDto(id='" + id + "', name='" + name + "', description='" + description + "', location='" + location + "', state='" + state + "', district='" + district + "', averageRating='" + averageRating + "', latitude='" + latitude + "', longitude='" + longitude + "', categoryId='" + categoryId + "', categoryName='" + categoryName + "', imageUrls='" + imageUrls + "')";
    }
}
