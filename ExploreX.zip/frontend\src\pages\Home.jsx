import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import api from '../services/api';

const Home = () => {
  const [categories, setCategories] = useState([]);
  const [featuredPlaces, setFeaturedPlaces] = useState([]);
  const [searchKeyword, setSearchKeyword] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    // Fetch categories and top featured tourist places on mount
    const fetchHomeData = async () => {
      try {
        const catRes = await api.get('/categories');
        setCategories(catRes.data);

        // Fetch places with sorting by rating to fetch featured places
        const placesRes = await api.get('/places?sortBy=rating');
        // Get the top 3 highest rated places
        setFeaturedPlaces(placesRes.data.slice(0, 3));
      } catch (error) {
        console.error('Error fetching home page resources:', error);
      }
    };
    fetchHomeData();
  }, []);

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    if (searchKeyword.trim()) {
      navigate(`/destinations?keyword=${encodeURIComponent(searchKeyword.trim())}`);
    } else {
      navigate('/destinations');
    }
  };

  // Maps category names to Bootstrap icon tags dynamically
  const getCategoryIcon = (name) => {
    switch (name.toLowerCase()) {
      case 'beaches': return 'bi-tsunami text-info';
      case 'mountains': return 'bi-mountains text-success';
      case 'heritage': return 'bi-bank text-warning';
      case 'wildlife': return 'bi-trees text-success';
      default: return 'bi-compass text-primary';
    }
  };

  return (
    <div>
      {/* 1. Hero Section */}
      <section className="hero-banner d-flex align-items-center text-white text-center">
        <div className="container position-relative z-3">
          <div className="row justify-content-center">
            <div className="col-md-9 col-lg-8">
              <h1 className="display-4 fw-bold text-white mb-3 italic-header">Discover Incredible India</h1>
              <p className="lead text-white-50 mb-5">Explore sun-kissed coastlines, mist-clad peaks, and ancient monuments. Plan your journey with ExploreX.</p>
              
              {/* Search Bar Widget */}
              <form onSubmit={handleSearchSubmit} className="glass-panel p-3 shadow-lg d-flex flex-column flex-md-row gap-2">
                <div className="input-group flex-grow-1">
                  <span className="input-group-text bg-transparent border-0 text-dark"><i className="bi bi-search fs-5"></i></span>
                  <input
                    type="text"
                    className="form-control border-0 bg-transparent text-dark fs-5 py-2"
                    placeholder="Search by place name, state, location..."
                    value={searchKeyword}
                    onChange={(e) => setSearchKeyword(e.target.value)}
                    style={{ outline: 'none', boxShadow: 'none' }}
                  />
                </div>
                <button type="submit" className="btn btn-explore-green btn-lg px-4 rounded-pill">Search</button>
              </form>
            </div>
          </div>
        </div>
        {/* Background hero image fallback */}
        <div className="position-absolute top-0 start-0 w-100 h-100 z-1" style={{ 
          backgroundImage: 'url("https://images.unsplash.com/photo-1548013146-72479768bada?w=1600")', 
          backgroundSize: 'cover', 
          backgroundPosition: 'center' 
        }}></div>
      </section>

      {/* 2. Popular Categories */}
      <section className="container py-5">
        <div className="text-center mb-5">
          <h2 className="display-5 fw-bold">Popular Categories</h2>
          <p className="text-muted">Choose your travel interest and explore matching destinations</p>
        </div>

        <div className="row g-4 justify-content-center">
          {categories.map((category) => (
            <div className="col-6 col-md-3" key={category.id}>
              <Link to={`/destinations?categoryId=${category.id}`} className="text-decoration-none">
                <div className="card explore-card text-center p-4 h-100 border-0 shadow-sm align-items-center justify-content-center">
                  <div className="icon-circle mb-3">
                    <i className={`bi ${getCategoryIcon(category.name)} fs-3`}></i>
                  </div>
                  <h5 className="fw-bold mb-1 text-dark">{category.name}</h5>
                  <p className="text-muted small mb-0 truncate-description" style={{ maxHeight: '40px', overflow: 'hidden' }}>{category.description}</p>
                </div>
              </Link>
            </div>
          ))}
        </div>
      </section>

      {/* 3. Featured Destinations */}
      <section className="bg-light py-5">
        <div className="container">
          <div className="d-flex justify-content-between align-items-end mb-5">
            <div>
              <h2 className="fw-bold display-5">Featured Places</h2>
              <p className="text-muted mb-0">Check out the top-rated traveler destinations across the country</p>
            </div>
            <Link to="/destinations" className="btn btn-outline-primary rounded-pill px-4 fw-semibold">View All</Link>
          </div>

          <div className="row g-4">
            {featuredPlaces.map((place) => (
              <div className="col-md-4" key={place.id}>
                <div className="card explore-card border-0 h-100 shadow-sm">
                  <div className="position-relative">
                    <img
                      src={place.imageUrls?.[0] || 'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?w=800'}
                      alt={place.name}
                      className="card-img-top"
                      style={{ height: '220px', objectFit: 'cover' }}
                    />
                    <div className="position-absolute top-0 end-0 m-3">
                      <span className="rating-badge shadow-sm">
                        <i className="bi bi-star-fill text-warning"></i>
                        {place.averageRating || 'New'}
                      </span>
                    </div>
                  </div>
                  <div className="card-body p-4 d-flex flex-column">
                    <span className="text-uppercase small fw-bold text-success mb-2">{place.categoryName}</span>
                    <h4 className="card-title fw-bold text-dark mb-2">{place.name}</h4>
                    <p className="text-secondary small mb-3"><i className="bi bi-geo-alt-fill text-danger me-1"></i>{place.location}, {place.state}</p>
                    <p className="text-muted small flex-grow-1 card-text-truncate" style={{ display: '-webkit-box', WebkitLineClamp: 3, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
                      {place.description}
                    </p>
                    <Link to={`/places/${place.id}`} className="btn btn-explore w-100 rounded-pill mt-3">Explore Details</Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 4. Statistics Block */}
      <section className="container py-5">
        <div className="card glass-panel border-0 shadow-lg text-white p-5 position-relative overflow-hidden" style={{ backgroundColor: 'var(--primary-blue)', borderRadius: '24px' }}>
          <div className="row text-center g-4 position-relative z-3">
            <div className="col-md-3">
              <h2 className="display-4 fw-bold text-success">50+</h2>
              <p className="mb-0 text-white-50 fw-semibold text-uppercase small">Tourist Categories</p>
            </div>
            <div className="col-md-3">
              <h2 className="display-4 fw-bold text-success">10K+</h2>
              <p className="mb-0 text-white-50 fw-semibold text-uppercase small">Happy Travelers</p>
            </div>
            <div className="col-md-3">
              <h2 className="display-4 fw-bold text-success">500+</h2>
              <p className="mb-0 text-white-50 fw-semibold text-uppercase small">Verified Reviews</p>
            </div>
            <div className="col-md-3">
              <h2 className="display-4 fw-bold text-success">99.8%</h2>
              <p className="mb-0 text-white-50 fw-semibold text-uppercase small">Satisfaction Rate</p>
            </div>
          </div>
        </div>
      </section>

      {/* 5. Call to Action / Testimonials */}
      <section className="container pb-5">
        <div className="row align-items-center g-5">
          <div className="col-md-6">
            <img
              src="https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=800"
              alt="Travel Planning"
              className="img-fluid rounded-4 shadow-lg"
              style={{ objectFit: 'cover', height: '400px', width: '100%' }}
            />
          </div>
          <div className="col-md-6">
            <span className="text-uppercase small fw-bold text-success">Plan with Us</span>
            <h2 className="fw-bold display-5 mt-2 mb-4">Start Sharing Your Reviews Today</h2>
            <p className="text-secondary mb-4">
              Join a community of travelers around the world. Rate your favorite local hotels, review nature spots, comment on tourist guides, bookmark places you love, and request custom package bookings!
            </p>
            <div className="d-flex gap-3">
              <Link to="/register" className="btn btn-explore-green btn-lg px-4 rounded-pill">Create Free Account</Link>
              <Link to="/about" className="btn btn-outline-dark btn-lg px-4 rounded-pill">Read More</Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
