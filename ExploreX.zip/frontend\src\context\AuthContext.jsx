import React, { createContext, useState, useEffect, useContext } from 'react';
import api from '../services/api';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Attempt to load token and user details from localStorage on initial page paint
    const storedToken = localStorage.getItem('token');
    const storedUser = localStorage.getItem('user');

    if (storedToken && storedUser) {
      setToken(storedToken);
      setUser(JSON.parse(storedUser));
    }
    setLoading(false);
  }, []);

  const login = async (usernameOrEmail, password) => {
    try {
      const response = await api.post('/auth/login', { usernameOrEmail, password });
      const { accessToken, id, username, email, roles } = response.data;

      localStorage.setItem('token', accessToken);
      const userData = { id, username, email, roles };
      localStorage.setItem('user', JSON.stringify(userData));

      setToken(accessToken);
      setUser(userData);
      return { success: true };
    } catch (error) {
      console.error('Login error:', error);
      const message = error.response?.data?.message || 'Login failed. Please check credentials.';
      return { success: false, error: message };
    }
  };

  const register = async (registerData) => {
    try {
      await api.post('/auth/register', registerData);
      return { success: true };
    } catch (error) {
      console.error('Registration error:', error);
      const message = error.response?.data?.message || 'Registration failed. Try a different username/email.';
      return { success: false, error: message };
    }
  };

  const logout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setToken(null);
    setUser(null);
  };

  const editProfile = (updatedProfile) => {
    // If the email or names change in user settings, synchronize our active header states
    const storedUser = JSON.parse(localStorage.getItem('user') || '{}');
    const newUser = { ...storedUser, email: updatedProfile.email };
    localStorage.setItem('user', JSON.stringify(newUser));
    setUser(newUser);
  };

  const isAdmin = user?.roles?.includes('ROLE_ADMIN') || false;

  const value = {
    user,
    token,
    loading,
    login,
    register,
    logout,
    editProfile,
    isAuthenticated: !!user,
    isAdmin
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be executed within an AuthProvider scope');
  }
  return context;
};
