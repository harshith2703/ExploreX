# ExploreX - Project Architecture Documentation

This document outlines the software architecture, design patterns, components, and data flow of the **ExploreX Tourist Information System** (CRUD College Project).

---

## 1. System Architecture Overview

ExploreX follows a decoupled, multi-tier **Client-Server Architecture** separating the user interface, application logic, and database layer.

```mermaid
graph TD
    subgraph Client Tier (Frontend)
        React[React JS Application]
        Context[Context API - Global State]
        Axios[Axios HTTP Client]
        React --> Context
        React --> Axios
    end

    subgraph Application Tier (Backend)
        Controller[Controller Layer - REST APIs]
        DTO[DTO Transfer Layer]
        Security[Spring Security & JWT Filter]
        Service[Service Implementation Layer]
        Mapper[Manual Mapper Layer]
        Repo[Spring Data JPA Repository Layer]
        
        Controller --> Security
        Controller --> DTO
        Controller --> Service
        Service --> Mapper
        Service --> Repo
    end

    subgraph Database Tier (Persistence)
        MySQL[(MySQL 8.0 Database)]
        Repo --> MySQL
    end

    Axios -- HTTP Requests / REST --&gt; Controller
    Controller -- JSON Responses --&gt; Axios
```

---

## 2. Technology Stack

### Frontend (Client-side)
*   **Core Library**: React 18
*   **Build Tool**: Vite (Ultra-fast HMR and bundling)
*   **Routing**: React Router DOM v6
*   **Styling**: Bootstrap 5.3.3 & Bootstrap Icons
*   **HTTP Client**: Axios (with global request/response interceptors)
*   **Maps Engine**: Google Maps JavaScript API (Haversine calculations computed client-side for geo-proximity)

### Backend (Server-side)
*   **Core Framework**: Spring Boot 3.3.1
*   **Language Runtime**: Java 24 / 26
*   **Security Framework**: Spring Security (Stateless JWT Authentication & BCrypt Password Hashing)
*   **Persistence Specification**: Jakarta Persistence (JPA) / Hibernate ORM
*   **Build Tool**: Apache Maven
*   **API Docs Engine**: Springdoc OpenAPI v3 (Swagger UI)

### Database Layer
*   **Database Engine**: MySQL 8.0+
*   **Connection Pool**: HikariCP (Default Spring Boot high-performance connection pool)

---

## 3. Backend Architectural Layers (Spring Boot)

The backend follows a strict **Layered (n-Tier) Architecture** to ensure separation of concerns, maintainability, and clean code principles.

```
[HTTP Request] -> Controller -> Service -> Repository -> Database
[HTTP Response] <- Controller <- Service <- Repository <- Database
```

### 1. Controller Layer (`com.explorex.controller`)
*   **Responsibility**: Exposes REST API endpoints.
*   **Implementation**: annotated with `@RestController` and `@RequestMapping`. Extracts path variables, request parameters, and headers. Passes requests to the Service layer and returns HTTP responses (`ResponseEntity`).
*   **Example**: `TouristPlaceController` handles all requests starting with `/api/places` and `/api/admin/places`.

### 2. DTO Layer (`com.explorex.dto`)
*   **Responsibility**: Insulates the internal database entities from external clients.
*   **Implementation**: Plain Old Java Objects (POJOs) containing only transfer fields and JSR-380 validation constraints (e.g. `@NotBlank`, `@Email`, `@Min`).
*   **Example**: `RegisterRequest` for signups, `TouristPlaceDto` for catalog representations.

### 3. Service Layer (`com.explorex.service`)
*   **Responsibility**: Core business logic, transaction handling, and security constraints.
*   **Implementation**: Decoupled interface-driven design (`com.explorex.service` interfaces and `com.explorex.service.impl` implementations). Annotated with `@Service` and `@Transactional`.
*   **Example**: `BookingServiceImpl` validates if a destination exists, associates the logged-in user, and creates the booking transaction.

### 4. Repository Layer (`com.explorex.repository`)
*   **Responsibility**: Database abstraction and SQL generation.
*   **Implementation**: Interfaces extending `JpaRepository<Entity, ID>`. Leverages Spring Data JPA's query creation from method names.
*   **Example**: `UserRepository.existsByEmail(String email)`.

### 5. Entity Layer (`com.explorex.entity`)
*   **Responsibility**: Represents the physical MySQL tables as Java objects.
*   **Implementation**: Annotated with `@Entity`, `@Table`, `@Id`, `@Column`, and relationship annotations (`@ManyToOne`, `@OneToMany`, `@ManyToMany`).
*   **Example**: `TouristPlace.java` maps fields like `name`, `latitude`, `longitude` to the database columns.

### 6. Mapper Layer (`com.explorex.mapper`)
*   **Responsibility**: Converts JPA Entities to DTOs and vice versa.
*   **Implementation**: Explicit Java mapper classes containing static conversion methods. This approach keeps mapper behavior transparent and debuggable without complex external reflection libraries.
*   **Example**: `TouristPlaceMapper.toDto(...)` and `TouristPlaceMapper.toEntity(...)`.

---

## 4. Frontend Architectural Layers (React JS)

```
Index.html -> main.jsx -> App.jsx (Routes) -> Layout -> Component Views
                                 |
                          [AuthContext Provider] -> Global Session State
```

### 1. Global Context Layer (`src/context`)
*   **Responsibility**: Handles global session authentication, registration, token persistence, and logout capabilities.
*   **Implementation**: React Context API (`AuthContext.jsx`). Wraps the entire application hierarchy.

### 2. API Service Layer (`src/services`)
*   **Responsibility**: Handles HTTP connection configurations and requests.
*   **Implementation**: Axios instance (`api.js`) configured with a dynamic base URL `window.location.hostname` (allowing network-wide local IP access) and an interceptor that automatically attaches the JWT token to the `Authorization` header.

### 3. View / Page Components (`src/pages`)
*   **Responsibility**: Page routing targets and layout wrappers.
*   **Examples**:
    *   `Home.jsx`: Dynamic homepage featuring reviews and landing content.
    *   `Destinations.jsx`: Search and grid listing with client-side proximity sorting ("Nearest to Me").
    *   `ExploreMap.jsx`: Unified interactive Google Map canvas.
    *   `AdminDashboard.jsx`: Consolidated CRUD management operations.

---

## 5. Security & Authentication Architecture

ExploreX implements stateless token-based authorization via **JSON Web Tokens (JWT)**.

```
1. User submits login credentials -> [POST /api/auth/login]
2. Backend validates credentials via AuthenticationManager.
3. If valid, JwtTokenProvider generates a signed JWT.
4. Token sent in JSON Response body.
5. Frontend saves token to localStorage and attaches it to subsequent requests.
```

### Key Security Classes:
*   `JwtAuthenticationFilter`: Intercepts every incoming HTTP request, extracts the Bearer token, validates the signature, and sets the authentication context in the Spring Security context.
*   `JwtAuthenticationEntryPoint`: Handles unauthenticated attempts to access secure REST APIs, returning an HTTP `401 Unauthorized` response.
*   `SecurityConfig`: Central security configuration that defines route protection parameters, enables CORS, disables CSRF (since the API is stateless), and injects the password BCrypt encoder.
