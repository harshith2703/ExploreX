package com.explorex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Main application bootstrap class for ExploreX - Tourist Information System.
 */
@SpringBootApplication
public class ExplorexApplication {

    public static void main(String[] args) {
        SpringApplication.run(ExplorexApplication.class, args);
    }
}
