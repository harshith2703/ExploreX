package com.explorex.service.impl;

import com.explorex.dto.TouristPlaceDto;
import com.explorex.entity.Category;
import com.explorex.entity.Image;
import com.explorex.entity.TouristPlace;
import com.explorex.exception.ResourceNotFoundException;
import com.explorex.mapper.TouristPlaceMapper;
import com.explorex.repository.CategoryRepository;
import com.explorex.repository.ImageRepository;
import com.explorex.repository.TouristPlaceRepository;
import com.explorex.service.TouristPlaceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Service implementation for TouristPlace operations.
 */
@Service
public class TouristPlaceServiceImpl implements TouristPlaceService {

    @Autowired
    private TouristPlaceRepository touristPlaceRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private ImageRepository imageRepository;

    @Override
    @Transactional
    public TouristPlaceDto createTouristPlace(TouristPlaceDto dto) {
        Category category = categoryRepository.findById(dto.getCategoryId())
                .orElseThrow(() -> new ResourceNotFoundException("Category", "id", dto.getCategoryId()));

        TouristPlace touristPlace = TouristPlaceMapper.toEntity(dto);
        touristPlace.setCategory(category);
        touristPlace.setAverageRating(0.0);

        // Bind images if provided
        if (dto.getImageUrls() != null && !dto.getImageUrls().isEmpty()) {
            List<Image> images = dto.getImageUrls().stream().map(url -> {
                Image image = new Image();
                image.setImageUrl(url);
                image.setTouristPlace(touristPlace);
                return image;
            }).collect(Collectors.toList());
            touristPlace.setImages(images);
        }

        TouristPlace savedPlace = touristPlaceRepository.save(touristPlace);
        return TouristPlaceMapper.toDto(savedPlace);
    }

    @Override
    public TouristPlaceDto getTouristPlaceById(Long id) {
        TouristPlace touristPlace = touristPlaceRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("TouristPlace", "id", id));
        return TouristPlaceMapper.toDto(touristPlace);
    }

    @Override
    public List<TouristPlaceDto> getAllTouristPlaces() {
        return touristPlaceRepository.findAll().stream()
                .map(TouristPlaceMapper::toDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public TouristPlaceDto updateTouristPlace(Long id, TouristPlaceDto dto) {
        TouristPlace touristPlace = touristPlaceRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("TouristPlace", "id", id));

        Category category = categoryRepository.findById(dto.getCategoryId())
                .orElseThrow(() -> new ResourceNotFoundException("Category", "id", dto.getCategoryId()));

        touristPlace.setName(dto.getName());
        touristPlace.setDescription(dto.getDescription());
        touristPlace.setLocation(dto.getLocation());
        touristPlace.setState(dto.getState());
        touristPlace.setDistrict(dto.getDistrict());
        touristPlace.setLatitude(dto.getLatitude());
        touristPlace.setLongitude(dto.getLongitude());
        touristPlace.setCategory(category);

        // Clear existing images and replace them
        touristPlace.getImages().clear();
        if (dto.getImageUrls() != null && !dto.getImageUrls().isEmpty()) {
            List<Image> newImages = dto.getImageUrls().stream().map(url -> {
                Image image = new Image();
                image.setImageUrl(url);
                image.setTouristPlace(touristPlace);
                return image;
            }).collect(Collectors.toList());
            touristPlace.getImages().addAll(newImages);
        }

        TouristPlace updatedPlace = touristPlaceRepository.save(touristPlace);
        return TouristPlaceMapper.toDto(updatedPlace);
    }

    @Override
    @Transactional
    public void deleteTouristPlace(Long id) {
        if (!touristPlaceRepository.existsById(id)) {
            throw new ResourceNotFoundException("TouristPlace", "id", id);
        }
        touristPlaceRepository.deleteById(id);
    }

    @Override
    public List<TouristPlaceDto> searchAndFilterTouristPlaces(Long categoryId, String keyword, String sortBy) {
        Sort sort = Sort.by(Sort.Direction.ASC, "name"); // Default sorting

        if (sortBy != null && !sortBy.trim().isEmpty()) {
            switch (sortBy.toLowerCase()) {
                case "newest":
                    sort = Sort.by(Sort.Direction.DESC, "createdAt");
                    break;
                case "rating":
                    sort = Sort.by(Sort.Direction.DESC, "averageRating");
                    break;
                case "popularity":
                    sort = Sort.by(Sort.Direction.DESC, "id"); // fallback
                    break;
                case "alphabetical":
                default:
                    sort = Sort.by(Sort.Direction.ASC, "name");
                    break;
            }
        }

        String searchKeyword = (keyword != null && !keyword.trim().isEmpty()) ? keyword.trim() : null;

        return touristPlaceRepository.filterAndSearch(categoryId, searchKeyword, sort).stream()
                .map(TouristPlaceMapper::toDto)
                .collect(Collectors.toList());
    }
}
