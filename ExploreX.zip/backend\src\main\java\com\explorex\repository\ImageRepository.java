package com.explorex.repository;

import com.explorex.entity.Image;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Spring Data Repository for the {@link Image} entity.
 */
@Repository
public interface ImageRepository extends JpaRepository<Image, Long> {
    List<Image> findByTouristPlaceId(Long touristPlaceId);
}
