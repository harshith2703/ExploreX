import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import api from '../services/api';

const Profile = () => {
  const { user, editProfile } = useAuth();
  
  // Profile settings state
  const [profile, setProfile] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phoneNumber: '',
    profilePicture: ''
  });
  const [profileSuccess, setProfileSuccess] = useState('');
  const [profileError, setProfileError] = useState('');

  // Password settings state
  const [passwordData, setPasswordData] = useState({
    oldPassword: '',
    newPassword: '',
    confirmNewPassword: ''
  });
  const [passwordSuccess, setPasswordSuccess] = useState('');
  const [passwordError, setPasswordError] = useState('');

  useEffect(() => {
    // Fetch profile details on load
    const fetchProfileData = async () => {
      try {
        const res = await api.get('/user/profile');
        setProfile(res.data);
      } catch (err) {
        console.error('Error fetching user profile:', err);
      }
    };
    fetchProfileData();
  }, []);

  const handleProfileChange = (e) => {
    setProfile({
      ...profile,
      [e.target.name]: e.target.value
    });
  };

  const handlePasswordChange = (e) => {
    setPasswordData({
      ...passwordData,
      [e.target.name]: e.target.value
    });
  };

  const handleProfileSubmit = async (e) => {
    e.preventDefault();
    setProfileSuccess('');
    setProfileError('');

    if (!profile.firstName.trim() || !profile.email.trim()) {
      setProfileError('First Name and Email are required.');
      return;
    }

    try {
      const res = await api.put('/user/profile/update', profile);
      setProfileSuccess('Profile updated successfully!');
      editProfile(res.data); // Update AuthContext variables
    } catch (err) {
      setProfileError(err.response?.data?.message || 'Error updating profile.');
    }
  };

  const handlePasswordSubmit = async (e) => {
    e.preventDefault();
    setPasswordSuccess('');
    setPasswordError('');

    const { oldPassword, newPassword, confirmNewPassword } = passwordData;
    if (!oldPassword || !newPassword || !confirmNewPassword) {
      setPasswordError('Please fill in all the password fields.');
      return;
    }

    if (newPassword.length < 6) {
      setPasswordError('New password must be at least 6 characters long.');
      return;
    }

    if (newPassword !== confirmNewPassword) {
      setPasswordError('New passwords do not match.');
      return;
    }

    try {
      await api.put('/user/change-password', { oldPassword, newPassword });
      setPasswordSuccess('Password updated successfully!');
      setPasswordData({ oldPassword: '', newPassword: '', confirmNewPassword: '' });
    } catch (err) {
      setPasswordError(err.response?.data?.message || 'Incorrect current password.');
    }
  };

  return (
    <div className="container py-5">
      <div className="text-center mb-5">
        <h1 className="fw-bold display-4">Profile Settings</h1>
        <p className="text-muted">Manage your personal settings, password changes, and account security details</p>
      </div>

      <div className="row g-4 justify-content-center">
        {/* Left Side: Avatar Panel */}
        <div className="col-lg-3">
          <div className="card shadow-sm border-0 p-4 text-center" style={{ borderRadius: '16px' }}>
            <img
              src={profile.profilePicture || `https://api.dicebear.com/7.x/adventurer/svg?seed=${user?.username}`}
              alt={user?.username}
              className="rounded-circle mx-auto mb-3 shadow border"
              style={{ width: '120px', height: '120px', objectFit: 'cover' }}
            />
            <h4 className="fw-bold text-dark mb-1">{profile.firstName} {profile.lastName}</h4>
            <span className="badge bg-success-subtle text-success border border-success-subtle rounded-pill px-3 py-1 text-uppercase small">
              {user?.roles?.[0]?.replace('ROLE_', '') || 'Tourist'}
            </span>
            <p className="text-muted small mt-3 mb-0">Registered member since 2026</p>
          </div>
        </div>

        {/* Right Side: Configuration Forms */}
        <div className="col-lg-7">
          {/* Edit Profile Form */}
          <div className="card shadow-sm border-0 p-4 mb-4" style={{ borderRadius: '16px' }}>
            <h4 className="fw-bold text-dark mb-4"><i className="bi bi-person-gear text-primary me-2"></i>Personal Details</h4>

            {profileSuccess && <div className="alert alert-success border-0 text-center rounded-pill py-2 small">{profileSuccess}</div>}
            {profileError && <div className="alert alert-danger border-0 text-center rounded-pill py-2 small">{profileError}</div>}

            <form onSubmit={handleProfileSubmit}>
              <div className="row">
                <div className="col-md-6 mb-3">
                  <label className="form-label small fw-semibold text-secondary">First Name *</label>
                  <input
                    type="text"
                    className="form-control bg-light border-0 py-2"
                    name="firstName"
                    value={profile.firstName}
                    onChange={handleProfileChange}
                  />
                </div>
                <div className="col-md-6 mb-3">
                  <label className="form-label small fw-semibold text-secondary">Last Name</label>
                  <input
                    type="text"
                    className="form-control bg-light border-0 py-2"
                    name="lastName"
                    value={profile.lastName || ''}
                    onChange={handleProfileChange}
                  />
                </div>
              </div>

              <div className="row">
                <div className="col-md-6 mb-3">
                  <label className="form-label small fw-semibold text-secondary">Email Address *</label>
                  <input
                    type="email"
                    className="form-control bg-light border-0 py-2"
                    name="email"
                    value={profile.email}
                    onChange={handleProfileChange}
                  />
                </div>
                <div className="col-md-6 mb-3">
                  <label className="form-label small fw-semibold text-secondary">Phone Number</label>
                  <input
                    type="text"
                    className="form-control bg-light border-0 py-2"
                    name="phoneNumber"
                    value={profile.phoneNumber || ''}
                    onChange={handleProfileChange}
                  />
                </div>
              </div>

              <div className="mb-4">
                <label className="form-label small fw-semibold text-secondary">Avatar SVG URL</label>
                <input
                  type="text"
                  className="form-control bg-light border-0 py-2"
                  name="profilePicture"
                  value={profile.profilePicture || ''}
                  onChange={handleProfileChange}
                  placeholder="Paste image web link or leave blank"
                />
              </div>

              <button type="submit" className="btn btn-explore rounded-pill px-4 shadow">
                Save Personal Details
              </button>
            </form>
          </div>

          {/* Change Password Form */}
          <div className="card shadow-sm border-0 p-4" style={{ borderRadius: '16px' }}>
            <h4 className="fw-bold text-dark mb-4"><i className="bi bi-shield-lock text-success me-2"></i>Change Password</h4>

            {passwordSuccess && <div className="alert alert-success border-0 text-center rounded-pill py-2 small">{passwordSuccess}</div>}
            {passwordError && <div className="alert alert-danger border-0 text-center rounded-pill py-2 small">{passwordError}</div>}

            <form onSubmit={handlePasswordSubmit}>
              <div className="mb-3">
                <label className="form-label small fw-semibold text-secondary">Current Password</label>
                <input
                  type="password"
                  className="form-control bg-light border-0 py-2"
                  name="oldPassword"
                  value={passwordData.oldPassword}
                  onChange={handlePasswordChange}
                />
              </div>

              <div className="row">
                <div className="col-md-6 mb-4">
                  <label className="form-label small fw-semibold text-secondary">New Password</label>
                  <input
                    type="password"
                    className="form-control bg-light border-0 py-2"
                    name="newPassword"
                    value={passwordData.newPassword}
                    onChange={handlePasswordChange}
                  />
                </div>
                <div className="col-md-6 mb-4">
                  <label className="form-label small fw-semibold text-secondary">Confirm New Password</label>
                  <input
                    type="password"
                    className="form-control bg-light border-0 py-2"
                    name="confirmNewPassword"
                    value={passwordData.confirmNewPassword}
                    onChange={handlePasswordChange}
                  />
                </div>
              </div>

              <button type="submit" className="btn btn-explore-green rounded-pill px-4 shadow text-white">
                Change Password
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
