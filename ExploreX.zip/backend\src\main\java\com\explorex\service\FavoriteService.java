package com.explorex.service;

import com.explorex.dto.TouristPlaceDto;

import java.util.List;

/**
 * Service interface for Favorite tourist places operations.
 */
public interface FavoriteService {
    void addFavorite(Long userId, Long placeId);
    void removeFavorite(Long userId, Long placeId);
    List<TouristPlaceDto> getFavoritesByUser(Long userId);
    Boolean isFavorite(Long userId, Long placeId);
}
