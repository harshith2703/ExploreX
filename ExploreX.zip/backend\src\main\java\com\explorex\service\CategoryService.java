package com.explorex.service;

import com.explorex.dto.CategoryDto;

import java.util.List;

/**
 * Service interface for Category CRUD operations.
 */
public interface CategoryService {
    CategoryDto createCategory(CategoryDto categoryDto);
    CategoryDto getCategoryById(Long id);
    List<CategoryDto> getAllCategories();
    CategoryDto updateCategory(Long id, CategoryDto categoryDto);
    void deleteCategory(Long id);
}
