package com.explorex.service;

import com.explorex.dto.TouristPlaceDto;

import java.util.List;

/**
 * Service interface for TouristPlace CRUD and query operations.
 */
public interface TouristPlaceService {
    TouristPlaceDto createTouristPlace(TouristPlaceDto touristPlaceDto);
    TouristPlaceDto getTouristPlaceById(Long id);
    List<TouristPlaceDto> getAllTouristPlaces();
    TouristPlaceDto updateTouristPlace(Long id, TouristPlaceDto touristPlaceDto);
    void deleteTouristPlace(Long id);
    List<TouristPlaceDto> searchAndFilterTouristPlaces(Long categoryId, String keyword, String sortBy);
}
