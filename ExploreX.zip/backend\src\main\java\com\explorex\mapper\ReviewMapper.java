package com.explorex.mapper;

import com.explorex.dto.ReviewDto;
import com.explorex.entity.Review;

/**
 * Mapper utility to convert between Review entities and DTOs.
 */
public class ReviewMapper {

    public static ReviewDto toDto(Review review) {
        if (review == null) {
            return null;
        }

        ReviewDto dto = new ReviewDto();
        dto.setId(review.getId());
        dto.setRating(review.getRating());
        dto.setComment(review.getComment());
        dto.setCreatedAt(review.getCreatedAt());

        if (review.getUser() != null) {
            dto.setUserId(review.getUser().getId());
            dto.setUsername(review.getUser().getUsername());
            dto.setUserProfilePic(review.getUser().getProfilePicture());
        }

        if (review.getTouristPlace() != null) {
            dto.setTouristPlaceId(review.getTouristPlace().getId());
            dto.setTouristPlaceName(review.getTouristPlace().getName());
        }

        return dto;
    }

    public static Review toEntity(ReviewDto dto) {
        if (dto == null) {
            return null;
        }

        Review review = new Review();
        review.setId(dto.getId());
        review.setRating(dto.getRating());
        review.setComment(dto.getComment());
        // User and TouristPlace will be resolved in Service layer
        return review;
    }
}
