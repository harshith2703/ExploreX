import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Login = () => {
  const [usernameOrEmail, setUsernameOrEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    
    if (!usernameOrEmail.trim() || !password.trim()) {
      setError('Please fill in all the credentials.');
      return;
    }

    setLoading(true);
    const result = await login(usernameOrEmail, password);
    setLoading(false);

    if (result.success) {
      navigate('/');
    } else {
      setError(result.error);
    }
  };

  return (
    <div className="container py-5">
      <div className="row justify-content-center">
        <div className="col-md-5">
          <div className="card shadow-lg border-0 p-4" style={{ borderRadius: '16px' }}>
            <div className="card-body">
              <div className="text-center mb-4">
                <i className="bi bi-compass text-primary" style={{ fontSize: '3rem' }}></i>
                <h2 className="mt-3 fw-bold">Welcome Back</h2>
                <p className="text-muted">Sign in to plan your next adventure</p>
              </div>

              {error && (
                <div className="alert alert-danger border-0 text-center rounded-pill" role="alert">
                  <i className="bi bi-exclamation-triangle-fill me-2"></i>{error}
                </div>
              )}

              <form onSubmit={handleSubmit}>
                <div className="mb-3">
                  <label className="form-label fw-semibold text-secondary">Username or Email</label>
                  <div className="input-group">
                    <span className="input-group-text bg-light border-0"><i className="bi bi-person text-muted"></i></span>
                    <input
                      type="text"
                      className="form-control bg-light border-0 py-2"
                      placeholder="Enter username or email"
                      value={usernameOrEmail}
                      onChange={(e) => setUsernameOrEmail(e.target.value)}
                    />
                  </div>
                </div>

                <div className="mb-4">
                  <div className="d-flex justify-content-between">
                    <label className="form-label fw-semibold text-secondary">Password</label>
                    <Link to="/contact" className="text-decoration-none small" style={{ color: 'var(--medium-blue)' }}>Forgot Password?</Link>
                  </div>
                  <div className="input-group">
                    <span className="input-group-text bg-light border-0"><i className="bi bi-lock text-muted"></i></span>
                    <input
                      type="password"
                      className="form-control bg-light border-0 py-2"
                      placeholder="Enter password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="btn btn-explore w-100 py-2 rounded-pill fw-bold fs-5 shadow"
                  disabled={loading}
                >
                  {loading ? (
                    <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                  ) : 'Sign In'}
                </button>
              </form>

              <div className="text-center mt-4">
                <span className="text-muted">Don't have an account? </span>
                <Link to="/register" className="fw-semibold text-decoration-none" style={{ color: 'var(--primary-green)' }}>Sign Up</Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
