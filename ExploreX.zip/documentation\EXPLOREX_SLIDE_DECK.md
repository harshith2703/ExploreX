# ExploreX – Slide Presentation Outline
> Optimized for copying directly into a PowerPoint (PPT) presentation

---

### **Slide 1: Title Slide**

# **ExploreX**
A full-stack travel booking & geolocation intelligence web application built with **React.js**, **Spring Boot**, and **MySQL** — enabling users to discover, map, and book destinations.

`FULL-STACK PROJECT` `REACT + SPRING BOOT + MYSQL` `GEOLOCATION INTELLIGENCE`

---

### **Slide 2: Introduction & Objectives**

## **Introduction & Objectives**
ExploreX is a tourist information portal where travelers search destinations, view relative physical distances dynamically, and book packages with integrated Google Maps canvas tracking.

#### **User Registration & Login**
*   Secure role-based account creation and JWT authentication.

#### **Proximity-Based Discovery**
*   Calculates client distances and sorts destinations by browser location proximity.

#### **Tour Bookings & Wishlists**
*   Trip reservation manager, booking status updates, and favorites wishlist.

#### **Interactive Geo-Mapping**
*   Dynamic Google Map markers, popup coordinates, and admin location controls.

---

### **Slide 3: Technologies Used**

## **Technologies Used**

#### **Frontend**
*   React.js · HTML5 · CSS3
*   JavaScript · Axios · React Router
*   Google Maps JavaScript API

#### **Backend**
*   Spring Boot 3.3.1 · Java · Maven
*   Spring Data JPA · Spring Security
*   Stateless JWT Engine

#### **Database**
*   MySQL 8.0 · schema.sql · data.sql
*   HikariCP connection pooling

#### **Tools**
*   RESTful APIs · Git & GitHub
*   Spring Tool Suite (STS)
*   Visual Studio Code

---

### **Slide 4: System Architecture**

## **System Architecture**
Data flows cleanly between three layers — the React frontend sends HTTP requests, the Spring Boot backend processes logic through its layered architecture, and MySQL persists all data.

```
                  [ FOUR-LAYER ARCHITECTURE FLOW ]

  +-----------------------+      Axios HTTP       +-----------------------+
  |    React Frontend     | --------------------> |   Controller Layer    |
  |  (Sends HTTP Requests)| <-------------------- |  (Validates Inputs)   |
  +-----------------------+     JSON Response     +-----------------------+
                                                              |
                                                              v
  +-----------------------+                       +-----------------------+
  |    MySQL Database     | <-------------------- |     Service Layer     |
  |  (Stores & Retrieves) | --------------------> |(Processes Business)   |
  +-----------------------+    Repository Layer   +-----------------------+
```
*This layered approach ensures separation of concerns — the frontend handles UI, the controller manages routing, the service encapsulates business logic, and the repository handles database access via JPA.*

---

### **Slide 5: Project Structure**

## **Project Structure**

### **Folder Organization**
The project is split into three top-level folders, each with a focused responsibility.

#### **📁 frontend/**
*   `src/components/` (reusable UI components)
*   `src/pages/` (page views: ExploreMap, Destinations)
*   `src/services/` (axios client setup: api.js)
*   `public/` (brand logo: favicon.svg)

#### **📁 backend/**
*   `controller/` (REST controller endpoints)
*   `service/` (business interfaces & implementations)
*   `repository/` (database access queries)
*   `entity/` (JPA mappings) · `dto/` (request validation)
*   `config/` (CORS and Security setups)

#### **📁 database/**
*   `schema.sql` (table structures)
*   `data.sql` (initial tourist places & maps seeds)

---

### **Slide 6: Database Design**

## **Database Design**

### **Core Tables**
The database uses normalized relational tables linked by foreign key relationships.

#### **Users**
*   `id (PK)`, `username`, `email`, `password`, `first_name`, `phone_number`

#### **Tourist Places**
*   `id (PK)`, `name`, `description`, `location`, `state`, `average_rating`, `latitude`, `longitude`, `category_id (FK)`

#### **Bookings**
*   `id (PK)`, `booking_date`, `number_of_people`, `status`, `user_id (FK)`, `tourist_place_id (FK)`

```
  +-------------+                 +----------------+
  |    Users    | 1             * |    Bookings    |
  | (Profile)   |---------------->| (Reservations) |
  +-------------+                 +----------------+
                                          ^
                                          | *
                                          | 1
                                  +----------------+
                                  | Tourist Places |
                                  | (Coordinates)  |
                                  +----------------+
```
*Each user can book multiple destinations — a classic one-to-many relationship enforced via foreign keys.*

---

### **Slide 7: Frontend–Backend Connection**

## **Frontend–Backend Connection**
React communicates with Spring Boot exclusively through RESTful APIs, exchanging JSON data over HTTP. Axios handles all requests from the UI layer.

```
  [React UI] -> [Axios HTTP] -> [Spring Controller] -> [Service & Repo]
```
*This stateless REST architecture keeps the frontend and backend decoupled, enabling independent development and testing of each layer.*

### **Example API Endpoints**
| Method | Endpoint | Purpose |
| :--- | :--- | :--- |
| **POST** | `/api/auth/register` | Register new user |
| **POST** | `/api/auth/login` | Authenticate user (returns JWT) |
| **GET** | `/api/places` | Fetch tourist places (supporting sorting) |
| **POST** | `/api/bookings` | Create a new tour booking |
| **GET** | `/api/favorites/my-favorites` | Fetch user's wishlist |
| **POST** | `/api/admin/places` | Create a new destination card (Admin) |

---

### **Slide 8: Key Features**

## **Key Features**

#### **🔑 User Authentication**
*   Secure registration and login with validated credentials and stateless JWT tokens.

#### **📍 Geolocation Distance Tracker**
*   Calculates live distance in kilometers using the mathematical **Haversine formula**.

#### **🗺️ Interactive Map Canvas**
*   Visual Google Map plotting destinations with custom markers, sidebar indexes, and popup cards.

#### **🗂️ Proximity Sorting**
*   Dynamic "Nearest to Me" catalog sort to organize destinations by current distance.

#### **🛠️ Admin CRUD Control**
*   Administrative dashboards to manage destinations, coordinates, bookings, and help desk messages.

#### **📱 Responsive Design**
*   Adaptive layouts styled using Bootstrap 5, optimized for mobile, tablet, and desktop screens.

---

### **Slide 9: Advantages & Future Enhancements**

## **Advantages & Future Enhancements**

### **Current Advantages**
*   **Easy to Use** — Modern, clean UI matching curated color schemas.
*   **Secure** — Encrypted passwords via BCrypt and validated inputs.
*   **Proximity Calculations** — Computes Haversine distances in the client DOM to save server processing power.
*   **Network-Ready** — Dynamic hostname resolution supports testing on local Wi-Fi networks.

### **Future Enhancements**
*   **Live Payment checkout** (e.g. Stripe gateway integration).
*   **Automated Email confirmations** on booking approvals.
*   **Directions Routing** connecting Google Maps Directions API.
*   **Social Sign-In** integrations (Google/Facebook OAuth2).

---

### **Slide 10: Conclusion**

## **Conclusion**
This project demonstrates a complete full-stack development workflow — from designing a relational database to building a reactive frontend and a robust REST API backend.

#### **Project Summary**
*   A working travel portal with authentication, coordinates mapping, proximity calculations, bookings, and admin tools.

#### **Learning Outcomes**
*   React component states, browser HTML5 Geolocation API, Spring Boot security configurations, and MySQL database relational design.

### **Thank You!**
*   Questions and feedback are welcome!
