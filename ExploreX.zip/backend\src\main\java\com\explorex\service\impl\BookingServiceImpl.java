package com.explorex.service.impl;

import com.explorex.dto.BookingDto;
import com.explorex.entity.Booking;
import com.explorex.entity.TouristPlace;
import com.explorex.entity.User;
import com.explorex.exception.BadRequestException;
import com.explorex.exception.ResourceNotFoundException;
import com.explorex.mapper.BookingMapper;
import com.explorex.repository.BookingRepository;
import com.explorex.repository.TouristPlaceRepository;
import com.explorex.repository.UserRepository;
import com.explorex.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Service implementation for Booking operations.
 */
@Service
public class BookingServiceImpl implements BookingService {

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private TouristPlaceRepository touristPlaceRepository;

    @Override
    @Transactional
    public BookingDto createBooking(Long userId, BookingDto dto) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));

        TouristPlace place = touristPlaceRepository.findById(dto.getTouristPlaceId())
                .orElseThrow(() -> new ResourceNotFoundException("TouristPlace", "id", dto.getTouristPlaceId()));

        Booking booking = BookingMapper.toEntity(dto);
        booking.setUser(user);
        booking.setTouristPlace(place);
        booking.setStatus("PENDING");

        Booking savedBooking = bookingRepository.save(booking);
        return BookingMapper.toDto(savedBooking);
    }

    @Override
    public List<BookingDto> getBookingsByUserId(Long userId) {
        if (!userRepository.existsById(userId)) {
            throw new ResourceNotFoundException("User", "id", userId);
        }
        return bookingRepository.findByUserId(userId).stream()
                .map(BookingMapper::toDto)
                .collect(Collectors.toList());
    }

    @Override
    public List<BookingDto> getAllBookings() {
        return bookingRepository.findAll().stream()
                .map(BookingMapper::toDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public BookingDto updateBookingStatus(Long bookingId, String status) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking", "id", bookingId));

        String sanitizedStatus = status.trim().toUpperCase();
        if (!sanitizedStatus.equals("PENDING") && !sanitizedStatus.equals("APPROVED") && !sanitizedStatus.equals("CANCELLED")) {
            throw new BadRequestException("Invalid status code: choose PENDING, APPROVED, or CANCELLED.");
        }

        booking.setStatus(sanitizedStatus);
        Booking updatedBooking = bookingRepository.save(booking);
        return BookingMapper.toDto(updatedBooking);
    }

    @Override
    @Transactional
    public void cancelBooking(Long userId, Long bookingId) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking", "id", bookingId));

        if (!booking.getUser().getId().equals(userId)) {
            throw new BadRequestException("You do not have permission to cancel this booking!");
        }

        booking.setStatus("CANCELLED");
        bookingRepository.save(booking);
    }
}
